function [ C_in, C_out, B_in, B_out ] = slc( M )
%SLC Spectral-Lens-Connectivity

    %% SLC Step 1: Find optimal in- and out-k

    [U,~,V] = svds(M,30);
    clear M;

    [ k_opt_out, S_k_opt_out  ] = findOptimalK(U);
    [ k_opt_in, S_k_opt_in  ] = findOptimalK(V);

    clear U V;

    %% SLC Step 2: Assign CC-nodeGroups and bridges

    [C_out, B_out] = assign(S_k_opt_out, k_opt_out);
    [C_in, B_in] = assign(S_k_opt_in, k_opt_in);

end

