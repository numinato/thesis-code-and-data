%% SLC example

% load openflights data set
load('openflights.mat', 'M');

% run SLC
[ C_in, C_out, B_in, B_out ] = slc( M );

% C_in and C_out contain the labels of in- and out-CC-nodeGroups
% B_in{p,q} and B_out{p,q} contain the bridges between the p-th and q-th CC-nodeGroup

% ENJOY !