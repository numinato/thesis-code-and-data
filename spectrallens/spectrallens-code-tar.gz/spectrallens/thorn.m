function [ thorniness ] = thorn( S,p,q,maxdeg,minrho )

    label = labelling(S,p,q,maxdeg,minrho);
    rc = accumarray(label,1);

    tc = sum(rc);
    rc = rc ./ tc;
    if size(rc,1)<3; rc(3) = 0; end;
    thorniness = ( rc(1) + rc(2) ) / ( rc(1) + rc(2) + rc(3) );
end

