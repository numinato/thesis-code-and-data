function [ C, B ] = assign( S, k )

    B = cell(k,k);

    % induce CC-nodeGroups
    C = induce(S);

    for p=1:k

        maxdeg = 5; % theta
        minrho = 1/sqrt(size(S,1));

        for q=p+1:k

            % bridge-ize
            [ labels ] = labelling(S, p, q, maxdeg, minrho);
            B{p,q} = labels == 3 & ( C == p | C == q );

        end

    end

end

