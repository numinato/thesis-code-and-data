function [ k_opt, IC_k_opt  ] = findOptimalK( X )

    k_max = 20;
    all_IC = cell(1,k_max);
    thness = zeros(k_max,1);

    for k=2:k_max

        [IC] = fastica(X(:,1:k)', 'approach', 'symm', 'g', 'skew', 'verbose', 'off');
        IC = IC';
        all_IC{k} = IC;

        maxdeg = 5; % theta
        minrho = 1/sqrt(size(IC,1));

        for p=1:k
            for q=p+1:k
                thness(k) = thness(k) + thorn(IC,p,q,maxdeg,minrho); 
            end
        end

        thness(k) = thness(k) / ((k^2-k)/2);

    end
    [~,idx] = max(thness);

    k_opt = idx;

    IC_k_opt = all_IC{k_opt};

end

