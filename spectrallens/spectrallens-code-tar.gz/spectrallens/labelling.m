function [ labels ] = labelling(S, p, q, maxdeg, minrho)

    [theta,rho] = cart2pol(S(:,p),S(:,q));
    thetadeg  = rad2deg(theta);

    % normalize into first quadrant
    thetadeg(thetadeg>90) = - thetadeg(thetadeg>90) + 180; % q2
    thetadeg(thetadeg<-90) = thetadeg(thetadeg<-90) + 180; % q3
    thetadeg(thetadeg<0 & thetadeg>=-90) = -thetadeg(thetadeg<0 & thetadeg>=-90); % q4
    % flip
    thetadeg = - (thetadeg - 90);

    % left = thetadeg >= 90 - maxdeg;
    right = thetadeg <= maxdeg;
    hybrids =  thetadeg < 90 - maxdeg  & thetadeg > maxdeg;
    middle = rho <= minrho;

    labels = ones(size(S,1),1);
    labels(right) = 2;
    labels(hybrids) = 3;
    labels(middle) = 4;

end
