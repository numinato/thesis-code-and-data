package de.lmu.ifi.dbs.fossclu;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;

import org.ejml.ops.MatrixFeatures;
import org.ejml.simple.SimpleMatrix;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import de.lmu.ifi.dbs.fossclu.FosscluMath;

@RunWith(JUnit4.class)
public class FosscluMathTest {

	private final static double EPS = 1.0e-7;
	private SimpleMatrix S, covS, compM;
	private double[] a, b, c1, c2, convab, d, e, convde, meanS, varS, compV, rootPoly, rootPolyRoots;

	@Before
	public void setUp() {

		// Test Matrix S
		S = new SimpleMatrix(3, 3);
		S.set(0, 0, -1);
		S.set(0, 1, 1);
		S.set(0, 2, 2);
		S.set(1, 0, -2);
		S.set(1, 1, 3);
		S.set(1, 2, 1);
		S.set(2, 0, 4);
		S.set(2, 1, 0);
		S.set(2, 2, 3);

		// Covariance matrix for matrix S
		covS = new SimpleMatrix(3, 3);
		covS.set(0, 0, 10.333333333333333);
		covS.set(0, 1, -4.166666666666667);
		covS.set(0, 2, 3.0);
		covS.set(1, 0, -4.166666666666667);
		covS.set(1, 1, 2.33333333333333);
		covS.set(1, 2, -1.5);
		covS.set(2, 0, 3.0);
		covS.set(2, 1, -1.5);
		covS.set(2, 2, 1.0);

		// Mean array for matrix S
		meanS = new double[3];
		meanS[0] = 0.33333333333333;
		meanS[1] = 1.33333333333333;
		meanS[2] = 2.0;

		// Variance array for matrix S
		varS = new double[3];
		varS[0] = 10.33333333333333;
		varS[1] = 2.33333333333333;
		varS[2] = 1.0;

		// Some test array
		a = new double[3];
		a[0] = -1.0;
		a[1] = -2.0;
		a[2] = 4.0;

		// another test array
		b = new double[3];
		b[0] = 1.0;
		b[1] = 3.0;
		b[2] = 0.0;

		c1 = new double[3];
		c1[0] = -0.0;
		c1[1] = -123.33 - 1.0e-12;
		c1[2] = +4.0;

		c2 = new double[3];
		c2[0] = +0.0;
		c2[1] = -123.33;
		c2[2] = +4.0 + 1.0e-10;

		// Convolution of a and b
		convab = new double[5];
		convab[0] = -1.0;
		convab[1] = -5.0;
		convab[2] = -2.0;
		convab[3] = 12.0;
		convab[4] = 0.0;

		// d = [0.33333333333333, -0.66666666666667, 17.5, 0.0, -157.23, -4.0]
		d = new double[6];
		d[0] = 0.33333333333333;
		d[1] = -0.66666666666667;
		d[2] = 17.5;
		d[3] = 0.0;
		d[4] = -157.23;
		d[5] = -4.0;

		// e = [5.0, 55.312, -2.33333333333333]
		e = new double[3];
		e[0] = 5.0;
		e[1] = 55.312;
		e[2] = -2.33333333333333;

		// deconv = [1.666666666666650,15.103999999999797,49.847555555555380,9.695155555555555e+02,-8.269833333333332e+02,-8.716705759999999e+03,1.456219999999995e+02,9.333333333333320]
		convde = new double[8];
		convde[0] = 1.666666666666650;
		convde[1] = 15.103999999999797;
		convde[2] = 49.847555555555380;
		convde[3] = 9.695155555555555e+02;
		convde[4] = -8.269833333333332e+02;
		convde[5] = -8.716705759999999e+03;
		convde[6] = 1.456219999999995e+02;
		convde[7] = 9.333333333333320;

		// companion vector
		compV = new double[4];
		compV[0] = 1;
		compV[1] = -6.0;
		compV[2] = -72.0;
		compV[3] = -27.0;

		// companion matrix of compV
		compM = new SimpleMatrix(3, 3);
		compM.set(0, 0, 6);
		compM.set(0, 1, 72);
		compM.set(0, 2, 27);
		compM.set(1, 0, 1);
		compM.set(2, 1, 1);

		// r = [1 -6 -72 -27]
		rootPoly = new double[4];
		rootPoly[0] = 1.0;
		rootPoly[1] = -6.0;
		rootPoly[2] = -72.0;
		rootPoly[3] = -27.0;

		// [12.122893784632390;-5.734509942225072;-0.388383842407320]
		rootPolyRoots = new double[3];
		rootPolyRoots[0] = 12.122893784632390;
		rootPolyRoots[1] = -5.734509942225072;
		rootPolyRoots[2] = -0.388383842407320;
	}
	
	@Test
	public void norm_usingVector_returnsNorm() {
		assertEquals(Math.sqrt(21.0), FosscluMath.norm(a, 2.0), EPS);
		assertEquals(7.0, FosscluMath.norm(a, 1.0), EPS);
		assertEquals(4.0, FosscluMath.norm(a, Double.POSITIVE_INFINITY), EPS);
		assertEquals(Math.sqrt(10.0), FosscluMath.norm(b, 2.0), EPS);
		assertEquals(Math.sqrt(5950.0), FosscluMath.norm(compV, 2.0), EPS);
	}
	
	@Test
	public void subtract_usingVectorsAB_returnSubtract() {
		double[] expected = {-2.0, -5.0, 4.0};
		assertArrayEquals(expected, FosscluMath.subtract(a, b), EPS);
	}
	
	@Test
	public void dist_usingVectorsAA_returnZero() {
		assertEquals(0.0, FosscluMath.dist(a, a), EPS);
		assertEquals(0.0, FosscluMath.dist(b, b), EPS);
	}
	
	@Test
	public void dist_usingVectorsAB_returnDistance() {
		assertEquals(Math.sqrt(45.0), FosscluMath.dist(a, b), EPS);
		assertEquals(Math.sqrt(45.0), FosscluMath.dist(b, a), EPS);
	}

	@Test
	public void conp_usingVector_returnsCompanionMatrix() {
		assertTrue(MatrixFeatures.isEquals(compM.getMatrix(), FosscluMath.comp(compV).getMatrix(), EPS));
	}

	@Test
	public void conv_usingAB_returnsConvolution() {
		assertArrayEquals(convab, FosscluMath.conv(a, b), EPS);
	}

	@Test
	public void conv_usingBA_returnsConvolution() {
		assertArrayEquals(convab, FosscluMath.conv(b, a), EPS);
	}

	@Test
	public void conv_usingDE_returnsConvolution() {
		assertArrayEquals(convde, FosscluMath.conv(d, e), EPS);
	}

	@Test
	public void conv_usingED_returnsConvolution() {
		assertArrayEquals(convde, FosscluMath.conv(e, d), EPS);
	}

	@Test
	public void cov_usingMatrix_calculatesCovariance() {
		assertTrue(MatrixFeatures.isEquals(covS.getMatrix(), FosscluMath.cov(S).getMatrix(), EPS));
	}

	@Test
	public void cov_usingTwoArrays_calculatesCovariance() {
		assertEquals(-4.166666666666667, FosscluMath.cov(a, b), EPS);
	}

	@Test
	public void cov_usingTwoArraysAndFlag_calculatesCovariance() {
		assertEquals(-2.777777777777778, FosscluMath.cov(a, b, true), EPS);
	}

	@Test
	public void equals_usingTheSameDoubleArray_returnsTrue() {
		assertTrue(FosscluMath.equals(a, a));
	}

	@Test
	public void equals_usingTwoDifferentDoubleArrays_returnsFalse() {
		assertFalse(FosscluMath.equals(a, b));
	}

	@Test
	public void equals_usingTwoNearlyEqualDoubleArrays_returnsTrue() {
		assertTrue(FosscluMath.equals(c1, c2, 1.0e-7));
	}

	@Test
	public void equals_usingTwoNearlyNonEqualDoubleArrays_returnsFalse() {
		assertFalse(FosscluMath.equals(c1, c2, 1.0e-11));
	}

	@Test
	public void eval_usingVectorAAnd0_evaluatesPolynomial() {
		assertEquals(4.0, FosscluMath.eval(a, 0.0), EPS);
	}

	@Test
	public void eval_usingVectorAAnd1_evaluatesPolynomial() {
		assertEquals(1.0, FosscluMath.eval(a, 1.0), EPS);
	}

	@Test
	public void eval_usingVectorAAnd5_evaluatesPolynomial() {
		assertEquals(-31.0, FosscluMath.eval(a, 5.0), EPS);
	}

	@Test
	public void matrix1Norm_usingMatrixS_retunsOneNorm() {
		assertEquals(7.0, FosscluMath.matrix1Norm(S), EPS);
	}

	@Test
	public void max_usingVectorA_calculatesMaximum() {
		assertEquals(4.0, FosscluMath.max(a), EPS);
	}

	@Test
	public void maxPos_usingVectorA_calculatesMaximumPos() {
		assertEquals(2, FosscluMath.maxPos(a));
	}

	@Test
	public void mean_usingMatrix_calculatesColumnMean() {
		assertArrayEquals(meanS, FosscluMath.mean(S), EPS);
	}

	@Test
	public void min_usingVectorA_calculatesMinimum() {
		assertEquals(-2.0, FosscluMath.min(a), EPS);
	}

	@Test
	public void minPos_usingVectorA_calculatesMinimumPos() {
		assertEquals(1, FosscluMath.minPos(a));
	}

	@Test
	public void prod_usingVectorA_calculatesElementProduct() {
		assertEquals(8.0, FosscluMath.prod(a), EPS);
	}

	@Test
	public void prod_usingVectorB_calculatesElementProduct() {
		assertEquals(0.0, FosscluMath.prod(b), EPS);
	}

	@Test
	public void rcond_usingMatrixS_returnsConditionNumber() {
		assertEquals(0.105990783410138, FosscluMath.rcond(S), EPS);
	}

	//	@Test
	//	public void matrix2Norm_usingMatrixS_retunsTheTwoNorm() {
	//		assertEquals(5.192102941625166, FosscluMath.matrix2Norm(S), EPS);
	//	}

	@Test
	public void realroots_usingVector_returnsRealRoots() {
		Arrays.sort(rootPolyRoots);
		double[] res = FosscluMath.realroots(rootPoly);
		Arrays.sort(res);
		assertArrayEquals(rootPolyRoots, res, EPS);
	}

	@Test
	public void sum_usingVectorA_calculatesElementSum() {
		assertEquals(1.0, FosscluMath.sum(a), EPS);
	}

	@Test
	public void sum_usingVectorB_calculatesElementSum() {
		assertEquals(4.0, FosscluMath.sum(b), EPS);
	}

	@Test
	public void var_usingArrayA_calculatesVariance() {
		assertEquals(10.33333333333333, FosscluMath.var(a), EPS);
	}

	@Test
	public void var_usingArrayB_calculatesVariance() {
		assertEquals(2.33333333333333, FosscluMath.var(b), EPS);
	}

	@Test
	public void var_usingMatrix_calculatesVariance() {
		assertArrayEquals(varS, FosscluMath.var(S), EPS);
	}
}
