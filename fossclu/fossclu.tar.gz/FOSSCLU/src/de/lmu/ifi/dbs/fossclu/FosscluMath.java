package de.lmu.ifi.dbs.fossclu;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.ejml.data.Complex64F;
import org.ejml.simple.SimpleEVD;
import org.ejml.simple.SimpleMatrix;

/**
 * A collection of mathematical functions used in FOSSCLU.
 * This collection uses the EJML math library.
 */
public class FosscluMath {

	/**
	 * If the delta between two double values is less than or equal this value, they are considered equal.
	 */
	public final static double EPS_DOUBLE_DELTA = 1.0e-7;

	/**
	 * Adds a scalar to every element of a vector and returns a new vector.
	 * 
	 * @param vector the vector
	 * @param scalar the scalar to be added
	 * @return A newly created array with each element added by the scalar
	 */
	public static double[] add(double[] vector, double scalar) {
		if (vector == null) return null;
		double[] add = new double[vector.length];
		for (int i = 0; i < vector.length; i++) {
			add[i] = vector[i] + scalar;
		}
		return add;
	}

	/**
	 * Elementwise addition of two same-sized arrays.
	 * 
	 * @param vector1 the first vector
	 * @param vector2 the second vector
	 * @return A newly created array containing the sum of each element.
	 */
	public static double[] add(double[] vector1, double[] vector2) {
		if (vector1 == null || vector2 == null || vector1.length != vector2.length) return null;
		double[] add = new double[vector1.length];
		for (int i = 0; i < vector1.length; i++) {
			add[i] = vector1[i] + vector2[i];
		}
		return add;
	}

	/**
	 * Calculates the Frobenius companion matrix of a polynomial given as a vector of coefficients.
	 * 
	 * @param a coefficient vector of the polynomial
	 * @return the companion matrix with -a_i/a_0 in the first row
	 */
	public static SimpleMatrix comp(double[] a) {
		if (a == null) throw new NullPointerException();
		SimpleMatrix S = new SimpleMatrix(a.length - 1, a.length - 1);
		for (int i = 0; i < a.length - 1; i++) {
			S.set(0, i, -1.0 * a[i + 1] / a[0]);
			if (i < a.length - 2) {
				S.set(i + 1, i, 1.0);
			}
		}
		return S;
	}

	/**
	 * Convolves vectors a and b. Algebraically, convolution is the same operation as multiplying the polynomials whose
	 * coefficients are the elements of u and v.
	 * 
	 * @param a first vector
	 * @param b second vector
	 * @return the convolution of a and b
	 */
	public static double[] conv(double[] a, double[] b) {
		double[] c = new double[a.length + b.length - 1];
		for (int k = 1; k <= c.length; k++) {
			int jMin = Math.max(1, k + 1 - b.length);
			int jMax = Math.min(k, a.length);
			double sum = 0;
			for (int j = jMin; j <= jMax; j++) {
				sum += a[j - 1] * b[k - j];
			}
			c[k - 1] = sum;
		}
		return c;
	}

	/**
	 * Calculates the statistical/empirical covariance ("Stichprobenkovarianz") of two statistical variables x and y.

	 * @see <a href="http://de.wikipedia.org/wiki/Stichprobenkovarianz">http://de.wikipedia.org/wiki/Stichprobenkovarianz</a>
	 * 
	 * @param x
	 * @param y
	 * @param flag If true, data will be normalized by x.length instead of x.length-1.
	 * @return
	 */
	public static double cov(double[] x, double[] y) {
		return cov(x, y, false);
	}

	/**
	 * Calculates the statistical/empirical covariance ("Stichprobenkovarianz") of two statistical variables x and y.
	 * 
	 * @see <a href="http://de.wikipedia.org/wiki/Stichprobenkovarianz">http://de.wikipedia.org/wiki/Stichprobenkovarianz</a>
	 * 
	 * @param x
	 * @param y
	 * @param flag If true, data will be normalized by x.length instead of x.length-1.
	 * @return
	 */
	public static double cov(double[] x, double[] y, boolean flag) {
		if (x == null || y == null || x.length == 0 || y.length == 0)
			throw new IllegalArgumentException(
					"There must be at least one statistical series, e.g. x and y must not be empty.");
		if (x.length != y.length) throw new IllegalArgumentException("Both x and y must be of same length.");
		double norm = x.length;
		if (!flag && x.length > 1) {
			norm = x.length - 1.0;
		}
		double meanX = sum(x) / x.length;
		double meanY = sum(y) / x.length;
		double cov = 0;
		for (int i = 0; i < x.length; i++) {
			cov += (x[i] - meanX) * (y[i] - meanY);
		}
		cov = cov / norm;
		return cov;
	}

	/**
	 * For matrix input X, where each row is an observation, and each column is a variable, cov(X) is the covariance
	 * matrix.
	 * 
	 * @param X A matrix where each row is an observation and each column is a variable
	 * @return The corresponding covariance matrix
	 */
	public static SimpleMatrix cov(SimpleMatrix X) {
		SimpleMatrix C = new SimpleMatrix(X.numCols(), X.numCols());
		for (int col1 = 0; col1 < X.numCols(); col1++) {
			for (int col2 = 0; col2 < X.numCols(); col2++) {
				double colCov = covCols(X.extractVector(false, col1), X.extractVector(false, col2));
				C.set(col1, col2, colCov);
			}
		}
		return C;
	}

	/**
	 * Transfers two SimpleMatrix columns to double[] in order to use cov(double[], double[]).
	 * 
	 * @param X
	 * @param Y
	 * @return
	 */
	private static double covCols(SimpleMatrix X, SimpleMatrix Y) {
		double[] x = new double[X.numRows()];
		for (int i = 0; i < X.numRows(); i++) {
			x[i] = X.get(i, 0);
		}
		double[] y = new double[Y.numRows()];
		for (int i = 0; i < Y.numRows(); i++) {
			y[i] = Y.get(i, 0);
		}
		return cov(x, y);
	}
	
	/**
	 * Euclidian distance between two vectors a and b.
	 * @param a
	 * @param b
	 * @return
	 */
	public static double dist(double[] a, double[] b) {
		return norm(subtract(a, b));
	}

	/**
	 * Pointwise multiplication of two equal sized matrices.
	 * 
	 * @param A
	 * @param B
	 * @return
	 */
	public static SimpleMatrix dotMult(SimpleMatrix A, SimpleMatrix B) {
		if (A.numCols() != B.numCols() || A.numRows() != B.numRows())
			throw new IllegalArgumentException("Matrices are not equal.");
		SimpleMatrix C = new SimpleMatrix(A.numRows(), A.numCols());
		for (int row = 0; row < A.numRows(); row++) {
			for (int col = 0; col < A.numCols(); col++) {
				C.set(row, col, A.get(row, col) * B.get(row, col));
			}
		}
		return C;
	}

	/**
	 * Tests if array a and array b are the same, e.g. both arrays have same length and the double values on each
	 * position are equal (whereas equal means their delta is less than or equal {@link EPS_DOUBLE_DELTA}).
	 * 
	 * @param a first double array
	 * @param b second double array
	 * @return true if equal, false otherwise
	 */
	public static boolean equals(double[] a, double[] b) {
		return equals(a, b, EPS_DOUBLE_DELTA);
	}

	/**
	 * Tests if array a and array b are the same, e.g. both arrays have same length and the double values on each
	 * position are equal (whereas equal means their delta is less than or equal the specified value).
	 * 
	 * @param a first double array
	 * @param b second double array
	 * @return true if equal, false otherwise
	 */
	public static boolean equals(double[] a, double[] b, double delta) {
		if (a == null || b == null || a.length != b.length) return false;
		for (int i = 0; i < a.length; i++) {
			if (Math.abs(a[i] - b[i]) > delta) return false;
		}
		return true;
	}

	/**
	 * Evaluates a polynomial given as a big-endian vector. E.g. [1 -6 -72 -27] is the polynomial x^3 -6x^2 -72x -27
	 * 
	 * @param a polynomial given as a big-endian vector
	 * @param x
	 * @return
	 */
	public static double eval(double[] a, double x) {
		double sum = 0;
		for (int i = 0; i < a.length; i++) {
			sum += Math.pow(x, a.length - 1 - i) * a[i];
		}
		return sum;
	}
	
	
	/**
	 * Geometric mean
	 * @param a
	 * @return
	 */
//	public static double geomean(double[] a) {
//		//return powmean(0.0, a);
//	}
	
	/**
	 * Harmonic mean
	 * @param a
	 * @return
	 */
	public static double harmmean(double[] a) {
		return powmean(-1.0, a);
	}
	
	/**
	 * Logarithm to base b
	 * @param x
	 * @param b
	 * @return
	 */
	public static double log(double x, double b) {
		return Math.log(x) / Math.log(b);
	}
	
	/**
	 * Logarithm to the base 2
	 * @param x
	 * @return
	 */
	public static double log2(double x) {
		return log(x, 2.0);
	}

	/**
	 * Returns the matrix 1-norm, e.g. the maximum column sum.
	 * 
	 * @param X the matrix
	 * @return 1-norm of the matrix
	 */
	public static double matrix1Norm(SimpleMatrix X) {
		double[] colsum = new double[X.numCols()];
		double maxColSum = 0;
		for (int colnum = 0; colnum < X.numCols(); colnum++) {
			for (int rownum = 0; rownum < X.numRows(); rownum++) {
				colsum[colnum] += Math.abs(X.get(rownum, colnum));
			}
			if (colsum[colnum] > maxColSum) {
				maxColSum = colsum[colnum];
			}
		}
		return maxColSum;
	}

	/**
	 * Returns the maximum value of an array of double.
	 * 
	 * @param a array of double
	 * @return maximum value
	 */
	public static double max(double[] a) {
		double max = a[0];
		for (int i = 1; i < a.length; i++) {
			if (a[i] > max) {
				max = a[i];
			}
		}
		return max;
	}
	
	public static double max(double[] a, int start, int count) {
		double max = a[start];
		for (int i = start+1; i < start+count; i++) {
			if (a[i] > max) {
				max = a[i];
			}
		}
		return max;
	}

	/**
	 * Returns the minimal value of an array of double.
	 * 
	 * @param a array of double
	 * @return minimum value
	 */
	public static int max(int[] a) {
		int max = a[0];
		for (int i = 1; i < a.length; i++) {
			if (a[i] > max) {
				max = a[i];
			}
		}
		return max;
	}

	/**
	 * Returns the position (row number) of the two most distant points in this matrix.
	 * @param points The points. Each point is a row of the matrix
	 * @return the row positions of the two most distant points
	 */
	public static int[] maxDistantPoints(SimpleMatrix points) {
		int[] maxPos = new int[2];
		double maxDist = 0.0;
		for (int i = 0; i < points.numRows(); i++) {
			for (int j = 0; j < points.numRows(); j++) {
				if (i != j) {
					double dist = dist(simpleRowToDoubleArray(points.extractVector(true, i)),
							simpleRowToDoubleArray(points.extractVector(true, j)));
					if (dist > maxDist) {
						maxDist = dist;
						maxPos[0] = i;
						maxPos[1] = j;
					}
				}
			}
		}
		return maxPos;
	}

	/**
	 * Returns the position of the minimal value of an array of double.
	 * 
	 * @param a array of double
	 * @return position of the minimum value
	 */
	public static int maxPos(double[] a) {
		int maxPos = 0;
		double max = a[0];
		for (int i = 1; i < a.length; i++) {
			if (a[i] > max) {
				max = a[i];
				maxPos = i;
			}
		}
		return maxPos;
	}
	
	/**
	 * Arithmetic mean of a double array
	 * @param a
	 * @return
	 */
	public static double mean(double[] a) {
		return sum(a) / (double)a.length;
	}

	/**
	 * For matrix input X, the mean will be computated as an array of the column means
	 * 
	 * @param X A matrix
	 * @return The array with the column means
	 */
	public static double[] mean(SimpleMatrix X) {
		double rownum = X.numRows();
		double[] means = new double[X.numCols()];
		for (int i = 0; i < means.length; i++) {
			double mean = 0;
			for (int j = 0; j < rownum; j++) {
				mean += X.get(j, i);
			}
			means[i] = mean / (double)rownum;
		}
		return means;
	}

	/**
	 * Returns the minimal value of an array of double.
	 * 
	 * @param a array of double
	 * @return minimum value
	 */
	public static double min(double[] a) {
		double min = a[0];
		for (int i = 1; i < a.length; i++) {
			if (a[i] < min) {
				min = a[i];
			}
		}
		return min;
	}

	/**
	 * Returns the minimal value of an array of double.
	 * 
	 * @param a array of double
	 * @return minimum value
	 */
	public static int min(int[] a) {
		int min = a[0];
		for (int i = 1; i < a.length; i++) {
			if (a[i] < min) {
				min = a[i];
			}
		}
		return min;
	}

	/**
	 * Returns the position of the minimal value of an array of double.
	 * 
	 * @param a array of double
	 * @return position of the minimum value
	 */
	public static int minPos(double[] a) {
		int minPos = 0;
		double min = a[0];
		for (int i = 1; i < a.length; i++) {
			if (a[i] < min) {
				min = a[i];
				minPos = i;
			}
		}
		return minPos;
	}

	/**
	 * Multiplies a scalar to every element of a vector and returns a new vector.
	 * 
	 * @param vector the vector
	 * @param scalar the scalar to be added
	 * @return A newly created array with each element multiplied by the scalar
	 */
	public static double[] mult(double[] vector, double scalar) {
		if (vector == null) return null;
		double[] add = new double[vector.length];
		for (int i = 0; i < vector.length; i++) {
			add[i] = vector[i] * scalar;
		}
		return add;
	}
	
	/**
	 * Multiplies two arrays elementwise
	 * @param a
	 * @param b
	 * @return 
	 */
	public static double[] mult(double[] a, double[] b) {
		if (a == null || b == null)
			throw new IllegalArgumentException("Both arguments must not be null.");
		if (a.length != b.length)
			throw new IllegalArgumentException("Both arguments must have the same length.");
		double[] c = new double[a.length];
		for (int i = 0; i < a.length; i++) {
			c[i] = a[i] * b[i];
		}
		return c;
	}

	/**
	 * Compute normalized mutual Information using true and cluster labels
	 * 
	 * @param trueLabels array with true labels
	 * @param clusterLabels array with cluster labels
	 * @return nmi_value double with normalized mutual information
	 */
	public static double nmi(int[] trueLabels, int[] clusterLabels) {

		if (trueLabels == null || clusterLabels == null)
			throw new IllegalArgumentException("Arguments must not be null.");
		if (trueLabels.length != clusterLabels.length)
			throw new IllegalArgumentException("Both arguments must have the same length.");

		double nmiValue = 0;
		int maxTrueLabelValue = FosscluMath.max(trueLabels);
		int maxClusterLabelValue = FosscluMath.max(clusterLabels);
		int maxLabelValue = Math.max(maxTrueLabelValue, maxClusterLabelValue);

		SimpleMatrix cat = new SimpleMatrix(trueLabels.length, maxLabelValue + 1);
		for (int i = 0; i < trueLabels.length; i++)
			cat.set(i, trueLabels[i], 1);
		SimpleMatrix cls = new SimpleMatrix(maxLabelValue + 1, clusterLabels.length);
		for (int i = 0; i < clusterLabels.length; i++)
			cls.set(clusterLabels[i], i, 1);

		SimpleMatrix cmat = cls.mult(cat);

		SimpleMatrix n_i = sum(false, cmat);
		SimpleMatrix n_j = sum(true, cmat);

		int row = cmat.numRows();
		int col = cmat.numCols();
		SimpleMatrix repmat1 = new SimpleMatrix(row, col);
		for (int i = 0; i < row; i++)
			repmat1.insertIntoThis(i, 0, n_i);
		SimpleMatrix repmat2 = new SimpleMatrix(row, col);
		for (int i = 0; i < row; i++)
			repmat2.insertIntoThis(0, i, n_j);

		SimpleMatrix product = dotMult(repmat1, repmat2);

		ArrayList<Integer> index = new ArrayList<Integer>(product.numRows()*product.numCols());
		for (int i = 0; i < product.numRows()*product.numCols(); i++)
			if (product.get(i) > 0.0)
				index.add(i);
		double n = FosscluMath.sum(cmat);
		for (int i : index)
			product.set(i, n * cmat.get(i) / product.get(i));


		index = new ArrayList<Integer>(product.numRows()*product.numCols());
		for (int i = 0; i < product.numRows()*product.numCols(); i++)
			if (product.get(i) > 0.0)
				index.add(i);
		for (int i : index)
			product.set(i, Math.log(product.get(i)));
		product = dotMult(cmat, product);

		nmiValue = sum(product);


		index = new ArrayList<Integer>(n_i.numRows()*n_i.numCols());
		for (int i = 0; i < n_i.numRows()*n_i.numCols(); i++)
			if (n_i.get(i) > 0.0)
				index.add(i);
		for (int i : index)
			n_i.set(i, n_i.get(i) * Math.log(n_i.get(i) / n));

		index = new ArrayList<Integer>(n_j.numRows()*n_j.numCols());
		for (int i = 0; i < n_j.numRows()*n_j.numCols(); i++)
			if (n_j.get(i) > 0.0)
				index.add(i);
		for (int i : index)
			n_j.set(i, n_j.get(i) * Math.log(n_j.get(i) / n));

		double denominator = Math.sqrt(sum(n_i) * sum(n_j));

		if (Math.abs(denominator) < EPS_DOUBLE_DELTA)
			nmiValue = 0;
		else
			nmiValue = nmiValue / denominator;
		return nmiValue;
	}
	
	/**
	 * Calculates the 2-norm of a vector a.
	 * @param a vector
	 * @return 2-norm of a
	 */
	public static double norm(double[] a) {
		return norm(a, 2.0);
	}

	/**
	 * Calculates the p-norm of a vector a, including the maximum norm.
	 * @param a vector
	 * @param p which norm, i.e. 1 <= p <= Double.POSITIVE_INFINITY
	 * @return p-norm of a
	 */
	public static double norm(double[] a, double p) {
		if (p == Double.POSITIVE_INFINITY) {
			double max = 0.0;
			for (int i = 0; i < a.length; i++) {
				if (Math.abs(a[i]) > max)
					max = a[i];
			}
			return max;
		} else {
			double sum = 0.0;
			for (int i = 0; i < a.length; i++) {
				sum += Math.pow(Math.abs(a[i]), p);
			}
			return Math.pow(sum, 1.0/p);
		}
	}
	
	/**
	 * Returns all values in the array raised to the power of p.
	 * @param e
	 * @param a
	 * @return
	 */
	public static double[] pow(double[] a, double p) {
		double[] res = Arrays.copyOf(a, a.length);
		for (int i = 0; i < res.length; i++)
			res[i] = Math.pow(res[i], p);
		return res;
	}
	
	/**
	 * Power mean / Generalized mean / Hölder mean
	 * @param p
	 * @param a
	 * @return
	 */
	public static double powmean(double p, double[] a) {
		return Math.pow(sum(pow(a, p)) / (double)a.length, 1.0 / p);
	}
	
	/**
	 * Power mean / Generalized mean / Hölder mean weighted
	 * @param p
	 * @param w
	 * @param a
	 * @return
	 */
	public static double powmeanw(double p, double[] w, double[] a) {
		return Math.pow(sum(mult(w, pow(a, p))) / (double)a.length, 1.0 / p);
	}

	/**
	 * Calculates the product of the elements of an array of double.
	 * 
	 * @param x An array of double.
	 * @return The product of the elements of x.
	 */
	public static double prod(double[] x) {
		double prod = 1;
		for (double xs : x) {
			prod = prod * xs;
		}
		return prod;
	}
	
	/**
	 * Get a random permutation of numbers 0 to n-1.
	 * The array is beeing randomized using {@link java.util.Collections.shuffle(List<?>)}.
	 * 
	 * @param n maximum number
	 * @return an array with length n containing every number from 0 to n-1 once and in random order
	 */
	public static int[] randPerm(int n) {
		List<Integer> randList = new ArrayList<Integer>();
		for (int i = 0; i < n; i++)
			randList.add(i);
		java.util.Collections.shuffle(randList);
		int[] rand = new int[n];
		for (int i = 0; i < n; i++)
			rand[i] = randList.get(i);
		return rand;
	}
	
	/**
	 * Get a random permutation of numbers 0 to n-1.
	 * The array is beeing randomized by swapping two random values. This is done {@code swap} times.
	 * 
	 * @param n maximum number
	 * @param swaps the number of swaps used to randomize the array
	 * @return an array with length n containing every number from 0 to n-1 once and in more/less random order
	 */
	public static int[] randPermLight(int n, int swaps) {
		int[] res = new int[n];
		for (int i = 0; i < n; i++)
			res[i] = i;
		Random rand = new Random();
		for (int i = 0; i < swaps; i++) {
			int pos1 = rand.nextInt(n);
			int pos2 = rand.nextInt(n);
			int temp = res[pos1];
			res[pos1] = res[pos2];
			res[pos2] = temp;
		}
		return res;
	}

	/**
	 * Compute reciprocal condition of square matrix in 1-norm.
	 * 
	 * @see http://www.mathworks.de/de/help/dsp/ref/reciprocalcondition.html
	 * @param X square matrix
	 * @return reciprocal condition number
	 */
	public static double rcond(SimpleMatrix X) {
		return 1.0 / (matrix1Norm(X.invert()) * matrix1Norm(X));
	}

	/**
	 * Returns a vector whose elements are the non-complex roots of the polynomial a.
	 * 
	 * @param a the coefficients of a polynomial, ordered in descending powers
	 * @return non-complex roots of the polynomial a
	 */
	public static double[] realroots(double[] a) {
		Complex64F[] eig = roots(a);
		ArrayList<Double> eigdList = new ArrayList<Double>(eig.length);
		for (Complex64F element : eig)
			if (element.isReal()) {
				eigdList.add(element.getReal());
			}
		double[] eigd = new double[eigdList.size()];
		for (int i = 0; i < eigdList.size(); i++) {
			eigd[i] = eigdList.get(i);
		}
		//System.out.println(Arrays.toString(eigd));
		//System.exit(1);
		return eigd;
	}

	/**
	 * Returns a vector whose elements are the roots of the polynomial a.
	 * 
	 * @param a the coefficients of a polynomial, ordered in descending powers
	 * @return roots of the polynomial a
	 */
	public static Complex64F[] roots(double[] a) {
		if (a == null) throw new NullPointerException();
		// TODO strip leading zeros
		// TODO strip trailing zeros but remember them as roots
		//System.out.println(Arrays.toString(a));
		SimpleMatrix S = comp(a);
		//System.out.println(S);
		@SuppressWarnings("rawtypes")
		SimpleEVD evd = S.eig();
		Complex64F[] eig = new Complex64F[evd.getNumberOfEigenvalues()];
		for (int i = 0; i < eig.length; i++) {
			eig[i] = evd.getEigenvalue(i);
		}
		return eig;
	}

	public static double[] simpleColToDoubleArray(SimpleMatrix S) {
		double[] r = new double[S.numRows()];
		for (int i = 0; i < S.numRows(); i++) {
			r[i] = S.get(i, 0);
		}
		return r;
	}

	public static int[] simpleColToIntArray(SimpleMatrix S) {
		int[] r = new int[S.numRows()];
		for (int i = 0; i < S.numRows(); i++) {
			r[i] = (int) S.get(i, 0);
		}
		return r;
	}

	public static double[] simpleRowToDoubleArray(SimpleMatrix S) {
		double[] r = new double[S.numCols()];
		for (int i = 0; i < S.numCols(); i++) {
			r[i] = S.get(0, i);
		}
		return r;
	}

	public static int[] simpleRowToIntArray(SimpleMatrix S) {
		int[] r = new int[S.numCols()];
		for (int i = 0; i < S.numCols(); i++) {
			r[i] = (int) S.get(0, i);
		}
		return r;
	}
	
	/**
	 * Elementwise subtraction of two same-sized arrays.
	 * 
	 * @param a the first vector
	 * @param b the second vector
	 * @return A newly created array containing a - b.
	 */
	public static double[] subtract(double[] a, double[] b) {
		if (a == null || b == null || a.length != b.length) return null;
		double[] sub = new double[a.length];
		for (int i = 0; i < a.length; i++) {
			sub[i] = a[i] - b[i];
		}
		return sub;
	}

	/**
	 * Calculates the sum of the elements of an array of double.
	 * 
	 * @param x An array of double.
	 * @return The sum of the elements of x.
	 */
	public static double sum(double[] x) {
		double sum = 0;
		for (double xs : x) {
			sum = sum + xs;
		}
		return sum;
	}

	/**
	 * Returns the sum of all matrix elements. Is Matlab sum(S(:)).
	 * @param S
	 * @return
	 */
	public static double sum(SimpleMatrix S) {
		double sum = 0;
		for (int i = 0; i < S.numRows() * S.numCols(); i++)
			sum += S.get(i);
		return sum;
	}

	/**
	 * Matlab sum(S, dim)
	 * 
	 * @param sumRows if true, the rows are summed up, otherwise the cols are summed up
	 * @param S
	 * @return
	 */
	public static SimpleMatrix sum(boolean sumRows, SimpleMatrix S) {
		if (sumRows) {
			SimpleMatrix R = new SimpleMatrix(S.numRows(), 1);
			for (int row = 0; row < S.numRows(); row++) {
				for (int col = 0; col < S.numCols(); col++) {
					R.set(row, 0, R.get(row, 0) + S.get(row, col));
				}
			}
			return R;
		} else {
			SimpleMatrix R = new SimpleMatrix(1, S.numCols());
			for (int col = 0; col < S.numCols(); col++) {
				for (int row = 0; row < S.numRows(); row++) {
					R.set(0, col, R.get(0, col) + S.get(row, col));
				}
			}
			return R;
		}
	}
	
	/**
	 * Returns the sum from 1 to n, i.e. 1+2+...+n
	 * @param n
	 * @return 
	 */
	public static int sumGauss(int n) {
		return (n+1) * n / 2;
	}

	/**
	 * For vectors, var(x) returns the variance of the values in x.
	 * 
	 * @param x an array of double
	 * @return the variance of values in x
	 */
	public static double var(double[] x) {
		double norm = x.length;
		if (x.length > 1) {
			norm--;
		}
		double var = 0;
		double xbar = sum(x) / x.length;
		for (double xs : x) {
			double delta = xs - xbar;
			var += delta * delta;
		}
		var = var / norm;
		return var;
	}

	/**
	 * For matrices var(X) is a row vector containing the variance of each column of X.
	 * 
	 * @param X
	 * @return
	 */
	public static double[] var(SimpleMatrix X) {
		double[] var = new double[X.numCols()];
		for (int i = 0; i < X.numCols(); i++) {
			var[i] = varCol(X.extractVector(false, i));
		}
		return var;
	}

	/**
	 * Transfers a SimpleMatrix column to a double[] in order to use var(double[]).
	 * 
	 * @param X
	 * @return
	 */
	private static double varCol(SimpleMatrix X) {
		double[] x = new double[X.numRows()];
		for (int i = 0; i < X.numRows(); i++) {
			x[i] = X.get(i, 0);
		}
		return var(x);
	}

}
