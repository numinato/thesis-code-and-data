package de.lmu.ifi.dbs.fossclu;

public abstract class Options {

    public static final boolean VERBOSE = true;

    // Set INPUT file here
    public static final String MATFILE = "example.mat";
    
    // Set OUTPUT file here
    public static final String RESFILE = "example_result.mat";

    // Choose Interval for k to be analyzed [K_START .. K_END]
    // k : number of clusters
    public static final int K_START = 4;
    public static final int K_END = 5;

    // Set Interval for m to be analyzed [M_START .. M_END]
    // m : number of projected subspace dimensions
    public static final int M_START = 2;
    public static final int M_END = 3;

    // Set the number of internal run:
    // FOSSCLU chooses the best result by using MDL, its internal quality measurement
    // Since FOSSCLU is partly initialization dependend, you can choose a higher number
    // of internal runs if FOSSCLU produces bad results.
    public static final int RUNS = 10;

    // number of initializations
    public static final int NUMBEROFINITS = 3;

    // Should the data be normalized before processing?
    public static final boolean NORMALIZE = false;

    // number of experiments. Note: only last experiment included in result matlab file
    public static final int NUMEXP = 1;

    // parameters for standard EM Clustering
    public static final int CLUSTERER_MAXITER = 100;
    public static final int INIT_MAXITER = 100;
    public static final int EMCL_MAX_ITER = 100;
    public static final int EMCL_GIVEUP = 5;
    public static final int EMCL_MINPTS = 10; // Default = 30
    public static final int EMCL_ITERATIONS_INIT = 10;
    public static final double EMCL_MINVAR = 1e-5;
    public static final double EMCL_MINRCOND = 1e-15;
    public static final double EMCL_CONV_EPS = 1e-5;
    public static final double EMCL_EQU_EPS = 1e-5;

    // Set use of standard weighted EM
    public static final boolean USEWEIGHT = true;

}
