package de.lmu.ifi.dbs.fossclu;

import static de.lmu.ifi.dbs.fossclu.FosscluMath.cov;
import static de.lmu.ifi.dbs.fossclu.FosscluMath.log2;
import static de.lmu.ifi.dbs.fossclu.FosscluMath.mean;
import static de.lmu.ifi.dbs.fossclu.FosscluMath.var;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.ejml.simple.SimpleMatrix;

import de.lmu.ifi.dbs.fossclu.OptimalRigidTransform.OptimalRigidTransformResult;

public class FOSSCLU {

	public FOSSCLU() {}

	public class FosscluEMResult {
		public double cost;
		public double mdl_value;
		public double nmi_value;
		public SimpleMatrix rotPoints;
		public int[] result_labels;
		public boolean failed;

	}

	/**
	 * Overall function, handels clustering
	 * 
	 * @param k number of random points from dataset as cluster centers
	 * @param m number of dimensions
	 * @param dataset  given datamatrix
	 * @return fosscluEMResult Wrapper with values: cost clustering costs
	 *         mdl_value minimum description length nmi_value normalized mutual
	 *         information rotPoints DataMatrix after clustering and ort
	 *         result_labels clustered labels failed boolean for fail/success
	 */

	public FosscluEMResult fosscluEM(int k, int m, SimpleMatrix dataset, int[] labels, int run) {
		if (Options.VERBOSE) System.out.println("Initializing...");
		initClusterResult init = initCluster(k, m, dataset);
		int[] init_labels = init.init_labels;
		double mdl_value = Double.MAX_VALUE;
		boolean failed = false;
		double cost = Double.MAX_VALUE;
		double nmi_value = 0;
		SimpleMatrix rotPoints = null;
		int[] result_labels = null;

		if (init.successful) {
			if (Options.VERBOSE) System.out.println("Clustering...");
			emClusteringResult emCluster = emClustering(k, m, init_labels, dataset);
			cost = emCluster.cost;
			rotPoints = emCluster.rotPoints;
			result_labels = emCluster.result_labels;
			if (emCluster.failed) {
				nmi_value = 0;
				mdl_value = Double.MAX_VALUE;
			} else {
				nmi_value = FosscluMath.nmi(labels, emCluster.result_labels);
				mdl_value = MDL(emCluster.rotPoints, emCluster.result_labels, m, k);
			}
		} else {
			failed = true;
		}

		if (failed) {

			if (init.successful)
				System.out.println("K: " + k + "M: " + m + "RUN: " + run + "CLUSTERING failed!! ####");
			else
				System.out.println("K: " + k + "M: " + m + "RUN: " + run + "INIT of clustering failed!! ##");
			cost = Double.MAX_VALUE;
			mdl_value = Double.MAX_VALUE;
			nmi_value = 0;
			rotPoints = null;
			result_labels = null;
		} else {
			System.out.println("K: " + k + "M: " + m + "RUN: " + run + " okay. (NMI = " + nmi_value + ", MDL = " + mdl_value);
		}

		FosscluEMResult res = new FosscluEMResult();
		res.cost = cost;
		res.failed = failed;
		res.mdl_value = mdl_value;
		res.nmi_value = nmi_value;
		res.result_labels = result_labels;
		res.rotPoints = rotPoints;

		return res;
	}

	private class initClusterResult {
		public int[] init_labels;
		public boolean successful;
	}

	/**
	 * Creates initialization for subcobi clustering using all dimensions and
	 * initial initialization with minimal cost after rotation is chosen
	 * 
	 * @param k number of random points from dataset as cluster centers
	 * @param m number of dimensions
	 * @param dataset given datamatrix
	 * @return
	 */
	private initClusterResult initCluster(int k, int m, SimpleMatrix dataset) {
		int n = dataset.numRows();
		boolean successful = false;
		int[] labels = new int[n];
		int[] init_labels = new int[n];
		double[] distances = new double[k];
		double minCost = Double.MAX_VALUE;

		for (int i = 0; i < 10; i++) {
			boolean clustered = false;
			int fails = 0;
			while (clustered == false && (fails < Options.EMCL_GIVEUP)) {

				int[] indices = FosscluMath.randPerm(n);
				SimpleMatrix centroids = new SimpleMatrix(n, dataset.numCols());

				for (int j = 0; j < k; j++) {
					int pos = indices[j];
					SimpleMatrix row = dataset.extractVector(true, pos);
					for (int rowLoop = 0; rowLoop < dataset.numCols(); rowLoop++)
						centroids.set(j, rowLoop, row.get(0, rowLoop));
				}

				int[] cluster_size = new int[k];
				for (int p = 0; p < n; p++) {
					for (int l = 0; l < k; l++) {
						double dist = 0;
						double dp = 0;
						double ci = 0;
						int dim = dataset.numCols();

						for (int o = 0; o < dim; o++) {
							dp = dataset.get(p, o);
							ci = centroids.get(l, o);
							dist += (dp - ci) * (dp - ci);
						}
						distances[l] = Math.sqrt(dist);
					}

					double labelval = Double.MAX_VALUE;
					int label = 0;
					for (int w = 0; w < k; w++) {
						if (distances[w] < labelval) {
							labelval = distances[w];
							label = w;
						}
					}

					labels[p] = label;
					cluster_size[label] = cluster_size[label] + 1;
				}

				boolean clustertest = true;
				for (int r = 0; r < k; r++) {
					if (cluster_size[r] < Options.EMCL_MINPTS) {
						fails++;
						clustertest = false;
					}
				}

				if (clustertest == true) {
					clustered = true;
					calcCovEmResult covres = calcCovEM(dataset, labels, k);
					int[] clusterSize = covres.clusterSize;
					List<Integer> cluster_size_list = new ArrayList<Integer>();
					for (int element : clusterSize)
						cluster_size_list.add(element);

					OptimalRigidTransform ortEM = new OptimalRigidTransform(n, cluster_size_list);
					OptimalRigidTransformResult ortEMResult = ortEM.getRotationMatrix(covres.allcov, covres.As, m, covres.N);

					if (ortEMResult.getCost() < minCost) {
						minCost = ortEMResult.getCost();
						for (int y = 0; y < labels.length; y++)
							init_labels[y] = labels[y];
						successful = true;
					}
				}
			}
		}

		initClusterResult res = new initClusterResult();
		res.init_labels = init_labels;
		res.successful = successful;
		return res;
	}

	private class calcCovEmResult {
		public List<SimpleMatrix> As;
		public SimpleMatrix allcov;
		public int[] clusterSize;
		public int N;

	}


	/**
	 * Computes the Covariance Matrix for subcobi clustering
	 * 
	 * @param dataset matrix of the data
	 * @param labels array assigning datapoints(rows) to a centroid
	 * @param k number of random points from dataset as cluster centers
	 * @return Covariance Matrix
	 */
	private calcCovEmResult calcCovEM(SimpleMatrix dataset, int[] labels, int k) {
		int dim = dataset.numCols();
		List<SimpleMatrix> As = new ArrayList<SimpleMatrix>();
		int N = labels.length; // = n from init = numrows from dataset
		int[] cluster_size = new int[k];

		for (int i = 0; i < k; i++)
			for (int label : labels)
				if (label == i)
					cluster_size[i] = cluster_size[i] + 1;

		for (int j = 0; j < k; j++) { // getting the Matrix with only points assigned to centroid j
			int numlabels = cluster_size[j];
			SimpleMatrix covAs = new SimpleMatrix(numlabels, dim);
			int cnt = 0;
			int l = 0;
			if (l <= numlabels) {
				for (l = 0; l < N; l++) {
					if (labels[l] == j) {
						int pos = l;
						SimpleMatrix row = dataset.extractVector(true, pos);
						for (int rowLoop = 0; rowLoop < dim; rowLoop++)
							covAs.set(cnt, rowLoop, row.get(0, rowLoop));
						cnt++;
					}
				}
			}

			SimpleMatrix rescov = FosscluMath.cov(covAs);
			As.add(rescov);
		}

		SimpleMatrix allcov = FosscluMath.cov(dataset);
		calcCovEmResult res = new calcCovEmResult();
		res.As = As;
		res.allcov = allcov;
		res.clusterSize = cluster_size;
		res.N = N;
		return res;
	}

	private class emClusteringResult {
		public int[] result_labels;
		public boolean failed;
		public SimpleMatrix rotPoints;
		public double cost;
	}

	/**
	 * Creates subcobi clustering
	 * 
	 * @param k number of random points from dataset as cluster centers
	 * @param m number of dimensions
	 * @param init_labels array with the initial labels
	 * @param points given datamatrix
	 * @return emClusteringResult with values: cost clustering costs rotPoints
	 *         DataMatrix after clustering and ort result_labels clustered
	 *         labels failed boolean for fail/success
	 */
	private emClusteringResult emClustering(int k, int m, int[] init_labels, SimpleMatrix dataset) {
		SimpleMatrix rotPoints = dataset.copy();
		double cost = Double.MAX_VALUE;
		int n = dataset.numRows();
		int[] clustResult = new int[init_labels.length];
		for (int i = 0; i < init_labels.length; i++)
			clustResult[i] = init_labels[i];

		int[] clustResult_old = new int[init_labels.length];
		int iter = 0;

		boolean failed = false;
		boolean useweightedEM; // no global constant usable, gets changed

		while (!Arrays.equals(clustResult, clustResult_old) && !failed) {
			iter++;
			for (int i = 0; i < init_labels.length; i++)
				clustResult_old[i] = clustResult[i];

			if (Options.USEWEIGHT) {
				if (iter < 10)
					useweightedEM = false;
				else
					useweightedEM = true;
			} else {
				useweightedEM = false;
			}

			calcCovEmResult covres = calcCovEM(rotPoints, clustResult, k);

			boolean smallclu = false;
			int[] clusterSize = covres.clusterSize;
			for (int element : clusterSize) {
				if (element < 5)
					smallclu = true;
			}
			
			if (smallclu) {
				failed = true;
				emClusteringResult res = new emClusteringResult();
				res.failed = failed;
				return res;
			}

			List<Integer> cluster_size_list = new ArrayList<Integer>();
			for (int element : covres.clusterSize)
				cluster_size_list.add(element);

			OptimalRigidTransform ortEM = new OptimalRigidTransform(n, cluster_size_list);
			OptimalRigidTransformResult ortEMResult = ortEM.getRotationMatrix(covres.allcov, covres.As, m, covres.N);
			cost = ortEMResult.getCost();

			boolean ortFailed = ortEMResult.getFailed();
			if (ortFailed) {
				failed = true;
				emClusteringResult res = new emClusteringResult();
				res.failed = failed;
				return res;
			}

			SimpleMatrix V = ortEMResult.getV();
			rotPoints = V.transpose().mult(rotPoints.transpose());
			rotPoints = rotPoints.transpose();
			SimpleMatrix rotpointm = new SimpleMatrix(n, m);

			for (int l = 0; l < m; l++) {
				SimpleMatrix col = rotPoints.extractVector(false, l);
				for (int colLoop = 0; colLoop < n; colLoop++)
					rotpointm.set(colLoop, l, col.get(colLoop, 0));
			}

			EmClusteringStepResult clustResultObj = emClusteringStep(rotpointm, clustResult, k, useweightedEM);
			clustResult = clustResultObj.labels;
			failed = clustResultObj.failed;
		}

		if (!failed && !Arrays.equals(clustResult, clustResult_old) && Options.VERBOSE)
			System.out.println("Clusterung DOES NOT CONVERGE after " + iter + " Iterations");

		emClusteringResult res = new emClusteringResult();
		res.failed = failed;
		res.result_labels = clustResult;
		res.rotPoints = rotPoints;
		res.cost = cost;
		return res;
	}

	private class EmClusteringStepResult {
		int[] labels;
		boolean failed;
	}

	/**
	 * Creates subcobi clustering
	 * 
	 * @param k number of random points from dataset as cluster centers
	 * @param labels array where points are assigned to centroids
	 * @param points given datamatrix
	 * @param useweightedEM
	 * @return labels array with new labels
	 */
	private EmClusteringStepResult emClusteringStep(SimpleMatrix points, int[] labels, int k, boolean useweightedEM) {
		int[] cluster_size_result = new int[k];
		boolean sparse_clusters = false;
		int n = points.numRows();
		int m = points.numCols();

		// MAXIMIZATION STEP
		int[] clusterSizes = new int[k];
		for (int i = 0; i < k; i++)
			for (double label : labels)
				if (label == i)
					clusterSizes[i]++;

		SimpleMatrix clusterMeans = new SimpleMatrix(k, m);
		for (int i = 0; i < k; i++) {
			SimpleMatrix cluster = new SimpleMatrix(clusterSizes[i], m);
			int cnt = 0;
			for (int w = 0; w < n; w++) {
				if (labels[w] == i) {
					SimpleMatrix row = points.extractVector(true, w);
					for (int rowLoop = 0; rowLoop < m; rowLoop++)
						cluster.set(cnt, rowLoop, row.get(0, rowLoop));
					cnt++;
				}
			}
			double[] mean = FosscluMath.mean(cluster);
			for (int j = 0; j < m; j++) {
				clusterMeans.set(i, j, mean[j]);
			}
		}

		List<SimpleMatrix> covariances = new ArrayList<SimpleMatrix>();
		for (int j = 0; j < k; j++) { // getting the Matrix with only points assigned to centroid j
			SimpleMatrix covariance = new SimpleMatrix(clusterSizes[j], m);
			int cnt = 0;
			for (int l = 0; l < n; l++) {
				if (labels[l] == j) {
					int pos = l;
					SimpleMatrix row = points.extractVector(true, pos);
					for (int rowLoop = 0; rowLoop < m; rowLoop++)
						covariance.set(cnt, rowLoop, row.get(0, rowLoop));
					cnt++;
				}
			}
			SimpleMatrix rescov = FosscluMath.cov(covariance);
			if (FosscluMath.rcond(rescov) < Options.EMCL_MINRCOND) {
				System.out.println("## sparse cluster(s), RCond = " + FosscluMath.rcond(rescov));
				sparse_clusters = true;
				EmClusteringStepResult res = new EmClusteringStepResult();
				res.labels = labels;
				res.failed = sparse_clusters;
				return res;
			}
			covariances.add(rescov);
		}

		double[] factor1 = new double[k];
		for (int i = 0; i < covariances.size(); i++)
			factor1[i] = 1.0 / Math.sqrt(Math.pow(2.0 * Math.PI, m) * covariances.get(i).determinant());

		// EXPECTATION STEP
		double[] clusterCosts = new double[k];

		for (int p = 0; p < n; p++) {
			for (int i = 0; i < k; i++) {
				SimpleMatrix diff = points.extractVector(true, p).minus(clusterMeans.extractVector(true, i));
				SimpleMatrix cov = covariances.get(i);
				cov = cov.invert();
				SimpleMatrix difft = diff.transpose();
				SimpleMatrix exponent = diff.mult(cov).mult(difft);
				clusterCosts[i] = factor1[i] * Math.exp(-0.5 * exponent.get(0, 0));
				if (useweightedEM) //there's no options.subcobi.useWeightedEM in main.m
					clusterCosts[i] = -(Math.log(clusterSizes[i] * clusterCosts[i]) / Math.log(2.0));
				else
					clusterCosts[i] = -(Math.log(clusterCosts[i]) / Math.log(2.0));
			}
			double mincost = Double.MAX_VALUE;
			int mincostcent = 0;
			for (int y = 0; y < clusterCosts.length; y++) {
				if (mincost > clusterCosts[y]) {
					mincost = clusterCosts[y];
					mincostcent = y;
				}
			}
			labels[p] = mincostcent;
			cluster_size_result[labels[p]]++;
		}

		for (int element : cluster_size_result) {
			if (element == 0) {
				sparse_clusters = true;
				System.out.println("EMPTY CLUSTER(S)..");
			}
		}

		EmClusteringStepResult res = new EmClusteringStepResult();
		res.labels = labels;
		res.failed = sparse_clusters;
		return res;
	}

	/**
	 * Minimum description length
	 * @param labels array where points assigned to centroids
	 * @param dimclus number of dimensions
	 * @param data given datamatrix
	 * @param k number of clusters
	 * @return mdl_value minimumdiscription length
	 */
	public static double MDL(SimpleMatrix data, int[] labels, int dimclus, int k) {

		// count labels
		int[] labels_cnt = new int[k];
		for (int i = 0; i < labels.length; i++)
			labels_cnt[labels[i]]++;
		
		int labels_num = 0;
		for (int i = 0; i < k; i++)
			if (labels_cnt[i] != 0)
				labels_num++;

		int[] labels_unique = new int[labels_num];
		int[] labels_iter = new int[labels_num];

		int lcnt = 0;
		for (int i = 0; i < k; i++) {
			if (labels_cnt[i] != 0) {
				labels_unique[lcnt] = labels_cnt[i];
				labels_iter[lcnt] = i;
				lcnt++;
			}
		}

		// cluster cost
		int n = data.numRows();
		int dim = data.numCols();
		double ccost = 0.5 * 0.5 * dim * (dim - 1.0) * log2(n);

		for (int i = 0; i < labels_iter.length; i++) {

			SimpleMatrix clusterPoints = new SimpleMatrix(labels_unique[i], dimclus);
			int cnt = 0;
			for (int p = 0; p < n; p++) {
				if (labels[p] == labels_iter[i]) {
					SimpleMatrix row = data.extractVector(true, p);
					for (int rowLoop = 0; rowLoop < dimclus; rowLoop++)
						clusterPoints.set(cnt, rowLoop, row.get(0, rowLoop));
					cnt++;
				}
			}
			
			int clusterSize = clusterPoints.numRows();
			SimpleMatrix covariance = cov(clusterPoints);
			double[] clusterMean = mean(clusterPoints);
			
			for (int j = 0; j < clusterSize; j++) {
				double c = 1.0 / Math.sqrt(Math.pow((2.0 * Math.PI), dimclus) * covariance.determinant());

				SimpleMatrix clusterMean2 = new SimpleMatrix(1, clusterMean.length);
				for (int g = 0; g < clusterMean.length; g++)
					clusterMean2.set(0, g, clusterMean[g]);

				SimpleMatrix diff = clusterPoints.extractVector(true, j).minus(clusterMean2);
				SimpleMatrix exponent = diff.mult(covariance.invert()).mult(diff.transpose());

				double exp = -0.5 * exponent.get(0, 0);
				c = c * Math.exp(exp);
				c = ((double)clusterSize / (double)n) * c;

				ccost = ccost - log2(c);
			}
			
			ccost = ccost + 0.5 * dimclus * log2(clusterSize);
			ccost = ccost + dimclus * (dimclus + 1.0) / 4.0 * log2(n);
			
		}
		
		
		// noise cost
		SimpleMatrix noise = new SimpleMatrix(data.numRows(), dim - dimclus);
		for (int i = 0; i < data.numRows(); i++) {
			SimpleMatrix row = data.extractVector(true, i);
			int cnt = 0;
			for (int j = dimclus; j < data.numCols(); j++) {
				noise.set(i, cnt, row.get(0, j));
				cnt++;
			}
		}

		double[] meanN = mean(noise);
		double[] varN = var(noise);
		for (int i = 0; i < n; i++) {
			double[] x = new double[noise.numCols()];
			for (int y = 0; y < noise.numCols(); y++)
				x[y] = noise.get(i, y);

			double p_prod = 1.0;
			for (int m = 0; m < dim - dimclus; m++) {
				double p = (1.0 / Math.sqrt(2.0 * Math.PI * varN[m]))
						* Math.exp(-0.5 * Math.pow(x[m] - meanN[m], 2.0) / varN[m]);
				if (Math.abs(p) > 1e-7)
					p_prod = p_prod * p;
			}
			ccost = ccost + log2(1.0 / p_prod);
		}
		ccost = ccost + 0.5 * 2.0 * (dim - dimclus) * log2(n);

		return ccost;
	}

}
