package de.lmu.ifi.dbs.fossclu;

import java.util.ArrayList;

import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.OpenMapRealMatrix;
import org.apache.commons.math3.linear.RealMatrix;

/**
 * A collection of mathematical functions used in FOSSCLU.
 * This part of the collection uses the Apache Commons Math Library.
 */
public class FosscluMathCommons {

	public final static double EPS_DOUBLE_DELTA = 1.0e-7;

	/**
	 * Calculates the Frobenius companion matrix of a polynomial given as a vector of coefficients.
	 * 
	 * @param a coefficient vector of the polynomial
	 * @return the companion matrix with -a_i/a_0 in the first row
	 */
	private static RealMatrix comp(double[] a) {
		OpenMapRealMatrix S = new OpenMapRealMatrix(a.length - 1, a.length - 1);
		for (int i = 0; i < a.length - 1; i++) {
			S.setEntry(0, i, -1.0 * a[i + 1] / a[0]);
			if (i < a.length - 2) {
				S.setEntry(i + 1, i, 1.0);
			}
		}
		return S;
	}

	/**
	 * Returns a vector whose elements are the eigenvalues of the matrix S.
	 * 
	 * @param S
	 * @return eigenvalues of S
	 */
	private static double[] realeig(RealMatrix S) {
		EigenDecomposition e = new EigenDecomposition(S);
		double[] reals = e.getRealEigenvalues();
		double[] imags = e.getImagEigenvalues();
		ArrayList<Double> realEig = new ArrayList<Double>();
		for (int i = 0; i < reals.length; i++)
			if (Math.abs(imags[i]) < EPS_DOUBLE_DELTA) {
				realEig.add(reals[i]);
			}
		double[] ret = new double[realEig.size()];
		for (int i = 0; i < realEig.size(); i++) {
			ret[i] = realEig.get(i);
		}
		return ret;
	}

	/**
	 * Returns a vector whose elements are the non-complex roots of the polynomial a.
	 * 
	 * @param a the coefficients of a polynomial, ordered in descending powers
	 * @return non-complex roots of the polynomial a
	 */
	public static double[] realroots(double[] a) {
		RealMatrix S = comp(a);
		//System.out.println(S);
		double[] ret = realeig(S);
		//System.out.println(Arrays.toString(ret));
		//System.exit(1);
		return ret;
	}

}
