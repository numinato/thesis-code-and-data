package de.lmu.ifi.dbs.fossclu;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import org.ejml.simple.SimpleMatrix;

import static de.lmu.ifi.dbs.fossclu.FosscluMath.*;

public class OptimalRigidTransform {
	/**
	 * If the difference between two double values is smaller than DOUBLE_EPS,
	 * they are considered equal.
	 */
	public static final double DOUBLE_EPS = 1e-5;

	public static final double ORT_CONVERGENCE_EPS = 1e-5;
	public static final int ORT_ITERATIONS_MAX = 100;
	public static final int ORT_ROTATE2D_ITERATIONS_MAX = 10000;

	private double dcost = Double.POSITIVE_INFINITY;
	private double cost = 1.0;
	private List<Integer> clusterSize;
	//private int numLabels;


	/**
	 * Constructor in order to create an Optimal Rigid Transform.
	 * 
	 * @param numLabels
	 * @param clusterSize
	 */
	public OptimalRigidTransform(int numLabels, List<Integer> clusterSize) {
		this.clusterSize = clusterSize;
		//this.numLabels = numLabels;
	}

	/**
	 * Performs an optimal rigid transform using a set of cluster specific
	 * determinant matrices and the overall determinant matrix, i.e. find an
	 * angle such that the cost is minimized.
	 * 
	 * @param overallDeterminant The overall determinant matrix
	 * @param singleClusterDeterminats A list of single cluster determinant matrices
	 * @return An angle with minimal cost or Double.MAX_VALUE if the function fails.
	 */
	private double rotate2D(SimpleMatrix overallDeterminant, List<SimpleMatrix> singleClusterDeterminats) {

		double[] a = new double[singleClusterDeterminats.size() + 1];
		double[] b = new double[singleClusterDeterminats.size() + 1];
		double[] c = new double[singleClusterDeterminats.size() + 1];
		a[0] = overallDeterminant.get(0, 0);
		b[0] = overallDeterminant.get(0, 1);
		c[0] = overallDeterminant.get(1, 1);

		for (int i = 0; i < singleClusterDeterminats.size(); i++) {
			a[i + 1] = singleClusterDeterminats.get(i).get(1, 1);
			b[i + 1] = -1.0 * singleClusterDeterminats.get(i).get(0, 1);
			c[i + 1] = singleClusterDeterminats.get(i).get(0, 0);
		}

		int[] n = new int[singleClusterDeterminats.size() + 1];
		for (int i = 1; i < singleClusterDeterminats.size() + 1; i++) {
			n[i] = clusterSize.get(i - 1);
			n[0] += clusterSize.get(i - 1);
		}

		double theta = ortFunctionMinPolynomialMultiplication(a, b, c, n, singleClusterDeterminats.size());
		cost = ortFunction(theta, a, b, c, n);

		return theta;
	}

	/**
	 * An implementation of the Optimal Rigid Tranform Function. The minimum of
	 * this function is used in an ORT.
	 * 
	 * @param x The rotation angle to be minimized
	 * @param a A combination of the overall determinant and the single cluster determinants, part a
	 * @param b A combination of the overall determinant and the single cluster determinants, part b
	 * @param c A combination of the overall determinant and the single cluster determinants, part c
	 * @param n Number of single clusters in the first component, cluster size of the single cluster in the other components.
	 * @return Cost that needs to be minimized.
	 */
	private double ortFunction(double x, double[] a, double[] b, double[] c, int[] n) {
		// f = @(x) prod(( a .* (sin(x)).^2 + 2 .* b .* sin(x) .* cos(x) + c .* (cos(x)).^2).^(n/n(1)));
		double result = 1.0;
		for (int i = 0; i < a.length; i++) {
			double row = a[i] * Math.sin(x) * Math.sin(x) + 2 * b[i] * Math.sin(x) * Math.cos(x) + c[i] * Math.cos(x)
					* Math.cos(x);
			row = Math.pow(row, ((double) n[i]) / ((double) n[0]));
			result *= row;
		}
		return result;
	}

	private double ortFunctionMinPolynomialMultiplication(double[] a, double[] b, double[] c, int[] n, int k) {
		// METHOD USING POLYNOMIAL MULTIPLICATION ONLY
		// precomputing first polynomial
		double[][] poly1 = new double[k + 1][];
		poly1[0] = new double[1];
		poly1[0][0] = 1.0;
		for (int i = 1; i < k + 1; i++) {
			double[] abc = new double[3];
			abc[0] = a[i - 1];
			abc[1] = b[i - 1] * 2.0;
			abc[2] = c[i - 1];
			poly1[i] = conv(poly1[i - 1], abc);
		}

		// precomputing second polynomial
		double[][] poly2 = new double[k + 1][];
		poly2[k] = new double[1];
		poly2[k][0] = 1;
		for (int i = k - 1; i >= 0; i--) {
			double[] abc = new double[3];
			abc[0] = a[i + 1];
			abc[1] = b[i + 1] * 2.0;
			abc[2] = c[i + 1];
			poly2[i] = conv(poly2[i + 1], abc);
		}

		// computing polynomial
		double[][] p = new double[k + 1][];
		for (int i = 0; i < k + 1; i++) {
			double[] abc = new double[3];
			abc[0] = -1.0 * n[i] * b[i];
			abc[1] = n[i] * a[i] - n[i] * c[i];
			abc[2] = n[i] * b[i];
			p[i] = conv(poly1[i], poly2[i]);
			p[i] = conv(p[i], abc);
		}

		int[] pLen = new int[p.length];
		for (int i = 0; i < p.length; i++) {
			pLen[i] = p[i].length;
		}
		
		int len = max(pLen);
		double[][] pArray = new double[k + 1][];
		for (int i = 0; i < k + 1; i++) {
			pArray[i] = new double[len];
			for (int j = len - p[i].length; j < len; j++) {
				pArray[i][j] = p[i][j - (len - p[i].length)];
			}
		}

		double[] r = new double[len];
		for (int i = 0; i < len; i++) {
			double sum = 0;
			for (int j = 0; j < k + 1; j++) {
				sum += pArray[j][i];
			}
			r[i] = sum;
		}

		double[] rts;
		rts = de.lmu.ifi.dbs.fossclu.FosscluMathCommons.realroots(r); // we use Apache Commons Math here since EJML sometimes fails to do the Eigendecomposition 

		for (int i = 0; i < rts.length; i++)
			rts[i] = Math.atan(rts[i]);
		double[] values = new double[rts.length];
		for (int i = 0; i < rts.length; i++)
			values[i] = this.ortFunction(rts[i], a, b, c, n);
		cost = min(values);
		double theta = rts[minPos(values)];

		return theta;
	}

	private SimpleMatrix getSwappingMatrix(int dim, int p, int q) {
		SimpleMatrix swappingMatrix = SimpleMatrix.identity(dim);
		swappingMatrix.set(p, p, 0.0);
		swappingMatrix.set(q, q, 0.0);
		swappingMatrix.set(p, q, 1.0);
		swappingMatrix.set(q, p, 1.0);
		return swappingMatrix;
	}

	private List<SimpleMatrix> getSingleClusterDeterminatMatrices(SimpleMatrix projectionMatrixClustered,
			List<SimpleMatrix> singleClusterCovarianceMatrices, SimpleMatrix swappingMatrix) {
		// TODO: code is not efficient, since a new matrix is created on each multiplication
		// Dets_As = zeros(k,2,2);
		List<SimpleMatrix> singleClusterDeterminats = new ArrayList<SimpleMatrix>(
				singleClusterCovarianceMatrices.size());
		SimpleMatrix tempMatrix;
		double tempDeterminant;
		for (int i = 0; i < singleClusterCovarianceMatrices.size(); i++) {
			SimpleMatrix singleCluDetMatrix = new SimpleMatrix(2, 2);
			// Dets_As(i,1,1) = det(P_clustered' * A * P_clustered);
			tempMatrix = projectionMatrixClustered.transpose();
			tempMatrix = tempMatrix.mult(singleClusterCovarianceMatrices.get(i));
			tempMatrix = tempMatrix.mult(projectionMatrixClustered);
			tempDeterminant = tempMatrix.determinant();
			singleCluDetMatrix.set(0, 0, tempDeterminant);
			// Dets_As(i,1,2) = det(P_clustered' * S_pq * A * P_clustered);
			tempMatrix = projectionMatrixClustered.transpose();
			tempMatrix = tempMatrix.mult(swappingMatrix);
			tempMatrix = tempMatrix.mult(singleClusterCovarianceMatrices.get(i));
			tempMatrix = tempMatrix.mult(projectionMatrixClustered);
			tempDeterminant = tempMatrix.determinant();
			singleCluDetMatrix.set(0, 1, tempDeterminant);
			// Dets_As(i,2,1) = Dets_As(k,1,2);
			// TODO: Matlab code is "k", not "i". Seems strange.
			singleCluDetMatrix.set(1, 0, tempDeterminant);
			// Dets_As(i,2,2) = det(P_clustered' * S_pq * A * S_pq * P_clustered);
			tempMatrix = projectionMatrixClustered.transpose();
			tempMatrix = tempMatrix.mult(swappingMatrix);
			tempMatrix = tempMatrix.mult(singleClusterCovarianceMatrices.get(i));
			tempMatrix = tempMatrix.mult(swappingMatrix);
			tempMatrix = tempMatrix.mult(projectionMatrixClustered);
			tempDeterminant = tempMatrix.determinant();
			singleCluDetMatrix.set(1, 1, tempDeterminant);
			singleClusterDeterminats.add(singleCluDetMatrix);
		}
		return singleClusterDeterminats;
	}

	private SimpleMatrix getOverallDeterminantMatrix(SimpleMatrix projectionMatrixUnclustered,
			SimpleMatrix overallCovarianceMatrix, SimpleMatrix swappingMatrix) {
		// TODO: code is not efficient, since a new matrix is created on each multiplication
		// Dets_B = zeros(2);
		SimpleMatrix overallDeterminant = new SimpleMatrix(2, 2);
		SimpleMatrix tempMatrix;
		double tempDeterminant;
		// Dets_B(1,1) = det(P_unclustered' * S_pq * B * S_pq * P_unclustered);
		tempMatrix = projectionMatrixUnclustered.transpose();
		tempMatrix = tempMatrix.mult(swappingMatrix);
		tempMatrix = tempMatrix.mult(overallCovarianceMatrix);
		tempMatrix = tempMatrix.mult(swappingMatrix);
		tempMatrix = tempMatrix.mult(projectionMatrixUnclustered);
		tempDeterminant = tempMatrix.determinant();
		overallDeterminant.set(0, 0, tempDeterminant);
		// Dets_B(1,2) = det(P_unclustered' * S_pq * B * P_unclustered);
		tempMatrix = projectionMatrixUnclustered.transpose();
		tempMatrix = tempMatrix.mult(swappingMatrix);
		tempMatrix = tempMatrix.mult(overallCovarianceMatrix);
		tempMatrix = tempMatrix.mult(projectionMatrixUnclustered);
		tempDeterminant = tempMatrix.determinant();
		overallDeterminant.set(0, 1, tempDeterminant);
		// Dets_B(2,1) = Dets_B(1,2);
		overallDeterminant.set(1, 0, tempDeterminant);
		// Dets_B(2,2) = det(P_unclustered'* B * P_unclustered);
		tempMatrix = projectionMatrixUnclustered.transpose();
		tempMatrix = tempMatrix.mult(overallCovarianceMatrix);
		tempMatrix = tempMatrix.mult(projectionMatrixUnclustered);
		tempDeterminant = tempMatrix.determinant();
		overallDeterminant.set(1, 1, tempDeterminant);
		return overallDeterminant;
	}

	private SimpleMatrix getRotationMatrix(int dim, int p, int q, double phi) {
		double c = Math.cos(phi);
		double s = Math.sin(phi);
		SimpleMatrix rotationMatrix = SimpleMatrix.identity(dim);
		rotationMatrix.set(p, p, c);
		rotationMatrix.set(q, q, c);
		rotationMatrix.set(p, q, s);
		rotationMatrix.set(q, p, -s);
		return rotationMatrix;
	}

	/**
	 * Performs an Optimal Rigid Transform and returns the matrix of rotated base vectors.
	 * 
	 * @param overallCovarianceMatrix The overall covariance matrix corresponding to the noise part.
	 * @param singleClusterCovarianceMatrices A list of covariance matrices corresponding to the single clusters.
	 * @param subspaceDimensions The number of subspace dimensions.
	 * @return The matrix of rotated base vectors.
	 */
	public OptimalRigidTransformResult getRotationMatrix(SimpleMatrix overallCovarianceMatrix,
			List<SimpleMatrix> singleClusterCovarianceMatrices, int subspaceDimensions, int N) {

		boolean failed = false;
		int overallCovDim = overallCovarianceMatrix.numCols();
		int numSingleClusters = singleClusterCovarianceMatrices.size();
		SimpleMatrix V = SimpleMatrix.identity(overallCovDim);
		SimpleMatrix tempUpperClustered = SimpleMatrix.identity(subspaceDimensions);
		SimpleMatrix tempLowerClustered = new SimpleMatrix(overallCovDim - subspaceDimensions, subspaceDimensions);
		SimpleMatrix projectionMatrixClustered = tempUpperClustered.combine(subspaceDimensions, 0, tempLowerClustered);
		SimpleMatrix tempUpperUnclustered = new SimpleMatrix(subspaceDimensions, overallCovDim - subspaceDimensions);
		SimpleMatrix tempLowerUnclustered = SimpleMatrix.identity(overallCovDim - subspaceDimensions);
		SimpleMatrix projectionMatrixUnclustered = tempUpperUnclustered.combine(subspaceDimensions, 0,
				tempLowerUnclustered);

		int iterationsDone = 0;
		dcost = Double.MAX_VALUE;
		cost = 1.0;

		for (int i = 0; i < numSingleClusters; i++)
			cost = cost * Math.pow(singleClusterCovarianceMatrices.get(i).extractMatrix(0, subspaceDimensions, 0, subspaceDimensions).determinant(), clusterSize.get(i) / N);
		if (subspaceDimensions < overallCovDim)
			cost = cost * overallCovarianceMatrix.extractMatrix(subspaceDimensions, overallCovDim, subspaceDimensions, overallCovDim).determinant();

		while (dcost / cost > ORT_CONVERGENCE_EPS && iterationsDone <= ORT_ITERATIONS_MAX) {
			iterationsDone++;
			double cost_old = cost;
			for (int p = 0; p < subspaceDimensions; p++) {
				for (int q = subspaceDimensions; q < overallCovDim; q++) {

					SimpleMatrix swappingMatrix = getSwappingMatrix(overallCovDim, p, q);
					List<SimpleMatrix> singleClusterDeterminatMatrices = getSingleClusterDeterminatMatrices(projectionMatrixClustered, singleClusterCovarianceMatrices, swappingMatrix);
					SimpleMatrix overallDeterminantMatrix = getOverallDeterminantMatrix(projectionMatrixUnclustered, overallCovarianceMatrix, swappingMatrix);

					double phi = Double.MAX_VALUE;
					try {
						phi = rotate2D(overallDeterminantMatrix, singleClusterDeterminatMatrices);
					} catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
						System.out.println("[FAIL][ort] eigen decomposition did not converge");
						failed = true;
						return new OptimalRigidTransformResult(V, cost, failed);
					}

					if (Double.MAX_VALUE - phi < DOUBLE_EPS) {
						System.out.println("[FAIL][ort] phi == Double.MAX_VALUE");
						failed = true;
						return new OptimalRigidTransformResult(V, cost, failed);
					}

					SimpleMatrix rotationMatrix = getRotationMatrix(overallCovDim, p, q, phi);
					V = V.mult(rotationMatrix);

					// Apply rotation to the covariance matrices
					// TODO: code is not efficient, since a new matrix is created on each multiplication
					ListIterator<SimpleMatrix> it = singleClusterCovarianceMatrices.listIterator();
					while (it.hasNext()) {
						SimpleMatrix singleCluCovMatrix = it.next();
						singleCluCovMatrix = rotationMatrix.transpose().mult(singleCluCovMatrix).mult(rotationMatrix);
						it.set(singleCluCovMatrix);
					}
					overallCovarianceMatrix = rotationMatrix.transpose().mult(overallCovarianceMatrix)
							.mult(rotationMatrix);
				}
			}
			dcost = Math.abs(cost - cost_old);
		}
		return new OptimalRigidTransformResult(V, cost, failed);
	}

	public class OptimalRigidTransformResult {
		private SimpleMatrix V;
		private double cost;
		private boolean failed;

		public OptimalRigidTransformResult(SimpleMatrix V, double cost, boolean failed) {
			this.V = V;
			this.cost = cost;
			this.failed = failed;
		}

		public SimpleMatrix getV() {
			return V;
		}

		public double getCost() {
			return cost;
		}

		public boolean getFailed() {
			return failed;
		}
	}
}
