package de.lmu.ifi.dbs.fossclu;

import org.ejml.simple.SimpleMatrix;

import de.lmu.ifi.dbs.fossclu.FOSSCLU.FosscluEMResult;

public class RunSubcobiClusterer {

	public class RunSubcobiClustererResult {
		public int best_k;
		public int best_m;
		public double nmi_value;
		public SimpleMatrix best_rotPoints;
		public int[] best_result_labels;
	}

	/**
	 * Runs fosscluEM for each m and k given
	 *
	 * @param k_testInterval search interval for best k
	 * @param m_testInterval search interval for best m
	 * @param dataset given data matrix
	 * @param labels array of labels extracted from input data
	 * @param exp_number number of experiment that is running
	 * @return RunSubcobiClustererResult with values : best_k best k found
	 *         best_m best m found nmi_value normalized mutual information
	 *         best_rotPoints best dataMatrix after clustering and ort
	 *         best_result_labels best result_labels compare_results k x m x
	 *         (cost, MDL, NMI)
	 */
	public RunSubcobiClustererResult runClusterer(SimpleMatrix dataset, int[] labels, int[] k_testInterval,
			int[] m_testInterval, int exp_number) {

		RunSubcobiClustererResult res = new RunSubcobiClustererResult();
		int label = 1;
		int maxlabel = 0;
		for (int j = 0; j < labels.length; j++)
			if (labels[j] > maxlabel)
				maxlabel = labels[j];

		for (int i = 1; i <= maxlabel; i++) {
			for (int p = 0; p < labels.length; p++)
				if (labels[p] == i)
					labels[p] = label;
			label++;
		}

		if (Options.NORMALIZE) {
			for (int i = 0; i < dataset.numRows(); i++) {

				double meantemp = 0.0;
				double std = 0.0;
				for (int j = 0; j < dataset.numCols(); j++)
					meantemp = meantemp + dataset.get(i, j);

				meantemp = meantemp / dataset.numCols();
				for (int j = 0; j < dataset.numCols(); j++)
					std = std + (dataset.get(i, j) - meantemp) * (dataset.get(i, j) - meantemp);
				
				std = Math.sqrt(std / dataset.numCols());

				for (int j = 0; j < dataset.numCols(); j++)
					dataset.set(i, j, (dataset.get(i, j) - meantemp) / std);
			}
		}

		System.out.println("Processing dataset, experiment " + exp_number + " ...");

		double minMDL = Double.MAX_VALUE;

		SimpleMatrix best_rotPoints = new SimpleMatrix(dataset.numRows(), dataset.numCols());

		int[] best_result_labels = new int[labels.length];
		// computation in the loop below, since the return value compare_results doesn't influence the values saved in output, there it will not be computated
		int best_k = 0;
		int best_m = 0;
		double val_nmi = 0;

		double maximal_NMI = 0;
		int best_nmi_k = 0;
		int best_nmi_m = 0;
		double best_NMI = 0;

		int total_iterations = k_testInterval.length * m_testInterval.length * Options.RUNS;

		int iteration = 0;

		for (int ki = 0; ki < k_testInterval.length; ki++) {
			int k = k_testInterval[ki];
			for (int mi = 0; mi < m_testInterval.length; mi++) {
				int m = m_testInterval[mi];
				int run = 1;
				while (run <= Options.RUNS) {
					System.out.println("Starting fosscluEM for k = " + k + " and m = " + m);

					FOSSCLU fos = new FOSSCLU();
					FosscluEMResult fossclures = fos.fosscluEM(k, m, dataset, labels, run);

					if (!fossclures.failed) {
						iteration++;
						double percentage_iterations = iteration * 100 / total_iterations;
						System.out.println("Percentage Iteration " + percentage_iterations);
						if (fossclures.mdl_value < minMDL) {
							minMDL = fossclures.mdl_value;
							best_rotPoints = fossclures.rotPoints;
							best_result_labels = fossclures.result_labels;
							best_k = k;
							best_m = m;
							val_nmi = fossclures.nmi_value;
						}
						if (fossclures.nmi_value > maximal_NMI) {
							maximal_NMI = fossclures.nmi_value;
							best_nmi_k = k;
							best_nmi_m = m;
							best_NMI = fossclures.nmi_value;
						}
					}
					run++;
				}
			}
		}

		System.out.println("Best MDL="+minMDL+" for k= " + best_k + ", m= " + best_m + ", NMI= " + val_nmi + " [maxNMI= "
				+ best_NMI + " at (but not only at) k= " + best_nmi_k + ", m= " + best_nmi_m);

		res.best_k = best_k;
		res.best_m = best_m;
		res.best_result_labels = best_result_labels;
		res.best_rotPoints = best_rotPoints;
		res.nmi_value = val_nmi;

		return res;
	}
}
