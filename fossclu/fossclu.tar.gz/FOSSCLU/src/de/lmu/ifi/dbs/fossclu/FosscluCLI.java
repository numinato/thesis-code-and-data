package de.lmu.ifi.dbs.fossclu;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.ejml.simple.SimpleMatrix;

import com.jmatio.io.MatFileReader;
import com.jmatio.io.MatFileWriter;
import com.jmatio.types.MLArray;
import com.jmatio.types.MLDouble;

import de.lmu.ifi.dbs.fossclu.RunSubcobiClusterer.RunSubcobiClustererResult;

/**
 * A command line interface to FOSSCLU.
 * 
 */
public class FosscluCLI {

	public static class MatlabReadingResult {
		public int[] labels;
		public SimpleMatrix points;
	}
	
	/**
	 * Read a Matlab file automagically into labels and points
	 * @param file file path and name relative to the project
	 */
	public static MatlabReadingResult readMatlabFile(String file) {
		MatlabReadingResult res = new MatlabReadingResult();
		MatFileReader matReader = null;
		try {
			System.out.println("Reading matlab file '" + file + "'.");
			matReader = new MatFileReader(file);
		} catch (IOException e) {
			System.out.println("Error: IOException while reading matlab file. Quitting.");
			System.exit(1);
		}
		Map<String, MLArray> matContent = matReader.getContent();
		if (matContent.size() != 2) {
			System.out.println("Error: Found more than two entries in the matlab file. Quitting.");
			System.exit(1);
		}
		MLDouble matLabels = null;
		MLDouble matPoints = null;
		Iterator<Entry<String, MLArray>> matContentIt = matContent.entrySet().iterator();
		while (matContentIt.hasNext()) {
			Entry<String, MLArray> entry = matContentIt.next();
			System.out.print("Found entry named '" + entry.getKey() + "' with dimensions "
					+ Arrays.toString(entry.getValue().getDimensions()) + " ... ");
			if (entry.getValue().isDouble()) {
				if (entry.getValue().getDimensions()[0] == 1) {
					System.out.println("taking this one as labels.");
					matLabels = (MLDouble) entry.getValue();
				} else {
					System.out.println("taking this one as points.");
					matPoints = (MLDouble) entry.getValue();
				}
			} else {
				System.out.println("but not consisting of double values. Error and Quitting.");
			}
		}
		if (matLabels == null || matPoints == null) {
			System.out.println("Error: labels or points are missing in matlab input file. Quitting.");
			System.exit(1);
		}
		res.labels = new int[matLabels.getDimensions()[1]];
		for (int col = 0; col < matLabels.getDimensions()[1]; col++) {
			// rounding and casting labels back to integer
			res.labels[col] = (int) Math.round(matLabels.get(0, col));
		}
		res.points = new SimpleMatrix(matPoints.getDimensions()[0], matPoints.getDimensions()[1]);
		for (int row = 0; row < matPoints.getDimensions()[0]; row++) {
			for (int col = 0; col < matPoints.getDimensions()[1]; col++) {
				res.points.set(row, col, matPoints.get(row, col));
			}
		}

		//		System.out.println(Arrays.toString(labels));
		//		System.out.println(points.toString());
		return res;
	}
	
	/**
	 * Write points and labels to a Matlab file
	 * @param labels
	 * @param points
	 * @param filename
	 */
	public static void writeMatlabFile(int[] labels, SimpleMatrix points, String filename) {
		ArrayList<MLArray> matColl = new ArrayList<MLArray>();
		
		double[] arrayLabels = new double[labels.length];
		for (int i = 0; i < labels.length; i++)
			arrayLabels[i] = (double)labels[i];
		MLDouble matLabels = new MLDouble("labels", arrayLabels, 1);
		matColl.add(matLabels);
		
		double[][] arrayPoints = new double[points.numRows()][];
		for (int i = 0; i < points.numRows(); i++) {
			arrayPoints[i] = new double[points.numCols()];
			for (int j = 0; j < points.numCols(); j++) {
				arrayPoints[i][j] = points.get(i, j);
			}
		}
		MLDouble matPoints = new MLDouble("points", arrayPoints);
		matColl.add(matPoints);
		
		try {
			@SuppressWarnings("unused")
			MatFileWriter matWriter = new MatFileWriter(filename, matColl);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		System.out.println("Working directory is '" + System.getProperty("user.dir") + "'.");
		MatlabReadingResult mat = readMatlabFile(Options.MATFILE);

		System.out.println("labels_gold="+Arrays.toString(mat.labels));
		
		int k_start = Options.K_START;
		int k_end = Options.K_END;
		int m_start = Options.M_START;
		int m_end = Options.M_END;

		int klen = k_end - k_start + 1;
		int mlen = m_end - m_start + 1;
		int[] k_testInterval = new int[klen];
		int[] m_testInterval = new int[mlen];

		for (int i = 0; i < klen; i++) {
			k_testInterval[i] = k_start + i;

		}

		for (int i = 0; i < mlen; i++) {
			m_testInterval[i] = m_start + i;

		}

		for (int i = 1; i <= Options.NUMEXP; i++) {
			System.out.println("Experiment Number: " + i);

			RunSubcobiClusterer clu = new RunSubcobiClusterer();
			RunSubcobiClustererResult res = clu.runClusterer(mat.points, mat.labels, k_testInterval, m_testInterval, i);

			System.out.println("nmi " + res.nmi_value);
			System.out.println("best k " + res.best_k);
			System.out.println("best m " + res.best_m);
			System.out.println("reslabels " + Arrays.toString(res.best_result_labels));
			
			writeMatlabFile(res.best_result_labels, res.best_rotPoints, Options.RESFILE);
		}

	}

}
