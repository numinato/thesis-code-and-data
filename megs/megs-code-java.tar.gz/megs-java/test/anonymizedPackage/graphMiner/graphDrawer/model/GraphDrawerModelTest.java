package anonymizedPackage.graphMiner.graphDrawer.model;

import static org.junit.Assert.*;

import org.junit.Test;

public class GraphDrawerModelTest {

    @Test
    public void testCalculateCosts() {
	fail("Not yet implemented");
    }

}
