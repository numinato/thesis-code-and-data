package anonymizedPackage.graphMiner.mdl;

import static org.junit.Assert.*;

public class graphMDLTest {

//    // @Test
//    public void testSortTree() {
//	MDL testGraphMDL = new MDL(null);
//
//	int[][] adjacencyMatrix = new int[12][12];
//	adjacencyMatrix[0][1] = 1;
//	adjacencyMatrix[0][2] = 1;
//	adjacencyMatrix[0][3] = 1;
//	adjacencyMatrix[0][4] = 1;
//	adjacencyMatrix[1][0] = 1;
//	adjacencyMatrix[2][0] = 1;
//	adjacencyMatrix[3][0] = 1;
//	adjacencyMatrix[4][0] = 1;
//	adjacencyMatrix[2][5] = 1;
//	adjacencyMatrix[2][6] = 1;
//	adjacencyMatrix[5][2] = 1;
//	adjacencyMatrix[6][2] = 1;
//	adjacencyMatrix[3][7] = 1;
//	adjacencyMatrix[7][3] = 1;
//	adjacencyMatrix[4][8] = 1;
//	adjacencyMatrix[8][4] = 1;
//	adjacencyMatrix[5][9] = 1;
//	adjacencyMatrix[9][5] = 1;
//	adjacencyMatrix[6][10] = 1;
//	adjacencyMatrix[10][6] = 1;
//	adjacencyMatrix[8][11] = 1;
//	adjacencyMatrix[11][8] = 1;
//
//	int[][] resultMatrix = new int[12][12];
//	for (int i = 0; i < resultMatrix.length; i++) {
//	    for (int j = 0; j < resultMatrix.length; j++) {
//		resultMatrix[i][j] = adjacencyMatrix[i][j];
//	    }
//	}
//
//	int[][] testResultMatrix = testGraphMDL.sortTreeMatrix(0, 11, 0, adjacencyMatrix);
//	assertArrayEquals(resultMatrix, testResultMatrix);
//
//    }

}
