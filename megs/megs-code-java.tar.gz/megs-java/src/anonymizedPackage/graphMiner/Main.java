package anonymizedPackage.graphMiner;
import anonymizedPackage.graphMiner.graphDrawer.application.gui.GraphDrawerController;

/**
* 
* @version $Id: Main.java 1743 2014-06-27 14:36:51Z goebl $
*/
public class Main {
    
    public static final boolean debuggingEnabled = false;

    public static void main(String args[]) {
	GraphDrawerController controller = new GraphDrawerController();
	controller.initView();
    }

}
