package anonymizedPackage.graphMiner.graphClusterer;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

public class ConnectedGraphPair {
    private Graph g1;
    private Graph g2;

    public ConnectedGraphPair(Graph g, int splitAtIndex) {
	ArrayList<Node> nodes1 = new ArrayList<Node>(g.getNodes().subList(0, splitAtIndex));
	ArrayList<Node> nodes2 = new ArrayList<Node>(g.getNodes().subList(splitAtIndex, g.size()));
    
	
	
    }

    public Graph getFirstGraph() {
	return g1;
    }

    public Graph getSecondGraph() {
	return g2;
    }

    public void sortAsTree(Graph g) {
	Node currentNode = g.getNode(0);
	Graph orderedGraph = new Graph(g.size());
	LinkedList<Node> allNodesToProcess = new LinkedList<Node>(g.getNodes());
	LinkedList<Node> nextNodesToProcess = new LinkedList<Node>();
	HashSet<Node> visitedNodes = new HashSet<Node>();

	while (currentNode != null) {

	    if (allNodesToProcess.remove(currentNode)) {
		visitedNodes.add(currentNode);
		orderedGraph.add(currentNode);
		for (Node neighbor : currentNode.getNeighbors()) {
		    if (g.contains(neighbor)) {
			nextNodesToProcess.add(neighbor);
		    }
		}
	    }

	    if ((currentNode = nextNodesToProcess.poll()) == null) {
		if (allNodesToProcess.isEmpty()) {
		    currentNode = null;
		} else {
		    currentNode = allNodesToProcess.getFirst();
		}
	    }
	}

	ArrayList<Node> nodes = new ArrayList<Node>(orderedGraph.getNodes());
    }
    
    
}
