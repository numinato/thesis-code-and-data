package anonymizedPackage.graphMiner.graphClusterer;

import java.util.HashSet;

import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

public class GraphSplitter {
    private Graph firstGraph;
    private Graph secondGraph;

    public GraphSplitter(Graph g, int m) {
	Graph bfsGraph;
	HashSet<Node> hs;

	bfsGraph = new Graph(g);
	bfsGraph.sortRandomBfs();
	hs = new HashSet<Node>(bfsGraph.getNodes().subList(0, m));
	firstGraph = new Graph();
	secondGraph = new Graph();

	for (Node node : g.getNodes()) {
	    if (hs.contains(node)) {
		firstGraph.add(node);
	    } else {
		secondGraph.add(node);
	    }
	}
    }

    public Graph getFirstGraph() {
	return firstGraph;
    }

    public Graph getSecondGraph() {
	return secondGraph;
    }

}
