package anonymizedPackage.graphMiner.graphClusterer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.TreeMap;

import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

/**
 * 
 * @version $Id: Cluster.java 1844 2014-07-23 16:51:04Z goebl $
 */
public abstract class Cluster {

    protected final double clusterCodebookLength = 5; // TODO: do not hard code
    public final static int minClusterSize = 4;
    
    private static int n;
    
    protected Graph clusteredGraph;
    protected Neighborhood neighborhood;
    protected double mdl;
    protected boolean isLastActionAddNode;
    protected Node lastActionNode;
    protected double lastMdl;
    
    protected Cluster(Neighborhood neighborhood){
	this.neighborhood = neighborhood;
	isLastActionAddNode = false;
	lastActionNode = null;
    }

    public final double getMdl() {
	return mdl;
    }

    public final int getSize() {
	return clusteredGraph.size();
    }

    /**
     * @return reflected ArrayList of Nodes of cluster
     */
    public final ArrayList<Node> getClusteredNodes() {
	return clusteredGraph.getNodes();
    }

    public abstract Collection<Node> getOrderedClusteredNodes();

    public static int getN(){
	return Cluster.n;
    }
    
    public static void setN(int n){
	Cluster.n = n;
    }
    
    public abstract void addNode(Node node, Collection<Node> nodes);
    
    public abstract void removeNode(Node node) throws GraphSizeException;
    
    public abstract void undo();
    
}
