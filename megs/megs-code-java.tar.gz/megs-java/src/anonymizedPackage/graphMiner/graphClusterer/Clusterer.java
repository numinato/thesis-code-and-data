package anonymizedPackage.graphMiner.graphClusterer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public abstract class Clusterer {

    public Clustering clustering;
    public Mode mode;
    public HashMap<HashSet<ClusterMap>, Integer> interClusterErrors;

    public Clusterer() {
	super();
    }

    public enum Mode {
	CLUSTERING, INIT
    };

    public abstract int[] getClusterBorders();

    public abstract int getClusterBorders(int i);

    public abstract void setClusterBorders(int i, int newPosition);

}
