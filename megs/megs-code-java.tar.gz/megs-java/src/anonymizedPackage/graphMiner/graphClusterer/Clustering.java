package anonymizedPackage.graphMiner.graphClusterer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import anonymizedPackage.graphMiner.graphDrawer.accessories.Tools;
import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.GraphType;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

public class Clustering extends ArrayList<ClusterMap> {

    private static final long serialVersionUID = 1164117084033725697L;

    public InterMap interMap;

    public Clustering(Graph graph) throws GraphSizeException {
	Cluster.setN(graph.size());
	interMap = new InterMap();
	ClusterMap cm = new ClusterMap(graph);
	add(cm);
	cm.buildTreeMap();
    }

    public double getClusterMdl() {
	double mdl = 0.0;
	int i = 0;
	for (ClusterMap cm : this) {
	    mdl += cm.getMinMdl();
	    // System.err.printf("ClusterMap %d: Best cluster type = '%s', MDL = %.2f%n",
	    // i, cm.getBestCluster()
	    // .getClass().toString().split("\\.")[6], cm.getMinMdl());
	    i++;
	}
	return mdl;

    }

    public double getMdl() {
//	assert assertionAux();
	// System.err.printf("Cost for number (%d) of clusters = %.2f, cost for cluster sizes = %.2f%n",
	// this.size(),
	// interMap.getMdl(), this.size() *
	// Math.ceil(Tools.log2(Cluster.getN())));
	return getClusterMdl() // subgraph cost
		+ interMap.getMdl() // errors between subgraphs
		+ Tools.logstar2(this.size()) // number of clusters
		+ Tools.logstar2(Cluster.getN()) // graph
						 // size
		+ this.size() * Math.ceil(Tools.log2(Cluster.getN())); // cluster
								       // sizes
    }

    private boolean assertionAux() {
	if (!Double.isInfinite(interCodingCost())) {
	    if (interMap.getMdl() != interCodingCost()) {
		System.err.printf("NOT EQUAL !!!: interMap.getMdl(): %.2f != interCodingCost(): %.2f",
			interMap.getMdl(), interCodingCost());
	    }
	    return interMap.getMdl() == interCodingCost();
	}
	return true;
    }

    @Deprecated
    public double interCodingCost() {
	try {
	    int existing = 0;
	    int possible = 0;
	    for (int i = 0; i < size(); i++) {
		for (int j = i + 1; j < size(); j++) {
		    existing += get(i).existingConnectingEdges(get(j));
		    possible += get(i).possibleConnectingEdges(get(j));
		}
	    }
	    System.err.println(existing);
	    System.err.println(possible);
	    return Tools.entropyCodingCost(existing, possible);
	} catch (NullPointerException e) {
	    return Double.POSITIVE_INFINITY;
	}
    }

    @Deprecated
    public double interCodingCostSplit(ClusterMap cm1, ClusterMap cm2) {
	int existing = 0;
	int possible = 0;
	for (int i = 0; i < size(); i++) {
	    for (int j = i + 1; j < size(); j++) {
		existing += get(i).existingConnectingEdges(get(j));
		possible += get(i).possibleConnectingEdges(get(j));
	    }
	}

	// add new error edges caused by splitting
	existing += cm1.existingConnectingEdges(cm2);
	possible += cm1.possibleConnectingEdges(cm2);

	assert !Double.isNaN(Tools.entropyCodingCost(existing, possible));
	
	return Tools.entropyCodingCost(existing, possible);
    }

    @Deprecated
    public double interCodingCostMerge(ClusterMap cm1, ClusterMap cm2) {
	int existing = 0;
	int possible = 0;
	for (int i = 0; i < size(); i++) {
	    for (int j = i + 1; j < size(); j++) {
		existing += get(i).existingConnectingEdges(get(j));
		possible += get(i).possibleConnectingEdges(get(j));
	    }
	}

	// remove error edges that disappear after merging
	existing -= cm1.existingConnectingEdges(cm2);
	possible -= cm1.possibleConnectingEdges(cm2);
	System.err.printf("OLD>> existing=%d,possible=%d%n", existing, possible);
	return Tools.entropyCodingCost(existing, possible);
    }

    public ClusterMap isMapped(Node node) {
	for (ClusterMap cm : this) {
	    if (cm.getBestClusteredNodes().contains(node)) {
		return cm;
	    }
	}
	assert false;
	return null;
    }

    public GraphType[] getBestGraphTypes() {
	GraphType[] gt = new GraphType[size()];
	for (int i = 0; i < size(); i++) {
	    gt[i] = get(i).getBestGraphType();
	}
	return gt;
    }

    public int getK() {
	return size();
    }

    public String toString() {
	StringBuffer sb = new StringBuffer();
	for (int i = 0; i < this.size(); i++) {
	    sb.append("ClusterMap " + i + ":\n");
	    sb.append(get(i).toString());
	}
	return sb.toString();
    }

    public InterMap getInterMap() {
	return interMap;
    }

    public void splitInterClusterMap(ClusterMap cmOld, ClusterMap cmNew1, ClusterMap cmNew2) {
	HashSet<HashSet<ClusterMap>> toAdd = new HashSet<HashSet<ClusterMap>>();
	HashSet<HashSet<ClusterMap>> toRemove = new HashSet<HashSet<ClusterMap>>();
	HashSet<ClusterMap> hsToAdd;

	for (Set<ClusterMap> hs : interMap.keySet()) {
	    if (hs.contains(cmOld)) {
		HashSet<ClusterMap> hsToRemove = new HashSet<ClusterMap>();
		ClusterMap cmPartner = interMap.get(hs).getOtherClusterMap(cmOld);

		hsToRemove.add(cmOld);
		hsToRemove.add(cmPartner);
		toRemove.add(hsToRemove);

		hsToAdd = new HashSet<ClusterMap>();
		hsToAdd.add(cmPartner);
		hsToAdd.add(cmNew1);
		toAdd.add(hsToAdd);

		hsToAdd = new HashSet<ClusterMap>();
		hsToAdd.add(cmPartner);
		hsToAdd.add(cmNew2);
		toAdd.add(hsToAdd);
	    }
	}
	interMap.removeInters(toRemove);
	hsToAdd = new HashSet<ClusterMap>();
	hsToAdd.add(cmNew1);
	hsToAdd.add(cmNew2);
	toAdd.add(hsToAdd);
	interMap.addInters(toAdd);
    }

    public double getInterMdl() {
	return interMap.getMdl();
    }

    public double getInterMdlWith(ClusterMap cm1, ClusterMap cm2) {
	return interMap.getMdlWith(new InterClusterArea(cm1, cm2));
    }

    public double getInterMdlWithout(ClusterMap cm1, ClusterMap cm2) {
	return interMap.getMdlWithout(new InterClusterArea(cm1, cm2));
    }

    public void mergeInterClusterMap(ClusterMap cmOld1, ClusterMap cmOld2, ClusterMap cmNew) {
	HashSet<HashSet<ClusterMap>> toAdd = new HashSet<HashSet<ClusterMap>>();
	HashSet<HashSet<ClusterMap>> toRemove = new HashSet<HashSet<ClusterMap>>();
	HashSet<ClusterMap> hsToAdd;
	HashSet<ClusterMap> hsToRemove;

	hsToRemove = new HashSet<ClusterMap>();
	hsToRemove.add(cmOld1);
	hsToRemove.add(cmOld2);
	interMap.remove(hsToRemove);

	for (Set<ClusterMap> hs : interMap.keySet()) {
	    if (hs.contains(cmOld1) || hs.contains(cmOld2)) {
		ClusterMap cm;
		if (hs.contains(cmOld1)) {
		    cm = cmOld1;
		} else {
		    cm = cmOld2;
		}
		hsToRemove = new HashSet<ClusterMap>();
		ClusterMap cmPartner = interMap.get(hs).getOtherClusterMap(cm);

		hsToRemove.add(cm);
		hsToRemove.add(cmPartner);
		toRemove.add(hsToRemove);

		hsToAdd = new HashSet<ClusterMap>();
		hsToAdd.add(cmPartner);
		hsToAdd.add(cmNew);
		toAdd.add(hsToAdd);
	    }
	}
	interMap.removeInters(toRemove);
	interMap.addInters(toAdd);
    }

    public void removeInterNode(ClusterMap cm, Node node) {
	interMap.removeNode(cm, node);
    }

    public void addInterNode(ClusterMap cm, Node node) {
	interMap.addNode(cm, node);

    }

}
