package anonymizedPackage.graphMiner.graphClusterer;

public class ClusteringException extends Exception {

    public ClusteringException(String string) {
	super(string);
    }

}
