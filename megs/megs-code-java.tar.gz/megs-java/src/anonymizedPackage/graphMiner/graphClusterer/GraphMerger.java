package anonymizedPackage.graphMiner.graphClusterer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

public class GraphMerger {
    HashMap<Node, Integer> graphPositions;

    public GraphMerger(HashMap<Node, Integer> graphPositions) {
	this.graphPositions = graphPositions;
    }

    public Graph merge(ArrayList<Node> nodes1, ArrayList<Node> nodes2) {
	TreeMap<Integer, Node> tm = new TreeMap<Integer, Node>();

	for (Node node : nodes1) {
	    tm.put(graphPositions.get(node), node);
	}
	for (Node node : nodes2) {
	    tm.put(graphPositions.get(node), node);
	}
	return new Graph(new ArrayList<Node>(tm.values()));
    }

}
