package anonymizedPackage.graphMiner.graphClusterer;

public class GraphSizeException extends Exception {

    public GraphSizeException(String string) {
	super(string);
    }

    private static final long serialVersionUID = 5653190620026432605L;

}
