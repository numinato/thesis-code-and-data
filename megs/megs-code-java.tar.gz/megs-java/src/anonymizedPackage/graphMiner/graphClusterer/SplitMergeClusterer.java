package anonymizedPackage.graphMiner.graphClusterer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Random;

import anonymizedPackage.graphMiner.graphDrawer.accessories.Nmi;
import anonymizedPackage.graphMiner.graphDrawer.accessories.Tools;
import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.GraphType;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

public class SplitMergeClusterer extends Clusterer {

    private static int minimalClusterSize = 4;
    public static boolean hasSparse = true;

    private Graph graph;
    private static HashMap<Node, Integer> graphPositions;
    private GraphMerger graphMerger;
    private LinkedList<Node> nodesToProcess;
    private ArrayList<ClusterMap> clusterMapsForTreeMapping;
    private double minMdl;
    private int graphSize;

    public SplitMergeClusterer(Graph graph) throws GraphSizeException {
	super();
	this.graph = graph;
	graphSize = graph.size();
	System.err.println("START CLUSTERING");
	setGraphPositions();
	graphMerger = new GraphMerger(graphPositions);
	clustering = new Clustering(graph);
    }

    private void setGraphPositions() {
	int count = 0;
	graphPositions = new HashMap<Node, Integer>();

	for (Node node : graph.getNodes()) {
	    graphPositions.put(node, count);
	    count++;
	}
    }

    public void diag() {
	graph.sortBfs();
    }

    /**
     * Creates random order for processing nodes in clustering step
     */
    public void createNodeProcessingOrder() {
	nodesToProcess = new LinkedList<Node>(graph.getNodes());
	Collections.shuffle(nodesToProcess);
	assert nodesToProcess.containsAll(graph.getNodes())
		&& graph.getNodes().containsAll(nodesToProcess);
    }

    public Node nextNode() {
	if (nodesToProcess.isEmpty()) {
	    return null;
	} else {
	    return nodesToProcess.pop();
	}
    }

    /**
     * Main split method of split&merge algorithm.
     */
    public void split() {
	clusterMapsForTreeMapping = new ArrayList<ClusterMap>();
	boolean isSplit = false;
	boolean areAllClustersTooSmall = false;
	int splittingDepth = 0;
	while (!isSplit && !areAllClustersTooSmall) {
	    areAllClustersTooSmall = true;

	    // create random order for clusters to split
	    Collections.shuffle(clustering);

	    // try to split clusters
	    for (int i = 0; i < clustering.size(); i++) {
		double mdlCostBeforeSplit = clustering.getMdl();
		try {
		    if (split(i, splittingDepth)) {
			isSplit = true;
			i++;
		    }
		    areAllClustersTooSmall = false;
		} catch (NullPointerException npe) {
		    areAllClustersTooSmall = false;
		} catch (SplittingException se) {
		    // System.err.println();
		} catch (GraphSizeException ge) {

		}
		double mdlCostAfterSplit = clustering.getMdl();
		assert !(mdlCostAfterSplit > mdlCostBeforeSplit);
	    }
	    splittingDepth++;

	}
	buildTreeMapsForClusterMaps();
    }

    /**
     * Attempts to split cluster (ClusterMap) with splitting depth specified in
     * {@code splittingDepth}. Returns true only if splitting is successful,
     * i.e. split clusters reduce overall MDL cost.
     * 
     * @param i
     *            cluster ID
     * @param splittingDepth
     *            splitting depth
     * @return {@code true} if splitting is successful
     * @throws GraphSizeException
     */
    private boolean split(int i, int splittingDepth) throws SplittingException, GraphSizeException,
	    NullPointerException {
	ClusterMap cm = clustering.get(i);

	Graph g = cm.getGraph();
	assert g.size() == cm.getBestClusteredNodes().size();

	int[] middleElements = calculateMiddleElements(cm.clusterSize(), splittingDepth);
	Tools.ShuffleArray(middleElements);
	for (int m : middleElements) {
	    double mdlCostBeforeSplit = clustering.getMdl();

	    if (m < Cluster.minClusterSize || cm.clusterSize() - m < Cluster.minClusterSize) {
		throw new SplittingException();
	    }

	    GraphSplitter gs = new GraphSplitter(g, m);

	    ClusterMap cm1 = new ClusterMap(gs.getFirstGraph());
	    ClusterMap cm2 = new ClusterMap(gs.getSecondGraph());

	    // System.err
	    // .println("======================================================================");
	    // System.err.println("Split at " + m + " results in:\n\nCM1:\n" +
	    // cm1.toString()
	    // + "\nCM2:\n" + cm2.toString() + "\nOld CM:\n" + cm.toString());
	    // System.err
	    // .println("======================================================================");

	    // assert that the new clusters have been built successfully
	    assert cm1.getBestClusteredNodes() != null;
	    assert cm2.getBestClusteredNodes() != null;

	    // assert that old cluster and new clusters contain the same nodes
	    ArrayList<Node> testAL = new ArrayList<Node>();
	    testAL.addAll(cm1.getBestClusteredNodes());
	    testAL.addAll(cm2.getBestClusteredNodes());
	    assert cm.getBestClusteredNodes().containsAll(testAL)
		    && testAL.containsAll(cm.getBestClusteredNodes());

	    assert clustering.getInterMdlWith(cm1, cm2) == clustering
		    .interCodingCostSplit(cm1, cm2);
	    double oldCost = cm.getMinMdl() + clustering.getInterMdl()
		    + Tools.logstar2(clustering.size());
	    double newCost = cm1.getMinMdl() + cm2.getMinMdl()
		    + clustering.getInterMdlWith(cm1, cm2) + Math.ceil(Tools.log2(Cluster.getN()))
		    + Tools.logstar2(clustering.size() + 1);
	    if (newCost < oldCost) {
		clustering.remove(i);
		clustering.add(i, cm2);
		clustering.add(i, cm1);
		clustering.splitInterClusterMap(cm, cm1, cm2);
		clusterMapsForTreeMapping.add(cm1);
		clusterMapsForTreeMapping.add(cm2);
		double mdlCostAfterSplit = clustering.getMdl();
		assert !(mdlCostAfterSplit > mdlCostBeforeSplit);
		assert clustering.interMap.size() == (clustering.size() * (clustering.size() - 1)) / 2;
		return true;
	    }
	}
	return false;
    }

    private int[] calculateMiddleElements(int clusterSize, int splittingDepth) {
	int[] result = new int[(int) Math.pow(2, splittingDepth)];
	double numerator = 1;
	double denominator = result.length * 2;
	for (int i = 0; i < result.length; i++) {
	    result[i] = (int) ((numerator / denominator) * clusterSize);
	    numerator += 2;
	}
	// System.err.printf("Splitting Depth = %2d, middle elements = %s%n",
	// splittingDepth, Arrays.toString(result));
	return result;
    }

    public void merge() {
	boolean hasChanged;

	clusterMapsForTreeMapping = new ArrayList<ClusterMap>();
	hasChanged = true;

	while (hasChanged) {
	    ClusterMap cmMerged;
	    double minMdl;
	    int minI, minJ;

	    cmMerged = null;
	    minMdl = Double.POSITIVE_INFINITY;
	    minI = -1;
	    minJ = -1;
	    hasChanged = false;

	    for (int i = 0; i < clustering.size(); i++) {
		for (int j = i + 1; j < clustering.size(); j++) {
		    ClusterMap cm, cm1, cm2;
		    Graph g;
		    double mdlBeforeMerge, mdlAfterMerge;

		    assert clustering.interMap.size() == (clustering.size() * (clustering.size() - 1)) / 2;

		    cm1 = clustering.get(i);
		    cm2 = clustering.get(j);

		    // buildTreeMapsForClusterMaps();
		    g = graphMerger.merge(cm1.getBestClusteredNodes(), cm2.getBestClusteredNodes());

		    assert cm1.getBestCluster().clusteredGraph.size()
			    + cm2.getBestCluster().clusteredGraph.size() == g.size();

		    cm = null;

		    try {
			cm = new ClusterMap(g);
		    } catch (GraphSizeException e) {
			e.printStackTrace();
			assert false;
		    }

		    assert clustering.interMap.size() == (clustering.size() * (clustering.size() - 1)) / 2;
		    assert clustering.getInterMdlWithout(cm1, cm2) == clustering
			    .interCodingCostMerge(cm1, cm2);

		    mdlBeforeMerge = cm1.getMinMdl() + cm2.getMinMdl() + clustering.getInterMdl()
			    + Tools.logstar2(clustering.size());

		    mdlAfterMerge = cm.getMinMdl() + clustering.getInterMdlWithout(cm1, cm2)
			    - Math.ceil(Tools.log2(Cluster.getN()))
			    + Tools.logstar2(clustering.size() - 1);

		    if (mdlAfterMerge < mdlBeforeMerge) {
			if (mdlAfterMerge < minMdl) {
			    cmMerged = cm;
			    minMdl = mdlAfterMerge;
			    minI = i;
			    minJ = j;
			    hasChanged = true;
			}
		    }
		}
	    }

	    if (hasChanged) {
		double mdlCostBeforeMerge, mdlCostAfterMerge;

		mdlCostBeforeMerge = clustering.getMdl();

		clustering.mergeInterClusterMap(clustering.get(minI), clustering.get(minJ),
			cmMerged);
		clustering.remove(minJ);
		clustering.remove(minI);
		clustering.add(minI, cmMerged);
		clusterMapsForTreeMapping.add(cmMerged);

		buildTreeMapsForClusterMaps(); // TODO: necessary?
		mdlCostAfterMerge = clustering.getMdl();

		assert !(mdlCostAfterMerge > mdlCostBeforeMerge);
	    }
	}
    }

    private void buildTreeMapsForClusterMaps() {
	for (ClusterMap cm : clusterMapsForTreeMapping) {
	    cm.buildTreeMap();
	}
    }

    public int[] getClusterBegins() {
	int[] result = new int[clustering.size()];
	result[0] = 0;
	for (int i = 0; i < clustering.size() - 1; i++) {
	    result[i + 1] = result[i] + clustering.get(i).clusterSize();

	}
	System.err.println(Arrays.toString(result));
	return result;
    }

    public void updateClustering(Node node) {
	ClusterMap oldCM;
	ClusterMap minCM;
	double oldMdl;
	double minMdl;
	double mdl;

	oldCM = clustering.isMapped(node);
	minCM = null;
	oldMdl = clustering.getMdl();
	minMdl = Double.POSITIVE_INFINITY;

	assert graph.contains(node);

	for (ClusterMap newCm : clustering) {
	    if (newCm != oldCM && oldCM.clusterSize() > Cluster.minClusterSize) {
		try {
		    clustering.removeInterNode(oldCM, node);
		    oldCM.removeNode(node);
		    newCm.addNode(node);
		    clustering.addInterNode(newCm, node);

		    mdl = clustering.getMdl();

		    if (mdl < oldMdl && mdl < minMdl) {
			minCM = newCm;
			minMdl = mdl;
		    }

		    clustering.removeInterNode(newCm, node);
		    newCm.undo();
		    oldCM.undo();
		    clustering.addInterNode(oldCM, node);

		} catch (GraphSizeException e) {
		    e.printStackTrace();
		    assert false;
		}
	    }
	}
	if (minCM != null) {
	    try {
		clustering.removeInterNode(oldCM, node);
		oldCM.removeNode(node);
	    } catch (GraphSizeException e) {
		assert false;
	    }
	    minCM.addNode(node);
	    clustering.addInterNode(minCM, node);
	    assert (Math.abs(minMdl - clustering.getMdl()) < 0.00001);
	}
    }

    public GraphType[] getGraphTypes() {
	return clustering.getBestGraphTypes();
    }

    public void update(Graph graphModel) {
	ArrayList<Node> nodes = new ArrayList<Node>();
	for (ClusterMap cm : clustering) {
	    nodes.addAll(cm.getBestClusteredNodes());
	}
	assert graphModel.contains(graph) && graph.contains(graphModel);
	graphModel.setNodes(nodes);
    }

    public double getMdl() {
	return clustering.getMdl();
    }

    @Override
    public int[] getClusterBorders() {
	// TODO Auto-generated method stub
	return null;
    }

    @Override
    public int getClusterBorders(int i) {
	// TODO Auto-generated method stub
	return 0;
    }

    @Override
    public void setClusterBorders(int i, int newPosition) {
	// TODO Auto-generated method stub

    }

    public static Integer getGraphPosition(Node node) {
	return graphPositions.get(node);
    }

    public double getNmi() {
	int[] classLabels;
	int[] clusterLabels;
	int count;
	int clusterLabel;

	classLabels = new int[graphSize];
	clusterLabels = new int[graphSize];
	count = 0;
	clusterLabel = 1;

	for (ClusterMap cm : clustering) {
	    for (Node n : cm.getBestClusteredNodes()) {
		clusterLabels[count] = clusterLabel;
		classLabels[count] = n.getClassLabel() + 1;
		count++;
	    }
	    clusterLabel++;
	}
	System.err.println(Arrays.toString(classLabels));
	System.err.println(Arrays.toString(clusterLabels));

	return Nmi.getNmi(classLabels, clusterLabels);
    }
    
    public void sort(Graph graphModel) {
	ArrayList<Node> nodes = new ArrayList<Node>();
	for (ClusterMap cm : clustering) {
	    nodes.addAll(cm.getBestClusteredNodesOrdered());
	}
	assert graphModel.contains(graph) && graph.contains(graphModel);
	graphModel.setNodes(nodes);
    }

}
