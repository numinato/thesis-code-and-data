package anonymizedPackage.graphMiner.graphClusterer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.TreeMap;

import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.GraphType;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

/**
 * 
 * @version $Id: ClusterMap.java 1844 2014-07-23 16:51:04Z goebl $
 */
public class ClusterMap extends HashMap<GraphType, Cluster> {

    private static final long serialVersionUID = 5289139943154533124L;
    public static int largestConnectedComponentSize;

    private TreeMap<Integer, Node> treeMap;
    private Neighborhood neighborhood;
    private boolean isLastActionAddNode;
    private Node lastActionNode;
    private Graph graphWhenCreated;

    public ClusterMap(Graph graph) throws GraphSizeException {
	this.neighborhood = new Neighborhood(graph);
	this.graphWhenCreated = graph;

	put(GraphType.CLIQUE, new CliqueCluster(graph, neighborhood));
	put(GraphType.HUB, new HubCluster(graph, neighborhood));
	put(GraphType.TREE, new TreeCluster(graph, neighborhood));
	put(GraphType.BIPARTITE, new BipartiteCluster(graph, neighborhood));
	put(GraphType.SPARSE, new SparseCluster(graph, neighborhood, this));

	assert graph.size() == this.get(GraphType.CLIQUE).getSize();
    }

    /**
     * For assertion mode only.
     * 
     * @return {@code false} if not all clusters of same mapping are equal sized
     */
    private boolean areAllMappedClustersEqualSized() {
	int s = this.get(GraphType.CLIQUE).getSize();

	for (Cluster c : this.values()) {
	    if (c.getSize() != s) {
		return false;
	    }
	}
	return true;
    }

    /**
     * @return minimal MDL of cluster (achieved by clustering by best graph
     *         type)
     */
    public double getMinMdl() {
	double minMdl = Double.POSITIVE_INFINITY;
	for (Cluster cluster : this.values()) {
	    if (cluster.getMdl() < minMdl) {
		minMdl = cluster.getMdl();
	    }
	}
	return minMdl;
    }

    /**
     * @return best cluster (consisting of graph/cluster type and node order)
     *         resulting in the minimal MDL
     */
    public Cluster getBestCluster() {
	// Cluster bestCluster = this.get(GraphType.CLIQUE);
	Cluster bestCluster = null;
	double minMdl = Double.POSITIVE_INFINITY;
	for (Cluster cluster : this.values()) {
	    if (cluster.getMdl() < minMdl) {
		minMdl = cluster.getMdl();
		bestCluster = cluster;
	    }
	}
	return bestCluster;
    }

    public GraphType getBestGraphType() {
	Cluster c = getBestCluster();
	if (c instanceof CliqueCluster) {
	    return GraphType.CLIQUE;
	}
	if (c instanceof HubCluster) {
	    return GraphType.HUB;
	}
	if (c instanceof BipartiteCluster) {
	    return GraphType.BIPARTITE;
	}
	if (c instanceof TreeCluster) {
	    return GraphType.TREE;
	}
	if (c instanceof SparseCluster) {
	    return GraphType.SPARSE;
	}
	assert false;
	return null;
    }

    /**
     * @return ArrayList of nodes of cluster resulting in minimal MDL
     */
    public ArrayList<Node> getBestClusteredNodes() throws NullPointerException {
	return getBestCluster().getClusteredNodes();
    }

    public Collection<Node> getBestClusteredNodesOrdered() {
	return getBestCluster().getOrderedClusteredNodes();
    }

    /**
     * @return cluster size (is asserted to be the same for all cluster types of
     *         this mapping, thus using CLIQUE (just randomly picked)).
     */
    public int clusterSize() {
	assert areAllMappedClustersEqualSized();
	return this.get(GraphType.CLIQUE).getSize();
    }

    /**
     * @param cm
     *            clusterMap for which existing connecting edges are counted.
     * @return Number of inter cluster existing connecting edges between this
     *         clusterMap and clusterMap cm.
     */
    public int existingConnectingEdges(ClusterMap cm) throws NullPointerException {
	int count = 0;
	for (Node node : getBestClusteredNodes()) {
	    for (Node neighbor : node.getNeighbors()) {
		if (cm.getBestClusteredNodes().contains(neighbor)) {
		    count++;
		}
	    }
	}
	return count;
    }

    /**
     * @param cm
     *            clusterMap for which possible connecting edges are counted.
     * @return Number of inter cluster possible connecting edges between this
     *         clusterMap and clusterMap cm.
     */
    public int possibleConnectingEdges(ClusterMap cm) {
	return clusterSize() * cm.clusterSize();
    }

    public void addNode(Node node) {
	neighborhood.addNode(node);
	isLastActionAddNode = true;
	lastActionNode = node;

	treeMap.put(SplitMergeClusterer.getGraphPosition(node), node);

	get(GraphType.CLIQUE).addNode(node, null);
	get(GraphType.HUB).addNode(node, null);
	get(GraphType.BIPARTITE).addNode(node, null);
	get(GraphType.TREE).addNode(node, treeMap.values());
	get(GraphType.SPARSE).addNode(node, null);
    }

    public void removeNode(Node node) throws GraphSizeException {
	isLastActionAddNode = false;
	lastActionNode = node;
	treeMap.remove(SplitMergeClusterer.getGraphPosition(node));

	get(GraphType.BIPARTITE).removeNode(node);
	neighborhood.removeNode(node);
	get(GraphType.TREE).removeNode(node);
	get(GraphType.CLIQUE).removeNode(node);
	get(GraphType.HUB).removeNode(node);
	get(GraphType.SPARSE).removeNode(node);
    }

    public void undo() {
	if (isLastActionAddNode) {
	    neighborhood.removeNode(lastActionNode);
	    treeMap.remove(SplitMergeClusterer.getGraphPosition(lastActionNode));
	} else {
	    neighborhood.addNode(lastActionNode);
	    treeMap.put(SplitMergeClusterer.getGraphPosition(lastActionNode), lastActionNode);
	}

	get(GraphType.CLIQUE).undo();
	get(GraphType.HUB).undo();
	get(GraphType.TREE).undo();
	get(GraphType.BIPARTITE).undo();
	get(GraphType.SPARSE).undo();
    }

    public String toString() {
	StringBuffer sb = new StringBuffer();

	sb.append(">> Best graph type is " + getBestCluster().getClass().toString().split("\\.")[3]
		+ "\n");

	sb.append("CLIQUE: " + this.get(GraphType.CLIQUE).mdl + "\n");

	sb.append("HUB: " + this.get(GraphType.HUB).mdl + "\n");

	sb.append(((TreeCluster) this.get(GraphType.TREE)).toString());

	sb.append("BIPARTITE: " + this.get(GraphType.BIPARTITE).mdl + " PC="
		+ ((BipartiteCluster) this.get(GraphType.BIPARTITE)).parameterCost() + " CC="
		+ ((BipartiteCluster) this.get(GraphType.BIPARTITE)).calculateCodingCost() + "\n");

	sb.append("SPARSE: " + this.get(GraphType.SPARSE).mdl + "\n");

	return sb.toString();
    }

    public boolean contains(Node node) {
	return neighborhood.contains(node);
    }

    public Graph getGraph() {
	return new Graph(new ArrayList<Node>(treeMap.values()));
    }

    public void buildTreeMap() {
	treeMap = new TreeMap<Integer, Node>();

	for (Node node : graphWhenCreated.getNodes()) {
	    treeMap.put(SplitMergeClusterer.getGraphPosition(node), node);
	}
    }

    public boolean isInfiniteMdlAllButSparse() {
	return Double.isInfinite(get(GraphType.CLIQUE).getMdl())
		&& Double.isInfinite(get(GraphType.HUB).getMdl())
		&& Double.isInfinite(get(GraphType.TREE).getMdl())
		&& Double.isInfinite(get(GraphType.BIPARTITE).getMdl());
    }

}
