package anonymizedPackage.graphMiner.graphClusterer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.SortedSet;
import java.util.TreeMap;

import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

public class Neighborhood extends HashMap<Node, LinkedHashSet<Node>> {

    private static final long serialVersionUID = 1210435095209161712L;

    private LinkedHashSet<Node> nodeSet;
    private HashMap<Node, TreeMap<Integer, Node>> nodeTreeMap;

    public Neighborhood(Graph graph) {
	LinkedHashSet<Node> graphSet = new LinkedHashSet<Node>(graph.getNodes());
	nodeSet = new LinkedHashSet<Node>();
	for (Node node : graph.getNodes()) {
	    nodeSet.add(node);
	    LinkedHashSet<Node> neighbors = new LinkedHashSet<Node>();
	    for (Node neighbor : node.getNeighbors()) {
		if (graphSet.contains(neighbor)) {
		    neighbors.add(neighbor);
		}
	    }
	    this.put(node, neighbors);
	}

	nodeTreeMap = new HashMap<Node, TreeMap<Integer, Node>>();
	for (Node node : this.keySet()) {
	    TreeMap<Integer, Node> tm = new TreeMap<Integer, Node>();
	    for (Node neighbor : this.get(node)) {
		tm.put(SplitMergeClusterer.getGraphPosition(neighbor), neighbor);
	    }
	    nodeTreeMap.put(node, tm);
	}
    }

    public void addNode(Node node) {
	LinkedHashSet<Node> neighborSet = new LinkedHashSet<Node>();
	for (Node neighbor : node.getNeighbors()) {
	    if (nodeSet.contains(neighbor)) {
		neighborSet.add(neighbor);
		this.get(neighbor).add(node);
		nodeTreeMap.get(neighbor).put(SplitMergeClusterer.getGraphPosition(node), node);
	    }
	}
	this.put(node, neighborSet);
	nodeSet.add(node);

	TreeMap<Integer, Node> tm = new TreeMap<Integer, Node>();
	for (Node neighbor : neighborSet) {
	    tm.put(SplitMergeClusterer.getGraphPosition(neighbor), neighbor);
	}
	nodeTreeMap.put(node, tm);

    }

    public void removeNode(Node node) {
	assert this.containsKey(node);
	
	for (Iterator<Node> iter = this.get(node).iterator(); iter.hasNext();) {
	    Node neighbor = iter.next();
	    this.get(neighbor).remove(node);
	    nodeTreeMap.get(neighbor).remove(SplitMergeClusterer.getGraphPosition(node));
	}
	
	
//	for (Node neighbor : this.get(node)) {
//	    this.get(neighbor).remove(node);
//	    nodeTreeMap.get(neighbor).remove(SplitMergeClusterer.getGraphPosition(node));
//	}
	
//	    for (Iterator<Edge> iter = edges.iterator(); iter.hasNext();) {
//		Edge edge = iter.next();
//		if (edge.containsAsNode(node)) {
//		    iter.remove();
//		}
//	    }
	
	nodeSet.remove(node);
	assert this.containsKey(node);
	this.remove(node);
	nodeTreeMap.remove(node);
    }

    /**
     * @return number of indirect edges in neighborhood
     */
    public int getEdgeCount() {
	int edgeCount = 0;
	for (Node node : this.keySet()) {
	    edgeCount += this.get(node).size();
	}
	return edgeCount / 2;
    }

    public String getAdjacencyMatrixString() {
	StringBuffer sb = new StringBuffer();
	ArrayList<Node> al = new ArrayList<Node>(nodeSet);

	for (int i = 0; i < al.size(); i++) {
	    for (int j = 0; j < al.size(); j++) {
		int n;
		if (this.get(al.get(i)).contains(al.get(j))) {
		    n = 1;
		} else {
		    n = 0;
		}
		sb.append(Integer.toString(n)).append(" ");
	    }
	    sb.append(System.lineSeparator());
	}
	return sb.toString();
    }

    public Node getMaxDegreeNode() {
	Node maxDegreeNode = null;
	int maxDegree = -1;
	int degree = 0;
	for (Node node : this.keySet()) {
	    degree = this.get(node).size();
	    if (degree > maxDegree) {
		maxDegreeNode = node;
		maxDegree = degree;
	    }
	}
	return maxDegreeNode;
    }

    public boolean contains(Node node) {
	return nodeSet.contains(node);
    }

    public Collection<Node> getSortedNeighbors(Node node){
	return nodeTreeMap.get(node).values();
    }
    
}
