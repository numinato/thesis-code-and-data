package anonymizedPackage.graphMiner.graphClusterer;

public class SplittingException extends Exception {

}
