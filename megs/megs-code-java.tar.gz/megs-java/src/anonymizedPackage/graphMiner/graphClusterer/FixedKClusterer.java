package anonymizedPackage.graphMiner.graphClusterer;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.GraphType;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

/**
 * 
 * @version $Id: Clustering.java 1898 2014-08-12 13:59:32Z goebl $
 */
public class FixedKClusterer extends Clusterer{

    private static int minimalClusterSize = 4;

    private Graph graph;
    private Mdl mdl;
    private LinkedList<Node> nodesToProcess;
    private int[] clusterBegins;
    private int k;
    private double minMdl;
    public ClusterMap[] clusterMap;

    public FixedKClusterer(Graph graph, int k) {
	super();
	this.graph = graph;
	this.k = k;
	clusterBegins = new int[k + 1];
	mdl = new Mdl(this, graph);
	init();
    }

    public void init() {
	setEqualClusterBegins();
//	initClusterMap();

	// this.clusterBegins = Arrays.copyOfRange(mdl.getClusterBegins(), 0,
	// mdl.getClusterBegins().length - 1);
	System.err.println("Diagonalizing graph..");
	long duration = System.currentTimeMillis();
//	graph.diagonalize(true);
	mdl.setOptimalGraph();

	System.err.println("Graph diagonalized [" + (System.currentTimeMillis() - duration) / 1000.0 + "s].");
	System.err.println("Refining cluster borders..");
	duration = System.currentTimeMillis();
	mode = Mode.INIT;

	boolean done = false;
	while (!done) {
	    try {
		refineIteratively();
		done = true;
	    } catch (ClusteringException e) {
		System.err.println("Empty clusters created. I will try again and again.");
		e.printStackTrace();
		setEqualClusterBegins();
//		initClusterMap();
		graph.diagonalize(true);
		mdl.setOptimalGraph();
	    }
	}

	mode = Mode.CLUSTERING;
	// reset clusterMaps
//	for (int i = 0; i < clusterMap.length; i++) {
//	    clusterMap[i] = new ClusterMap();
//	}
	// clusterBegins[0] = 0; clusterBegins[1] = 10; clusterBegins[2] = 20;
	System.err.println("Cluster borders refined [" + (System.currentTimeMillis() - duration) / 1000.0 + "s].");
	// createNodeProcessingOrder();
	mdl.isInitalized = true;
    }

//    /**
//     * Initializes ClusterMap.
//     */
//    private void initClusterMap() {
//	clusterMap = new ClusterMap[k];
//	for (int i = 0; i < clusterMap.length; i++) {
//	    clusterMap[i] = new ClusterMap();
//	}
//    }

    /**
     * Initializes clusters into equal partitions.
     */
    private void setEqualClusterBegins() {
	for (int i = 0; i < k; i++) {
	    clusterBegins[i] = i * graph.size() / k;
	}
	clusterBegins[k] = graph.size();
    }

    public Node nextNode() {
	if (nodesToProcess.isEmpty()) {
	    return null;
	} else {
	    return nodesToProcess.pop();
	}
    }

    public int step(Node node) {
	int nodeDestination = -1;
	System.err.println("Cluster begins at pop: " + Arrays.toString(clusterBegins));
	if (getClusterSize(node) > 3) { // minimum cluster size
	    nodeDestination = updateClustering(node);
	}
	return nodeDestination;
    }

    private int getClusterSize(Node node) {
	int clusterSize = 0;
	int nodeID = graph.getNodes().indexOf(node);
	for (int i = 0; i < clusterBegins.length; i++) {
	    if (clusterBegins[i] <= nodeID) {
		if (i == clusterBegins.length - 1) {
		    clusterSize = graph.size() - clusterBegins[i];
		    break;
		} else {
		    clusterSize = clusterBegins[i + 1] - clusterBegins[i];
		    break;
		}
	    }
	}
	System.err.println("Size of cluster containing NodeID " + graph.getNodes().indexOf(node) + " is: "
		+ clusterSize);
	return clusterSize;
    }

    private int updateClustering(Node nodeToMove) {
	double mdlMinCost = mdl.update(-1, -1, clusterBegins);
	double mdlCost;
	int nodeToMoveId = graph.getNodes().indexOf(nodeToMove);
	int oldPosition = graph.getNodes().indexOf(nodeToMove);
	int newPosition;
	int minMDLPosition = nodeToMoveId;
	int[] oldClusterBegins = clusterBegins.clone();
	int[] minMdlClusterBegins = clusterBegins.clone();

	for (int i = 0; i < k; i++) {

	    System.err.println("Move NodeID " + graph.getNodes().indexOf(nodeToMove) + " to cluster " + i
		    + ", clusterBegins = " + Arrays.toString(clusterBegins));

	    // find cluster ID of nodeToMove
	    int from = getClusterId(nodeToMoveId);
	    // move node only if cluster size is larger than minimal cluster
	    // size
	    if ((from == k - 1 && clusterBegins[from] < graph.size() - FixedKClusterer.minimalClusterSize)
		    || clusterBegins[from + 1] - clusterBegins[from] > FixedKClusterer.minimalClusterSize) {
		newPosition = i == k - 1 ? graph.size() - 1 : clusterBegins[i + 1] - 1;
		graph.moveNode(nodeToMoveId, newPosition);
		recalculateClusterBegins(from, i);
		mdlCost = mdl.update(graph.getNodes().indexOf(nodeToMove), -1, clusterBegins);
		mdl.reset();
		graph.moveNode(graph.getNodes().indexOf(nodeToMove), oldPosition);

		if (mdlCost < mdlMinCost) {
		    mdlMinCost = mdlCost;
		    minMDLPosition = newPosition;
		    minMdlClusterBegins = clusterBegins.clone();

		}
		clusterBegins = oldClusterBegins.clone();
	    }
	}

	graph.moveNode(nodeToMove, minMDLPosition);
	clusterBegins = minMdlClusterBegins;
	mdl.update(graph.getNodes().indexOf(nodeToMove), minMDLPosition, clusterBegins);
	graph.setNodes(mdl.getOptimalGraph());
	System.err.println("Current MDL = " + mdl.getCosts());
	System.err.println("Best position: Move NodeID " + graph.getNodes().indexOf(nodeToMove) + " to position "
		+ minMDLPosition + ", clusterBegins = " + Arrays.toString(clusterBegins));
	this.minMdl = mdlMinCost;
	return minMDLPosition;
    }

    private void recalculateClusterBegins(int from, int to) {
	for (int p = 0; p < clusterBegins.length; p++) {
	    if (from < p) {
		clusterBegins[p]--;
	    }
	}
	for (int p = 0; p < clusterBegins.length; p++) {
	    if (to < p) {
		clusterBegins[p]++;
	    }
	}
    }

    private int getClusterId(int nodeToMoveId) {
	int result = Arrays.binarySearch(clusterBegins, nodeToMoveId);
	if (result >= 0) {
	    return result;
	} else {
	    return -result - 2;
	}
    }

    private void recalculateClusterBegins(int nodeToMoveID, int idx, int clusterId) {
	System.err.println("Cluster begins before recalculation: " + Arrays.toString(clusterBegins));

	for (int p = 0; p < clusterBegins.length; p++) {
	    if (nodeToMoveID < clusterBegins[p]) {
		clusterBegins[p]--;
	    }
	}
	for (int p = 0; p < clusterBegins.length; p++) {
	    if (idx <= nodeToMoveID) { // correct with equal sign (=) ?
		if (clusterBegins[p] >= idx && clusterId != p) {
		    clusterBegins[p]++;
		}
	    }
	}
	System.err.println("Cluster begins after recalculation: " + Arrays.toString(clusterBegins));
    }

    public int[] getClusterBegins() {
	return Arrays.copyOf(clusterBegins, clusterBegins.length - 1);
    }

    public double getMinMdl() {
	return minMdl;
    }

    /**
     * Creates random order for processing nodes in clustering step
     */
    public void createNodeProcessingOrder() {
	nodesToProcess = new LinkedList<Node>(graph.getNodes());
	Collections.shuffle(nodesToProcess);
    }

    @Deprecated
    private int updateClusteringSlow(Node nodeToMove) {
	int clusterId = 0;
	int idx;
	double mdlMinCost = mdl.update(-1, -1, clusterBegins);
	double mdlCost;
	int nodeToMoveId = graph.getNodes().indexOf(nodeToMove);
	int oldPosition = graph.getNodes().indexOf(nodeToMove);
	int minMDLPosition = nodeToMoveId;
	int[] oldClusterBegins = clusterBegins.clone();
	int[] minMdlClusterBegins = clusterBegins.clone();

	for (int i = 0; i < (graph.size() + clusterBegins.length - 1); i++) {

	    System.err.println("Move NodeID " + graph.getNodes().indexOf(nodeToMove) + " to position " + i
		    + ", clusterBegins = " + Arrays.toString(clusterBegins));

	    if ((clusterId < clusterBegins.length - 1) && (i == clusterBegins[clusterId + 1] + clusterId + 1)) {
		clusterId++;
	    }
	    // else if (i == clusterBegins[clusterBegins.length - 1] + clusterId
	    // + 1) {
	    // clusterId++;
	    // }
	    idx = i - clusterId;

	    // if ((idx != nodeToMoveId + 1) && (idx != nodeToMoveId + 1)) {

	    graph.moveNode(nodeToMoveId, idx);
	    recalculateClusterBegins(nodeToMoveId, idx, clusterId);
	    mdlCost = mdl.update(graph.getNodes().indexOf(nodeToMove), idx, clusterBegins);
	    mdl.reset();
	    graph.moveNode(graph.getNodes().indexOf(nodeToMove), oldPosition);

	    if (mdlCost < mdlMinCost) {
		mdlMinCost = mdlCost;
		minMDLPosition = idx;
		minMdlClusterBegins = clusterBegins.clone();

	    }

	    clusterBegins = oldClusterBegins.clone();

	    // }
	}

	graph.moveNode(nodeToMove, minMDLPosition);
	clusterBegins = minMdlClusterBegins;
	mdl.update(graph.getNodes().indexOf(nodeToMove), minMDLPosition, clusterBegins);
	graph.setNodes(mdl.getOptimalGraph());
	System.err.println("Current MDL = " + mdl.getCosts());
	System.err.println("Best position: Move NodeID " + graph.getNodes().indexOf(nodeToMove) + " to position "
		+ minMDLPosition + ", clusterBegins = " + Arrays.toString(clusterBegins));
	this.minMdl = mdlMinCost;
	return minMDLPosition;
    }

    private void refineIteratively() throws ClusteringException {
	// more efficient: consider only clusters adjacent to changing cluster
	// border
	System.err.println(Arrays.toString(clusterBegins));
	mdl.updateAdjMatBuffer(); // necessary?
	mdl.setCosts();
	boolean hasChanged;
	int a;
	int a0;
	int b;
	int aOld;
	double initCostsLeft;
	double initCostsRight;
	for (int i = 0; i < clusterBegins.length - 2; i++) {
	    System.err.println(clusterBegins.length);
	    a0 = clusterBegins[i];
	    a = clusterBegins[i + 1];
	    b = clusterBegins[i + 2];
	    hasChanged = true;
	    while (hasChanged) {
		aOld = a;
//		if ((a - a0) / 2 <= 3 && (b - a) / 2 <= 3) {
//		    throw new ClusteringException("Cluster(s) too small to proceed!");
//		}
		initCostsLeft = mdl.initCosts(i + 1, a0 + (a - a0) / 2);
		initCostsRight = mdl.initCosts(i + 1, a + (b - a) / 2);

		if (initCostsLeft <= initCostsRight) {
		    b = a;
		    a = a0 + (a - a0) / 2;
		} else {
		    a0 = a;
		    a = a + (b - a) / 2;
		}
		if (a == aOld) {
		    hasChanged = false;
		}
	    }
	    clusterBegins[i + 1] = a;
	    System.err.println(Arrays.toString(clusterBegins));

	    // no cluster begin for minimal MDL found in interval
	    // [clusterBegins[i] clusterBegins[i + 2]]
	    if (clusterBegins[i + 1] < clusterBegins[i] + 2 || clusterBegins[i + 1] > clusterBegins[i + 2] - 2) {
		clusterBegins[i + 1] = clusterBegins[i + 2];
		for (int m = i + 2; m < k; m++) {
		    clusterBegins[m] = clusterBegins[i + 1] + (graph.size() - clusterBegins[i + 1]) * (m - i - 1)
			    / (k - i - 1);
		    // clusterBegins[m] = m * (graph.size() - clusterBegins[i])
		    // / (k-i);
		}
		if (clusterBegins[k] == clusterBegins[k - 1]) {
		    System.err.println(Arrays.toString(clusterBegins));
		    System.err
			    .println("I could not identify "
				    + k
				    + " clusters. Perhaps try again for k-1? Trying to set last cluster size to half distance.");
		    clusterBegins[k - 1] = clusterBegins[k - 2] + (clusterBegins[k] - clusterBegins[k - 2]) / 2;
		    i++;
		}
		i--;
	    }

	    // if (clusterBegins[i + 1] < clusterBegins[i] + 3) {
	    // System.err.println("Cluster size of cluster: " + i +
	    // " is < 3. Setting to 3");
	    // clusterBegins[i + 1] += 3;
	    // }

	}

    }

    public double getCosts() {
	return mdl.getCosts();
    }

    public GraphType[] getGraphTypes() {
	return mdl.getGraphTypes();
    }

    public double getMdlCosts(int i) {
	return mdl.mdlCosts[i];
    }

    public int[] getClusterBorders() {
	return clusterBegins;
    }

    public int getClusterBorders(int i) {
	return clusterBegins[i];
    }

    public void setClusterBorders(int i, int value) {
	this.clusterBegins[i] = value;
    }

}
