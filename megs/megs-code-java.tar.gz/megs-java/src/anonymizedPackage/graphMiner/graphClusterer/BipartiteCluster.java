package anonymizedPackage.graphMiner.graphClusterer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Random;
import java.util.TreeMap;

import anonymizedPackage.graphMiner.graphDrawer.accessories.Tools;
import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

public class BipartiteCluster extends Cluster {
    private Random r;
    private HashSet<Node> setA;
    private HashSet<Node> setB;
    private boolean isLastActionSetA;
    private int lastPosition;
    private int edgeCountBetweenSets;
    private int edgeCountInSets;
    private int possibleEdgesBetweenSets;
    private int possibleEdgesInSets;

    private int lastEdgeCountBetweenSets;
    private int lastEdgeCountInSets;
    private int lastPossibleEdgesBetweenSets;
    private int lastPossibleEdgesInSets;

    public BipartiteCluster(Graph graph, Neighborhood neighborhood) throws GraphSizeException {
	super(neighborhood);

	if (graph.size() < minClusterSize) {
	    throw new GraphSizeException("Too few nodes for bipartite cluster.");
	}

	mdl = 0.0;
	r = new Random();
	// TODO: Repeat for better results;
	partitionBipartite(graph);

	if (setA.size() == 1 || setB.size() == 1) {
	    // Special case: Subgraph is also HUB
	    mdl = Double.POSITIVE_INFINITY;
	}

	mdl += parameterCost() + initCodingCost();
    }

    private void partitionBipartite(Graph graph) {
	LinkedList<Node> nodes = new LinkedList<Node>(graph.getNodes());
	setA = new HashSet<Node>();
	setB = new HashSet<Node>();

	Collections.shuffle(nodes);
	setA.add(nodes.pop());
	setB.add(nodes.pop());

	while (!nodes.isEmpty()) {
	    Node node = nodes.pop();
	    int edgeCount = 0;
	    for (Node neighbor : neighborhood.get(node)) {
		if (setA.contains(neighbor)) {
		    edgeCount++;
		} else if (setB.contains(neighbor)) {
		    edgeCount--;
		}
	    }
	    if (edgeCount > 0) {
		setB.add(node);
	    } else if (edgeCount < 0) {
		setA.add(node);
	    } else {
		if (r.nextBoolean()) {
		    setA.add(node);
		} else {
		    setB.add(node);
		}
	    }
	}

	clusteredGraph = new Graph(graph.size());
	clusteredGraph.addAll(setA);
	clusteredGraph.addAll(setB);

    }

    /**
     * Returns parameter cost for
     * <ul>
     * <li>1. encoding edge probabilities inside and outside of 'bipartite area'
     * (= where edges should be for bipartiteness).</li>
     * 
     * <li>2. encoding for bipartite set id (= to which bipartite set a node
     * belongs) = 1 Bit for every node.</li>
     * </ul>
     */
    public double parameterCost() {
	double c = 0.0;

	// edge probability inside and outside
	c += 2 * 0.5 * Tools.log2(clusteredGraph.size());

	// bipartite set id
	c += clusteredGraph.size();

	// parameter cost for cluster/graph type
	c += Math.ceil(Tools.log2(clusterCodebookLength));

	// id costs for each node
	c += Tools.log2(Cluster.getN() / ((double) getSize())) * getSize();

	return c;
    }

    public double initCodingCost() {
	edgeCountBetweenSets = 0;
	edgeCountInSets = 0;
	HashSet<Node> oneSet = (setA.size() < setB.size()) ? setA : setB;
	HashSet<Node> otherSet = (oneSet.equals(setA)) ? setB : setA;

	for (Node node : oneSet) {
	    if (neighborhood.get(node) != null) {
		for (Node neighbor : neighborhood.get(node)) {
		    if (oneSet.contains(neighbor)) {
			edgeCountInSets++;
		    } else {
			edgeCountBetweenSets++;
		    }
		}
	    }
	}

	for (Node node : otherSet) {
	    if (neighborhood.get(node) != null) {
		for (Node neighbor : neighborhood.get(node)) {
		    if (otherSet.contains(neighbor)) {
			edgeCountInSets++;
		    }
		}
	    }
	}

	edgeCountInSets /= 2;

	possibleEdgesBetweenSets = (setA.size() * setB.size());
	possibleEdgesInSets = (setA.size() * setA.size() - setA.size()) / 2;
	possibleEdgesInSets += (setB.size() * setB.size() - setB.size()) / 2;

	return calculateCodingCost();
    }

    /**
     * @param cost
     * @return
     */
    double calculateCodingCost() {
	double cost = 0.0;

	if (edgeCountInSets > possibleEdgesInSets / 2.0) {
	    cost = Double.POSITIVE_INFINITY;
	} else if (edgeCountBetweenSets < possibleEdgesBetweenSets / 2.0) {
	    cost = Double.POSITIVE_INFINITY;
	} else {
	    cost += possibleEdgesInSets
		    * Tools.entropy(((double) edgeCountInSets) / possibleEdgesInSets);
	    cost += possibleEdgesBetweenSets
		    * Tools.entropy(((double) edgeCountBetweenSets) / possibleEdgesBetweenSets);
	}

	return cost;
    }

    @Override
    public void addNode(Node node, Collection<Node> nodes) {
	int countEdgesToA, countEdgesToB;

	lastMdl = mdl;
	lastActionNode = node;
	isLastActionAddNode = true;

	lastEdgeCountBetweenSets = edgeCountBetweenSets;
	lastEdgeCountInSets = edgeCountInSets;
	lastPossibleEdgesBetweenSets = possibleEdgesBetweenSets;
	lastPossibleEdgesInSets = possibleEdgesInSets;

	countEdgesToA = 0;
	countEdgesToB = 0;

	// add node to best set or to set A if equal

	for (Node neighbor : neighborhood.get(node)) {
	    if (setA.contains(neighbor)) {
		countEdgesToA++;
	    } else if (setB.contains(neighbor)) {
		countEdgesToB++;
	    }
	}

	if (countEdgesToA >= countEdgesToB) {
	    setB.add(node);
	    clusteredGraph.addNode(clusteredGraph.size() - 1, node);
	    isLastActionSetA = false;

	    edgeCountBetweenSets += countEdgesToA;
	    edgeCountInSets += countEdgesToB;
	    possibleEdgesBetweenSets += setA.size();
	    possibleEdgesInSets += setB.size();
	} else {
	    setA.add(node);
	    clusteredGraph.addNode(0, node);
	    isLastActionSetA = true;

	    edgeCountBetweenSets += countEdgesToB;
	    edgeCountInSets += countEdgesToA;
	    possibleEdgesBetweenSets += setB.size();
	    possibleEdgesInSets += setA.size();
	}

	mdl = parameterCost() + calculateCodingCost();
    }

    @Override
    public void removeNode(Node node) throws GraphSizeException {
	int countEdgesToA, countEdgesToB;

	lastEdgeCountBetweenSets = edgeCountBetweenSets;
	lastEdgeCountInSets = edgeCountInSets;
	lastPossibleEdgesBetweenSets = possibleEdgesBetweenSets;
	lastPossibleEdgesInSets = possibleEdgesInSets;

	countEdgesToA = 0;
	countEdgesToB = 0;

	if (clusteredGraph.size() < minClusterSize + 1) {
	    throw new GraphSizeException("Graph too small for bipartitness");
	}

	lastPosition = clusteredGraph.indexOf(node);

	lastMdl = mdl;
	lastActionNode = node;
	isLastActionAddNode = false;

	for (Node neighbor : neighborhood.get(node)) {
	    if (setA.contains(neighbor)) {
		countEdgesToA++;
	    } else if (setB.contains(neighbor)) {
		countEdgesToB++;
	    } else {
		assert false;
	    }
	}

	clusteredGraph.remove(node);
	if (setA.contains(node)) {
	    edgeCountBetweenSets -= countEdgesToB;
	    edgeCountInSets -= countEdgesToA;
	    possibleEdgesBetweenSets -= setB.size();
	    possibleEdgesInSets -= setA.size();
	    setA.remove(node);
	    isLastActionSetA = true;
	} else {
	    edgeCountBetweenSets -= countEdgesToA;
	    edgeCountInSets -= countEdgesToB;
	    possibleEdgesBetweenSets -= setA.size();
	    possibleEdgesInSets -= setB.size();
	    setB.remove(node);
	    isLastActionSetA = false;
	}

	mdl = parameterCost() + calculateCodingCost();
    }

    @Override
    public void undo() {
	if (lastActionNode != null) {
	    if (isLastActionAddNode) {
		clusteredGraph.remove(lastActionNode);
		if (isLastActionSetA) {
		    setA.remove(lastActionNode);
		} else {
		    setB.remove(lastActionNode);
		}
	    } else {
		clusteredGraph.addNode(lastPosition, lastActionNode);
		if (isLastActionSetA) {
		    setA.add(lastActionNode);
		} else {
		    setB.add(lastActionNode);
		}
	    }
	    mdl = lastMdl;

	    edgeCountBetweenSets = lastEdgeCountBetweenSets;
	    edgeCountInSets = lastEdgeCountInSets;
	    possibleEdgesBetweenSets = lastPossibleEdgesBetweenSets;
	    possibleEdgesInSets = lastPossibleEdgesInSets;

	    lastActionNode = null;
	}
    }

    public String toString() {
	StringBuffer sb = new StringBuffer();

	sb.append("==========\n");
	sb.append("edgeCountBetweenSets  = " + edgeCountBetweenSets + "\n");
	sb.append("edgeCountInSets  = " + edgeCountInSets + "\n");
	sb.append("possibleEdgesBetweenSets  = " + possibleEdgesBetweenSets + "\n");
	sb.append("possibleEdgesInSets  = " + possibleEdgesInSets + "\n");
	sb.append("==========\n");

	return sb.toString();
    }

    @Override
    public Collection<Node> getOrderedClusteredNodes() {
	ArrayList<Node> al;
	TreeMap<Integer, Node> tm;

	al = new ArrayList<Node>();
	tm = new TreeMap<Integer, Node>();
	for (Node node : this.setA) {
	    tm.put(SplitMergeClusterer.getGraphPosition(node), node);
	}
	al.addAll(tm.values());
	tm = new TreeMap<Integer, Node>();
	for (Node node : this.setB) {
	    tm.put(SplitMergeClusterer.getGraphPosition(node), node);
	}
	al.addAll(setB);

	return al;
    }
}
