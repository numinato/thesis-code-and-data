package anonymizedPackage.graphMiner.graphClusterer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import anonymizedPackage.graphMiner.graphDrawer.accessories.Tools;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

public class InterMap extends HashMap<Set<ClusterMap>, InterClusterArea> {

    private static final long serialVersionUID = -3881592144575267574L;

    public double getMdl() {
	int numberPossibleEdges = 0;
	int numberExistingEdges = 0;

	for (InterClusterArea inter : this.values()) {
	    numberPossibleEdges += inter.getNumberPossibleEdges();
	    numberExistingEdges += inter.getNumberExistingEdges();
	}
	return Tools.entropyCodingCost(numberExistingEdges, numberPossibleEdges);
    }

    public InterClusterArea get(ClusterMap cm1, ClusterMap cm2) {
	HashSet<ClusterMap> set = new HashSet<ClusterMap>();
	set.add(cm1);
	set.add(cm2);
	return get(set);
    }

    public ArrayList<InterClusterArea> getInters(ClusterMap cm) {
	ArrayList<InterClusterArea> al = new ArrayList<InterClusterArea>(0);
	for (Set<ClusterMap> set : this.keySet()) {
	    if (set.contains(cm)) {
		al.add(get(set));
	    }
	}
	return al;
    }

    public double getMdlWith(InterClusterArea i) {
	int numberPossibleEdges = 0;
	int numberExistingEdges = 0;

	for (InterClusterArea inter : this.values()) {
	    numberPossibleEdges += inter.getNumberPossibleEdges();
	    numberExistingEdges += inter.getNumberExistingEdges();
	}

	numberPossibleEdges += i.getNumberPossibleEdges();
	numberExistingEdges += i.getNumberExistingEdges();

	assert !Double.isNaN(Tools.entropyCodingCost(numberExistingEdges, numberPossibleEdges));

	return Tools.entropyCodingCost(numberExistingEdges, numberPossibleEdges);
    }

    public double getMdlWithout(InterClusterArea i) {
	int numberPossibleEdges = 0;
	int numberExistingEdges = 0;
//	System.err.println(">>");
	for (InterClusterArea inter : this.values()) {
	    numberPossibleEdges += inter.getNumberPossibleEdges();
	    numberExistingEdges += inter.getNumberExistingEdges();
	    // System.err.println(">>" + inter + ": " +
	    // inter.getNumberPossibleEdges() + " / "
	    // + inter.getNumberExistingEdges());
	}

	numberPossibleEdges -= i.getNumberPossibleEdges();
	numberExistingEdges -= i.getNumberExistingEdges();

	// System.err.println("Minus " + i.getNumberExistingEdges() + " / "
	// + i.getNumberPossibleEdges());

	// System.err.printf("numberExistingEdges=%d,numberPossibleEdges=%d%n",
	// numberExistingEdges,
	// numberPossibleEdges);
	return Tools.entropyCodingCost(numberExistingEdges, numberPossibleEdges);
    }

    public void removeInter(ClusterMap cm1, ClusterMap cm2) {
	HashSet<ClusterMap> hs = new HashSet<ClusterMap>();
	hs.add(cm1);
	hs.add(cm2);
	this.remove(hs);
    }

    public void addInter(ClusterMap cm1, ClusterMap cm2) {
	HashSet<ClusterMap> hs = new HashSet<ClusterMap>();
	hs.add(cm1);
	hs.add(cm2);
	this.put(hs, new InterClusterArea(cm1, cm2));
    }

    public void removeInters(HashSet<HashSet<ClusterMap>> toRemove) {
	for (HashSet<ClusterMap> hs : toRemove) {
	    remove(hs);
	}

    }

    public void addInters(HashSet<HashSet<ClusterMap>> toAdd) {
	for (HashSet<ClusterMap> hs : toAdd) {
	    put(hs,
		    new InterClusterArea((ClusterMap) hs.toArray()[0], (ClusterMap) hs.toArray()[1]));
	}

    }

    public void removeNode(ClusterMap cm, Node node) {
	for (InterClusterArea i : this.values()) {
	    if (i.getCm1().equals(cm) || i.getCm2().equals(cm)) {
		ClusterMap otherCm = i.getCm1().equals(cm) ? i.getCm2() : i.getCm1();
		if (cm.contains(node)) {
		    for (Node neighbor : node.getNeighbors()) {
			if (otherCm.contains(neighbor)) {
			    i.numberExistingEdges--;
			}
		    }
		    i.numberPossibleEdges -= otherCm.clusterSize();
		} else {
		    for (Node neighbor : node.getNeighbors()) {
			if (cm.contains(neighbor)) {
			    i.numberExistingEdges--;
			}
		    }
		    i.numberPossibleEdges -= cm.clusterSize();
		}

	    }
	}

    }

    public void addNode(ClusterMap cm, Node node) {
	for (InterClusterArea i : this.values()) {
	    if (i.getCm1().equals(cm) || i.getCm2().equals(cm)) {
		ClusterMap otherCm = i.getCm1().equals(cm) ? i.getCm2() : i.getCm1();
		if (cm.contains(node)) {
		    for (Node neighbor : node.getNeighbors()) {
			if (otherCm.contains(neighbor)) {
			    i.numberExistingEdges++;
			}
		    }
		    i.numberPossibleEdges += otherCm.clusterSize();
		} else {
		    for (Node neighbor : node.getNeighbors()) {
			if (cm.contains(neighbor)) {
			    i.numberExistingEdges++;
			}
		    }
		    i.numberPossibleEdges += cm.clusterSize();
		}

	    }
	}

    }

    public int getNumberPossibleEdges() {
	int numberPossibleEdges = 0;

	for (InterClusterArea inter : this.values()) {
	    numberPossibleEdges += inter.getNumberPossibleEdges();
	}
	return numberPossibleEdges;
    }

    public int getNumberExistingEdges() {
	int numberExistingEdges = 0;

	for (InterClusterArea inter : this.values()) {
	    numberExistingEdges += inter.getNumberExistingEdges();
	}
	return numberExistingEdges;
    }

}
