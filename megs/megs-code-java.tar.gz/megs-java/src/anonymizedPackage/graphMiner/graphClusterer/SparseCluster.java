package anonymizedPackage.graphMiner.graphClusterer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.TreeMap;

import anonymizedPackage.graphMiner.graphDrawer.accessories.Tools;
import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

public class SparseCluster extends Cluster {

    private ClusterMap clusterMap;

    public SparseCluster(Graph graph, Neighborhood neighborhood, ClusterMap clusterMap) {
	super(neighborhood);
	clusteredGraph = new Graph(graph);
	this.clusterMap = clusterMap;
	mdl += codingCost();
	mdl += parameterCost();
    }

    private double codingCost() {
	int possibleEdges = (getSize() * getSize() - getSize()) / 2;
	int edgeCount = neighborhood.getEdgeCount();

	// if less than half edges
	if (edgeCount > possibleEdges / 2.0) {
	    return Double.POSITIVE_INFINITY;
	    // } else if (SplitMergeClusterer.hasSparse
	    // && ClusterMap.largestConnectedComponentSize >=
	    // clusteredGraph.size() / 2.0
	    // && !clusterMap.isInfiniteMdlAllButSparse()) {
	    // return Double.POSITIVE_INFINITY;
	} else {
	    // return edges entropy-encoded
	    return possibleEdges * Tools.entropy(((double) edgeCount) / possibleEdges);
	}
    }

    private double parameterCost() {
	double c = 0.0;

	// parameter cost for encoding edge probability
	c += 0.5 * Tools.log2(getSize());

	// parameter cost for cluster/graph type
	c += Math.ceil(Tools.log2(clusterCodebookLength));

	// id costs for each node
	c += Tools.log2(Cluster.getN() / ((double) getSize())) * getSize();

	return c;
    }

    @Override
    public void addNode(Node node, Collection<Node> nodes) {
	lastMdl = mdl;
	lastActionNode = node;
	isLastActionAddNode = true;
	clusteredGraph.add(node);
	mdl = codingCost();
	mdl += parameterCost();

    }

    @Override
    public void removeNode(Node node) throws GraphSizeException {
	if (clusteredGraph.size() < minClusterSize + 1) {
	    throw new GraphSizeException("Cluster too small.");
	}
	lastMdl = mdl;
	lastActionNode = node;
	isLastActionAddNode = false;
	clusteredGraph.remove(node);
	mdl = codingCost();
	mdl += parameterCost();
    }

    @Override
    public void undo() {
	if (lastActionNode != null) {
	    mdl = lastMdl;
	    if (isLastActionAddNode) {
		clusteredGraph.remove(lastActionNode);
	    } else {
		clusteredGraph.add(lastActionNode);
	    }
	    lastActionNode = null;
	}
    }

    @Override
    public Collection<Node> getOrderedClusteredNodes() {
	TreeMap<Integer, Node> tm = new TreeMap<Integer, Node>();
	for (Node node : this.getClusteredNodes()) {
	    tm.put(SplitMergeClusterer.getGraphPosition(node), node);
	}
	return new ArrayList<Node>(tm.values());
    }

}
