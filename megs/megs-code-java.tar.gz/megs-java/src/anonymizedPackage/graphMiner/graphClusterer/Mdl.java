package anonymizedPackage.graphMiner.graphClusterer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;

import anonymizedPackage.graphMiner.graphClusterer.Clusterer.Mode;
import anonymizedPackage.graphMiner.graphDrawer.accessories.Tools;
import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.GraphType;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

/**
 * 
 * @version $Id: Mdl.java 2145 2015-01-27 09:56:09Z goebl $
 */
@Deprecated
public class Mdl {

    public static final int BIPARTITENESS_RUNS = 50;

    double clog2n; // constant for ceil(log2(n))
    Graph graph;
    public double[] mdlCosts;
    GraphType[] graphTypes;
    HashMap<GraphType, ArrayList<Node>> alternativeNodes;
    ArrayList<Node> optimalGraph;
    Clusterer clusterer;
    int[][] adjacencyMatrixBuffer;
    int graphSize;
    int k;
    int eInterMax;
    ArrayList<Node>[] oldBipartiteOrder;
    double[] oldBipartiteMdl;
    ArrayList<Node> savedOptimalGraph;

    public boolean isInitalized;

    @SuppressWarnings("unchecked")
    public Mdl(Clusterer clustering, Graph graph) {
	this.clusterer = clustering;
	this.graph = graph;
//	k = clustering.getClusterBorders().length - 1;
	k=1;
	graphSize = graph.size();
	graphTypes = new GraphType[k];
	mdlCosts = new double[k];
	clog2n = Math.ceil(Math.log(graph.size()) / Math.log(2));
	setEInterMax();

	updateAdjMatBuffer();
	graph.getAdjacencyMatrix(); // DEBUG0815
	// setCosts();
	isInitalized = false;
	oldBipartiteMdl = new double[k];
	oldBipartiteOrder = new ArrayList[k];

    }

    private void setEInterMax() {
	eInterMax = 0;
	int tmp;
	for (int i = 0; i < k; i++) {
	    tmp = 0;
	    for (int j = 0; j <= i; j++) {
		tmp += clusterer.getClusterBorders(j + 1) - clusterer.getClusterBorders(j);
	    }
	    eInterMax += (clusterer.getClusterBorders(i + 1) - clusterer.getClusterBorders(i)) * (graph.size() - tmp);
	}
    }

    public double initCosts(int i, int newPosition) throws ClusteringException {
	double result;
	int oldPosition = clusterer.getClusterBorders(i);

	clusterer.setClusterBorders(i, newPosition);
	// check for empty clusters
	for (int j = 0; j < clusterer.getClusterBorders().length - 1; j++) {
	    if (clusterer.getClusterBorders(j + 1) - clusterer.getClusterBorders(j) <= 1) {
		throw new ClusteringException("Empty Cluster(s) created");
	    }
	}
	// for (int j = 0; j < clustering.getClusterBorders().length - 1; j++) {
	// if (clustering.getClusterBorders(j + 1) -
	// clustering.getClusterBorders(j) <= 3) {
	// throw new ClusteringException("Too small Cluster(s) created");
	// }
	// }

	setCosts();
	result = getCosts();
	clusterer.setClusterBorders(i, oldPosition);
	setCosts();
	return result;
    }

    // public double splitCosts(int i) {
    // double result;
    // int newClusterBegin = (clustering.getClusterBorders(i + 1) -
    // clustering.getClusterBorders(i)) / 2;
    // int oldPosition = clustering.getClusterBorders(i);
    //
    // clustering.insertCluster(i+1,newClusterBegin);
    //
    // clustering.setClusterBorders(i, newPosition);
    //
    // clustering.removeCluster(i + 1);
    //
    // setCosts();
    // result = getCosts();
    // clustering.setClusterBorders(i, oldPosition);
    // setCosts();
    // return result;
    // }

    // private void setClusterBegins(int[] clusterPositions) {
    // clusterBegins = Arrays.copyOf(clusterPositions, clusterPositions.length +
    // 1);
    // clusterBegins[clusterBegins.length - 1] = graphSize;
    // }

    /**
     * Calculates minimum description length for current clustering. All
     * necessary costs for losslessly transmitting the graph are included. None
     * left away due to constant values.
     * 
     * @return total MDL transmission cost
     */
    public double getCosts() {
	double cost = 0.0;

	// cost for encoding total number of nodes (= total graph dimension)
	cost += Tools.logstar2(graph.size());

	// cost for inter-cluster edges
	cost += getCostInterClusterErrors();

	// cluster ID cost
	cost += clusterIdCost();

	for (double d : mdlCosts) {
	    cost += d;
	}
	assert !Double.isNaN(cost);
	return cost;
    }

    private double clusterIdCost() {
	double clusterIdCost = 0.0;

	for (ClusterMap cm : clusterer.clustering) {
	    clusterIdCost += Tools.log2(graph.size() / cm.clusterSize());
	}

	return clusterIdCost;
    }

    public GraphType[] getGraphTypes() {
	return graphTypes;
    }

    public void setCosts() {
	graph.getAdjacencyMatrix();
	int[] clustersToProcess = new int[k];
	for (int i = 0; i < k; i++) {
	    clustersToProcess[i] = i;
	}
	setCosts(clustersToProcess);
	graph.getAdjacencyMatrix();
    }

    private void setCosts(int[] clustersToProcess) {
	// set best MDL costs for each cluster
	// System.out.println("\nBest MDL:");
	for (int i : clustersToProcess) {
	    calculateClusterModel(i);
	}
	// graph.setNodes(optimalGraph);
    }

    private void calculateClusterModel(int clusterID) {
	double minCost = Double.MAX_VALUE;
	double cost = 0.0;
	alternativeNodes = new HashMap<GraphType, ArrayList<Node>>();

	// cost for coding cluster information
	// mdlCosts[clusterID] = clog2n; // cluster size

	// cost for encoding cluster ids for each node of cluster
	// mdlCosts[clusterID] = clusterSize(clusterID) * Tools.log2(k);

	updateAdjMatBuffer();
	mdlCosts[clusterID] = 0.0;

	// find minimal cost for coding edges
	for (GraphType gt : GraphType.values()) {
	    updateAdjMatBuffer();
	    // graph.printAdjacencyMatrix();
	    ArrayList<Node> oldNodes = new ArrayList<Node>(graph.getNodes());
	    cost = cost(clusterID, gt);
	    graph.setNodes(oldNodes);
	    // graph.printAdjacencyMatrix();
	    // System.out.printf("Cluster %d (Nodes %d->%d): MDL cost (without cluster cost) for %s is: %.2f%n",
	    // clusterID, clustering.getClusterBorders()[clusterID],
	    // clustering.getClusterBorders()[clusterID + 1] - 1, gt.toString(),
	    // cost);
	    if (cost < minCost) {
		minCost = cost;
		graphTypes[clusterID] = gt;
	    }
	}

	if (clusterer.getClusterBorders()[clusterID] + 1 == clusterer.getClusterBorders()[clusterID + 1] - 1) {
	    mdlCosts[clusterID] = Double.POSITIVE_INFINITY;
	} else {
	    // add nodes ordered in minimal MDL structure to optimal graph
	    optimalGraph
		    .subList(clusterer.getClusterBorders()[clusterID], clusterer.getClusterBorders()[clusterID + 1])
		    .clear();
	    optimalGraph.addAll(clusterer.getClusterBorders()[clusterID], alternativeNodes.get(graphTypes[clusterID]));

	    mdlCosts[clusterID] += minCost;
	}
    }

    private double getCostInterClusterErrors() {
	int possibleEdgeCount = 0;
	int existingEdgeCount = 0;
	double edgeProbability;

	for (int i = 0; i < clusterer.clustering.size(); i++) {
	    for (int j = i + 1; j < clusterer.clustering.size(); j++) {
		possibleEdgeCount += clusterer.clustering.get(i).possibleConnectingEdges(clusterer.clustering.get(j));
		existingEdgeCount += clusterer.clustering.get(i).existingConnectingEdges(clusterer.clustering.get(j));
	    }
	}

	return Tools.entropyCodingCost(existingEdgeCount, possibleEdgeCount);
    }

    @Deprecated
    private double costInterClusterErrors_old() {
	int possibleEdgeCount = 0;
	int existingEdgeCount = 0;
	double edgeProbability;
	double cost = 0.0;

	updateAdjMatBuffer();
	for (int i = 1; i < k; i++) {
	    for (int col = clusterer.getClusterBorders(i); col < graph.size(); col++) {
		for (int row = clusterer.getClusterBorders(i - 1); row < clusterer.getClusterBorders(i); row++) {
		    possibleEdgeCount++;
		    existingEdgeCount += adjacencyMatrixBuffer[row][col];
		}
	    }
	}

	edgeProbability = possibleEdgeCount == 0 ? 0 : ((double) existingEdgeCount) / possibleEdgeCount;
	cost += possibleEdgeCount * Tools.entropy(edgeProbability);

	// edge probability
	// cost += 0.5 * Tools.log2(v)
	return cost;
    }

    private double cost(int i, GraphType gt) {
	switch (gt) {
	case CLIQUE:
	    return costClique(i);
	case HUB:
	    return costHub(i);
	case TREE:
	    return costTree(i);
	case BIPARTITE:
	    return costBipartite(i);
	}
	try {
	    assert false;
	    throw new Exception("Unhandled GraphType");
	} catch (Exception e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	    return Double.MAX_VALUE;
	}
    }

    private double costClique(int i) {
	int firstNodeID = clusterer.getClusterBorders()[i];
	int lastNodeID = clusterer.getClusterBorders()[i + 1] - 1;
	Graph subgraph = graph.subgraph(firstNodeID, lastNodeID);
	Cluster cluster = new CliqueCluster(subgraph, null);

	// save clique graph ordering (= default ordering)
	saveSubgraphNodeOrder(GraphType.CLIQUE, firstNodeID, lastNodeID);

	clusterer.clustering.get(i).put(GraphType.CLIQUE, cluster);

	return cluster.getMdl();
    }

    private double costHub(int i) {
	int firstNodeID = clusterer.getClusterBorders()[i];
	int lastNodeID = clusterer.getClusterBorders()[i + 1] - 1;
	Graph subgraph = graph.subgraph(firstNodeID, lastNodeID);
	HubCluster cluster = new HubCluster(subgraph, null);

	alternativeNodes.put(GraphType.HUB, cluster.getClusteredNodes());
	clusterer.clustering.get(i).put(GraphType.HUB, cluster);

	return cluster.getMdl();
    }

    // if more non-edges than edges in hub: cost is infinite
    // if (edgeCount < (clusterSize - 1) / 2.0){
    // cost = Double.POSITIVE_INFINITY;
    // }

    private double costBipartite(int i) {
	double cost;
	BipartiteCluster cluster = (BipartiteCluster) clusterer.clustering.get(i).get(GraphType.BIPARTITE);
	int firstNodeID = clusterer.getClusterBorders()[i];
	int lastNodeID = clusterer.getClusterBorders()[i + 1] - 1;
	Graph subgraph = graph.subgraph(firstNodeID, lastNodeID);

	try {
	    if (clusterer.mode == Mode.INIT || cluster == null) {
		cluster = new BipartiteCluster(subgraph, null);
		clusterer.clustering.get(i).put(GraphType.BIPARTITE, cluster);
	    } else {
		// **************************************************************************************
		// work-around adapter before refactoring of clustering
		// algorithm
		if (subgraph.size() > cluster.getClusteredNodes().size()) {
		    // add node: find out which
		    cluster.addNode((Node) Tools.findDifferentElement(cluster.getClusteredNodes(), subgraph.getNodes()), null);
		} else if (subgraph.size() < cluster.getClusteredNodes().size()) {
		    // remove node: find out which
		    cluster.removeNode((Node) Tools.findDifferentElement(cluster.getClusteredNodes(),
			    subgraph.getNodes()));
		} else {
		    // no change, no action needed.
		}
		// **************************************************************************************
	    }

	} catch (GraphSizeException e) {
	    cluster = null;
	}

	if (cluster == null) {
	    cost = Double.MAX_VALUE / 2.0;
	    alternativeNodes.put(GraphType.BIPARTITE, null);
	    clusterer.clustering.get(i).remove(GraphType.BIPARTITE);
	} else {
	    cost = cluster.getMdl();
	    alternativeNodes.put(GraphType.BIPARTITE, cluster.getClusteredNodes());
	}
	return cost;
    }

    private double costTree(int i) {
	double cost = 0.0;
	int firstNodeId = clusterer.getClusterBorders()[i];
	int lastNodeId = clusterer.getClusterBorders()[i + 1] - 1;

	Graph subgraph = graph.subgraph(firstNodeId, lastNodeId);

	try {
	    TreeCluster cluster = new TreeCluster(subgraph, null);
	    alternativeNodes.put(GraphType.TREE, cluster.getClusteredNodes());
	    clusterer.clustering.get(i).put(GraphType.TREE, cluster);
	    cost = cluster.getMdl();
	} catch (GraphSizeException ce) {
	    alternativeNodes.put(GraphType.TREE, null);
	    clusterer.clustering.get(i).remove(GraphType.TREE);
	    cost = Double.MAX_VALUE / 2.0;
	}

	return cost;
    }

    /**
     * Sorts adjacency matrix for tree (Visibility set to package protected for
     * testing)
     * 
     * @param startNodeID
     *            start node of tree
     * @param endNodeID
     *            end node of tree (inclusive)
     * @param rootNodeID
     *            root of tree
     */
    void sortTree(int startNodeID, int endNodeID, int rootNodeID) {

	// gdm.printAdjacencyMatrix();
	LinkedList<Node> nodesToSwap = new LinkedList<Node>();
	HashSet<Node> nodesSwapped = new HashSet<Node>();
	Node nodeToSwap = null;
	int swapNodePosition = startNodeID;
	int currentNodeID;

	nodesToSwap.add(graph.getNodes().get(rootNodeID));

	while (!nodesToSwap.isEmpty()) {
	    nodeToSwap = nodesToSwap.pop();
	    nodesSwapped.add(nodeToSwap);
	    // enlist neighboring nodes for swapping if not already swapped
	    for (Node node : nodeToSwap.getNeighbors()) {
		if (!nodesSwapped.contains(node) && (graph.getNodes().indexOf(node) >= startNodeID)
			&& (graph.getNodes().indexOf(node) <= endNodeID) && !nodesToSwap.contains(node)) {
		    nodesToSwap.add(node);
		}
	    }
	    // swap node if necessary
	    currentNodeID = graph.getNodes().indexOf(nodeToSwap);
	    if (currentNodeID != swapNodePosition) {
		graph.swapNodes(currentNodeID, swapNodePosition);
	    }
	    nodesSwapped.add(nodeToSwap);
	    swapNodePosition++;
	    // gdm.printAdjacencyMatrix();
	}
	// gdm.printAdjacencyMatrix();
    }

    /**
     * Returns node ID of node with highest degree of given interval
     * [firstNodeID .. lastNodeID]. If nodes of equal degree exist, smallest ID
     * is returned.
     * 
     * @param firstNodeID
     * @param lastNodeID
     * @return node ID with highest degree
     */
    private int getHighestDegreeNodeID(int firstNodeID, int lastNodeID) {
	int highestDegreeNodeID = firstNodeID;
	int highestDegree = 0;
	int degree = 0;
	for (int i = firstNodeID; i <= lastNodeID; i++) {
	    degree = graph.getDegree(i, firstNodeID, lastNodeID);
	    if (degree > highestDegree) {
		highestDegreeNodeID = i;
		highestDegree = degree;
	    }
	}
	return highestDegreeNodeID;
    }

    private Node getHighestDegreeNode(int firstNodeID, int lastNodeID) {
	return graph.getNode(getHighestDegreeNodeID(firstNodeID, lastNodeID));

    }

    /**
     * Roughly coded. Needs refactoring for speed and looks.
     * 
     * @param firstNodeID
     * @param lastNodeID
     * @return
     */
    private int getRootNodeID(int firstNodeID, int lastNodeID) {
	ArrayList<ArrayList<Integer>> adjList = new ArrayList<ArrayList<Integer>>();
	for (int i = firstNodeID; i <= lastNodeID; i++) {
	    ArrayList<Integer> nodeAL = new ArrayList<Integer>();
	    nodeAL.add(i);
	    adjList.add(nodeAL);
	}

	boolean changed = true;
	while (changed) {
	    changed = false;
	    int adjListSize = adjList.size();
	    for (int i = 0; i < adjListSize; i++) {
		ArrayList<Integer> al = adjList.get(i);
		if (al.size() > 0) {
		    // System.err.println();
		    // System.err.print("From node " + al.get(al.size() - 1) +
		    // ":");
		    boolean isChangedNode = false;
		    for (Node neighboringNode : graph.getNodes().get(al.get(al.size() - 1)).getNeighbors()) {
			boolean contained = false;
			int nnID = graph.getNodes().indexOf(neighboringNode);
			// System.err.print(nnID + ",");
			if (nnID >= firstNodeID && nnID <= lastNodeID) {
			    for (Integer integer : al) {
				if (integer.intValue() == nnID) {
				    contained = true;
				}
			    }
			    if (!contained) {
				ArrayList<Integer> newList = new ArrayList<Integer>(al);
				newList.add(graph.getNodes().indexOf(neighboringNode));
				adjList.add(newList);
				isChangedNode = true;
				changed = true;
			    }
			}

		    }
		    if (isChangedNode) {
			al.removeAll(al);
		    }
		}
	    }
	}

	for (ArrayList<Integer> ali : adjList) {
	    // System.err.print(adjList.indexOf(ali));
	    for (Integer integer : ali) {
		// System.err.print("[" + integer + "] ");
	    }
	    // System.err.println();

	}
	// gdm.printAdjacencyMatrix();
	int maxPathLength = adjList.get(adjList.size() - 1).size();
	ArrayList<ArrayList<Integer>> alLongest = new ArrayList<ArrayList<Integer>>();
	for (ArrayList<Integer> alint : adjList) {
	    if (alint.size() == maxPathLength) {
		alLongest.add(alint);
	    }
	}
	// for now: use only one of the longest paths
	int[] longestArr = new int[maxPathLength];
	for (int i = 0; i < longestArr.length; i++) {
	    longestArr[i] = adjList.get(adjList.size() - 1).get(i);
	    // System.err.println(longestArr[i]);
	}
	// for now: don't mind if neighbors are not in subgraph
	int middleElement = (int) Math.ceil((double) (longestArr.length - 1) / 2.0);
	int highestDegreeElement = -1;
	int highestDegree = -1;
	for (int i = middleElement; i < longestArr.length; i++) {
	    if (graph.getNodes().get(longestArr[i]).getNeighbors().size() > highestDegree) {
		highestDegree = graph.getNodes().get(longestArr[i]).getNeighbors().size();
		highestDegreeElement = longestArr[i];
	    }
	    if (longestArr.length - i >= 0) {
		if (graph.getNodes().get(longestArr[longestArr.length - i]).getNeighbors().size() > highestDegree) {
		    highestDegree = graph.getNodes().get(longestArr[longestArr.length - i]).getNeighbors().size();
		    highestDegreeElement = longestArr[longestArr.length - i];
		}
	    }
	}
	// System.err.println("highestDegree=" + highestDegree);
	// System.err.println("highestDegreeElement=" + highestDegreeElement);

	return highestDegreeElement;
    }

    private void saveSubgraphNodeOrder(GraphType gt, int start, int end) {
	alternativeNodes.put(gt, new ArrayList<Node>(graph.getNodes().subList(start, end + 1)));
	// alternativeNodes.put(gt, new ArrayList<Node>(graph.getNodes()));
    }

    public void updateAdjMatBuffer() {
	adjacencyMatrixBuffer = graph.getAdjacencyMatrix();
    }

    public double update(int i, int j, int[] clusterBegins) {
	savedOptimalGraph = new ArrayList<Node>(optimalGraph);
	mdlCosts = new double[k];
	setCosts();
	return getCosts();
    }

    public void reset() {
	optimalGraph = new ArrayList<Node>(savedOptimalGraph);
    }

    public ArrayList<Node> getOptimalGraph() {
	return optimalGraph;
    }

    public int[] getClusterBegins() {
	return clusterer.getClusterBorders();
    }

    public void setOptimalGraph() {
	optimalGraph = new ArrayList<Node>(graph.getNodes());
    }

    private int clusterSize(int clusterId) {
	return clusterer.getClusterBorders(clusterId + 1) - clusterer.getClusterBorders(clusterId);
    }

    /**
     * Sorts adjacency matrix for tree (Visibility set to package protected for
     * testing)
     * 
     * @param startNodeID
     *            start node of tree
     * @param endNodeID
     *            end node of tree (inclusive)
     * @param rootNodeID
     *            root of tree
     */
    @Deprecated
    void sortTreeOld(int startNodeID, int endNodeID, int rootNodeID) {
	// swap nodes
	ArrayList<Node> nodesToSwap = new ArrayList<Node>();
	nodesToSwap.add(graph.getNodes().get(rootNodeID));
	int currentNodeID = startNodeID;
	while (currentNodeID <= endNodeID) {
	    for (int j = 0; j < nodesToSwap.size(); j++) {
		if (nodesToSwap.get(j) != null) {
		    int swapNodeID = graph.getNodes().indexOf(nodesToSwap.get(j));
		    if (swapNodeID > currentNodeID && swapNodeID <= endNodeID) {
			// if (subcostTree(startNodeID, currentNodeID))
			graph.swapNodes(currentNodeID, swapNodeID);
			nodesToSwap.set(j, null);
			for (Node n : graph.getNodes().get(currentNodeID).getNeighbors()) {
			    int nID = graph.getNodes().indexOf(n);
			    if (nID > currentNodeID && nID <= endNodeID) {
				nodesToSwap.add(n);
			    }
			}
			currentNodeID++;

		    }
		    if (swapNodeID == currentNodeID) {
			nodesToSwap.set(j, null);
			for (Node n : graph.getNodes().get(currentNodeID).getNeighbors()) {
			    int nID = graph.getNodes().indexOf(n);
			    if (nID > currentNodeID && nID <= endNodeID) {
				nodesToSwap.add(n);
			    }
			}
			currentNodeID++;
		    }

		    graph.printAdjacencyMatrix();
		}
	    }
	}
    }

    /* for testing */
    @Deprecated
    int[][] sortTreeMatrix(int startNodeID, int endNodeID, int rootNodeID, int[][] adjacencyMatrix) {
	// swap nodes
	ArrayList<Node> nodesToSwap = new ArrayList<Node>();
	nodesToSwap.add(graph.getNodes().get(rootNodeID));
	int currentNodeID = startNodeID;
	while (currentNodeID <= endNodeID) {
	    for (int j = 0; j < nodesToSwap.size(); j++) {
		if (nodesToSwap.get(j) != null) {
		    int swapNodeID = graph.getNodes().indexOf(nodesToSwap.get(j));
		    if (swapNodeID > currentNodeID && swapNodeID <= endNodeID) {
			// if (subcostTree(startNodeID, currentNodeID))
			graph.swapNodes(currentNodeID, swapNodeID);
			nodesToSwap.set(j, null);
			for (Node n : graph.getNodes().get(currentNodeID).getNeighbors()) {
			    int nID = graph.getNodes().indexOf(n);
			    if (nID > currentNodeID && nID <= endNodeID) {
				nodesToSwap.add(n);
			    }
			}
			currentNodeID++;

		    }
		    if (swapNodeID == currentNodeID) {
			nodesToSwap.set(j, null);
			for (Node n : graph.getNodes().get(currentNodeID).getNeighbors()) {
			    int nID = graph.getNodes().indexOf(n);
			    if (nID > currentNodeID && nID <= endNodeID) {
				nodesToSwap.add(n);
			    }
			}
			currentNodeID++;
		    }

		    graph.printAdjacencyMatrix();
		}
	    }
	}
	return adjacencyMatrix;
    }

    @Deprecated
    private double costTreeOld(int i) {
	double cost = 0.0;
	int firstNodeId = clusterer.getClusterBorders()[i];
	int lastNodeId = clusterer.getClusterBorders()[i + 1] - 1;
	Graph subgraph = graph.subgraph(firstNodeId, lastNodeId);

	double mdl = 0.0;
	Node currentNode = getHighestDegreeNode(firstNodeId, lastNodeId);
	LinkedList<Node> allNodesToProcess = new LinkedList<Node>(subgraph.getNodes());
	LinkedList<Node> nextNodesToProcess = new LinkedList<Node>();
	// TODO: create this list only once in composite field:
	ArrayList<Node> treeOrderedNodes = new ArrayList<Node>(allNodesToProcess.size());

	HashSet<Node> visitedNodes = new HashSet<Node>();
	visitedNodes.add(currentNode);

	while (currentNode != null) {

	    if (allNodesToProcess.remove(currentNode)) {
		visitedNodes.add(currentNode);
		treeOrderedNodes.add(currentNode);
		for (Node neighbor : currentNode.getNeighbors()) {
		    if (subgraph.contains(neighbor)) {
			nextNodesToProcess.add(neighbor);
		    }
		}
	    }

	    if ((currentNode = nextNodesToProcess.poll()) == null) {
		if (allNodesToProcess.isEmpty()) {
		    currentNode = null;
		} else {
		    currentNode = allNodesToProcess.getFirst();
		    mdl++;
		}
	    } else if (!visitedNodes.contains(currentNode)) {
		mdl--;
	    }
	}

	for (Node node : treeOrderedNodes) {
	    mdl += graph.getNumberOfNeighbors(node, lastNodeId);
	}

	alternativeNodes.put(GraphType.TREE, treeOrderedNodes);
	return mdl * 2.0 * Math.ceil(Tools.log2(graph.size())) + 2.0 * (lastNodeId - firstNodeId + 1)
		* Math.ceil(Tools.log2(graph.size()));
    }

}
