package anonymizedPackage.graphMiner.graphClusterer;

import java.util.HashSet;

import anonymizedPackage.graphMiner.graphDrawer.model.Node;

public class InterClusterArea {
    private HashSet<ClusterMap> cmSet;
    private ClusterMap cm1;
    private ClusterMap cm2;
     int numberExistingEdges;
     int numberPossibleEdges;

    public InterClusterArea(ClusterMap cm1, ClusterMap cm2) {
	cmSet = new HashSet<ClusterMap>();
	cmSet.add(cm1);
	cmSet.add(cm2);
	this.cm1 = cm1;
	this.cm2 = cm2;
	numberPossibleEdges = cm1.clusterSize() * cm2.clusterSize();
	numberExistingEdges = 0;

	for (Node node : cm1.getBestClusteredNodes()) {
	    for (Node neighbor : node.getNeighbors()) {
		if (cm2.contains(neighbor)) {
		    numberExistingEdges++;
		}
	    }
	}
    }

    public HashSet<ClusterMap> getClusterMaps() {
	return cmSet;
    }

    public ClusterMap getOtherClusterMap(ClusterMap cm) {
	ClusterMap resultMap = null;
	for (ClusterMap cm1 : cmSet) {
	    if (!cm1.equals(cm)) {
		resultMap = cm1;
	    }
	}
	return resultMap;
    }

    public int getNumberExistingEdges() {
	return numberExistingEdges;
    }

    public int getNumberPossibleEdges() {
	return numberPossibleEdges;
    }

    public ClusterMap getCm1() {
        return cm1;
    }

    public ClusterMap getCm2() {
        return cm2;
    }

}
