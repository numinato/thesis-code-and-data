package anonymizedPackage.graphMiner.graphClusterer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.TreeMap;

import anonymizedPackage.graphMiner.graphDrawer.accessories.Tools;
import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

public class HubCluster extends Cluster {
    private Node lastHubNode;

    public HubCluster(Graph subgraph, Neighborhood neighborhood) {
	super(neighborhood);
	clusteredGraph = new Graph(subgraph);
	lastHubNode = null;

	// move max degree node to front
	sortClusteredGraph();

	mdl += codingCost();
	mdl += parameterCost();
    }

    private double parameterCost() {
	double c = 0.0;

	// hub edge probability and spokes edge probability
	c += 2.0 * 0.5 * Tools.log2(clusteredGraph.size());

	// parameter cost for cluster/graph type
	c += Math.ceil(Tools.log2(clusterCodebookLength));

	// id costs for each node
	c += Tools.log2(Cluster.getN() / ((double) getSize())) * getSize();

	// encoding of hub node
	c += Math.ceil(Tools.log2(clusteredGraph.size()));

	return c;
    }

    private double codingCost() {
	double cost;
	int hubEdgeCount;
	int spikesEdgeCount;
	int possibleSpikesEdgeCount;

	cost = 0.0;

	// entropy-encode hub edges
	hubEdgeCount = neighborhood.get(clusteredGraph.getNode(0)).size();
	cost += (clusteredGraph.size() - 1)
		* Tools.entropy(((double) hubEdgeCount) / (clusteredGraph.size() - 1));

	// HUB needs to have at least 50% of all other nodes be connected to hub
	// node:
	if (hubEdgeCount < (clusteredGraph.size() - 1) / 2.0) {
	    cost = Double.POSITIVE_INFINITY;
	}

	// entropy-encode spoke edges
	spikesEdgeCount = neighborhood.getEdgeCount() - hubEdgeCount;
	possibleSpikesEdgeCount = ((clusteredGraph.size() - 1) * (clusteredGraph.size() - 1) - (clusteredGraph
		.size() - 1)) / 2;

	cost += possibleSpikesEdgeCount
		* Tools.entropy(((double) spikesEdgeCount) / possibleSpikesEdgeCount);

	// if more non-edges than edges exist in HUB, it is no HUB any longer:
	if (spikesEdgeCount > possibleSpikesEdgeCount / 2.0) {
	    cost = Double.POSITIVE_INFINITY;
	}

	return cost;

    }

    private void sortClusteredGraph() {
	clusteredGraph.swapNodes(0, clusteredGraph.indexOf(neighborhood.getMaxDegreeNode()));
    }

    @Override
    public void addNode(Node node, Collection<Node> nodes) {
	lastMdl = mdl;
	lastHubNode = clusteredGraph.getNode(0);
	lastActionNode = node;
	isLastActionAddNode = true;
	clusteredGraph.add(node);
	sortClusteredGraph();
	mdl = codingCost();
	mdl += parameterCost();
    }

    @Override
    public void removeNode(Node node) throws GraphSizeException {
	if (clusteredGraph.size() < minClusterSize + 1) {
	    throw new GraphSizeException("Graph too small");
	}
	lastMdl = mdl;
	lastHubNode = clusteredGraph.getNode(0);
	lastActionNode = node;
	isLastActionAddNode = false;
	clusteredGraph.removeNode(node);
	sortClusteredGraph();
	mdl = codingCost();
	mdl += parameterCost();
    }

    @Override
    public void undo() {
	if (lastActionNode != null) {
	    mdl = lastMdl;
	    if (isLastActionAddNode) {
		clusteredGraph.remove(lastActionNode);
	    } else {
		clusteredGraph.add(lastActionNode);
	    }
	    clusteredGraph.swapNodes(lastHubNode, 0);
	    lastActionNode = null;
	}
    }

    @Override
    public Collection<Node> getOrderedClusteredNodes() {
	ArrayList<Node> al = new ArrayList<Node>();
	al.add(this.getClusteredNodes().get(0));
	TreeMap<Integer, Node> tm = new TreeMap<Integer, Node>();
	for (int i = 1; i < this.getClusteredNodes().size(); i++) {
	    Node node = this.getClusteredNodes().get(i);
	    tm.put(SplitMergeClusterer.getGraphPosition(node), node);
	}
	al.addAll(tm.values());
	return al;
    }

}