package anonymizedPackage.graphMiner.graphClusterer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.LinkedList;

import anonymizedPackage.graphMiner.graphDrawer.accessories.Tools;
import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

public class TreeCluster extends Cluster {

    private Graph lastClusteredGraph;
    private double errorCost;
    private int errorEdgeCount;
    private int possibleErrorEdgeCount;
    private int[] numberOfChildren;

    public TreeCluster(Graph subgraph, Neighborhood neighborhood) throws GraphSizeException {
	super(neighborhood);
	lastClusteredGraph = null;
	clusteredGraph = new Graph(subgraph.size());

	if (subgraph.size() < minClusterSize) {
	    throw new GraphSizeException("Too few nodes for tree.");
	}

	// if (neighborhood.getEdgeCount() < minClusterSize) {
	// throw new GraphSizeException("Too few edges for tree.");
	// }

	mdl = sortTreeIfConnected(subgraph) ? codingCost() + parameterCost()
		: Double.POSITIVE_INFINITY;
    }

    private double parameterCost() {
	double cost = 0.0;

	// parameter cost for encoding edge probability
	cost += 0.5 * Tools.log2(clusteredGraph.size());

	// parameter cost for cluster/graph type
	cost += Math.ceil(Tools.log2(clusterCodebookLength));

	// id costs for each node
	cost += Tools.log2(Cluster.getN() / ((double) getSize())) * getSize();

	// encoding cost for parent of each node except root node
	cost += (clusteredGraph.size() - 1) * Tools.log2(clusteredGraph.size() - 1);

	return cost;
    }

    private double codingCost() {
	int j = 0;
	errorEdgeCount = neighborhood.getEdgeCount() - (clusteredGraph.size() - 1);
	possibleErrorEdgeCount = 0;
	for (int i = 1; i < clusteredGraph.size(); i++) {
	    j += numberOfChildren[i - 1] - 1;
	    possibleErrorEdgeCount += j;
	}
	errorCost = possibleErrorEdgeCount
		* Tools.entropy(errorEdgeCount / ((double) possibleErrorEdgeCount));
	if (errorEdgeCount > possibleErrorEdgeCount / 2.0) {
	    errorCost = Double.POSITIVE_INFINITY;
	}

	return errorCost;
    }

    /**
     * Sorts node order to tree-like order.
     * 
     * @param originalGraph
     */
    private boolean sortTreeIfConnected(Graph originalGraph) {

	LinkedList<Node> nextNodesToProcess;
	LinkedHashSet<Node> visitedNodes;
	Node currentNode;
	int i;
	boolean isConnected;

	currentNode = null;
	i = 0;
	isConnected = false;
	numberOfChildren = new int[originalGraph.size()];
	nextNodesToProcess = new LinkedList<Node>();
	visitedNodes = new LinkedHashSet<Node>();
	nextNodesToProcess.add(originalGraph.getNode(0));

	while ((currentNode = nextNodesToProcess.poll()) != null) {
	    int c = 0;
	    clusteredGraph.add(currentNode);
	    visitedNodes.add(currentNode);
	    for (Node neighbor : neighborhood.getSortedNeighbors(currentNode)) {
		if (!visitedNodes.contains(neighbor)) {
		    nextNodesToProcess.add(neighbor);
		    visitedNodes.add(neighbor);
		    c++;
		}
	    }
	    numberOfChildren[i] = c;
	    i++;
	}

	int largestConnectedComponentSize = clusteredGraph.size();

	// If graph is not connected: use original ordering
	if (clusteredGraph.size() < originalGraph.size()) {
	    clusteredGraph = new Graph(originalGraph.getNodes());
	    // if (SplitMergeClusterer.hasSparse) {
	    // int size = calclargestConnectedComponent(originalGraph);
	    // if (size > largestConnectedComponentSize) {
	    // largestConnectedComponentSize = size;
	    // }
	    // }
	} else {
	    isConnected = true;
	}
	ClusterMap.largestConnectedComponentSize = largestConnectedComponentSize;

	assert clusteredGraph.size() > 0;
	assert clusteredGraph.size() <= originalGraph.size();

	// System.err.println("TreeCluster Nodes are: [ " +
	// Tools.IterableToString(clusteredGraph.getNodes()) + " ]");
	return isConnected;
    }

    private int calclargestConnectedComponent(Graph originalGraph) {

	LinkedHashSet<Node> visitedNodes;
	LinkedHashSet<Node> allNodes;
	LinkedList<Node> nextNodesToProcess;
	Node currentNode;
	int maxSize;

	maxSize = 0;
	allNodes = new LinkedHashSet<Node>(originalGraph.getNodes());
	allNodes.removeAll(clusteredGraph.getNodes());

	while (!allNodes.isEmpty()) {

	    int size = 0;
	    currentNode = null;
	    nextNodesToProcess = new LinkedList<Node>();
	    visitedNodes = new LinkedHashSet<Node>();
	    Node node = allNodes.iterator().next();
	    nextNodesToProcess.add(node);

	    while ((currentNode = nextNodesToProcess.poll()) != null) {
		visitedNodes.add(currentNode);
		allNodes.remove(currentNode);
		size++;
		for (Node neighbor : neighborhood.getSortedNeighbors(currentNode)) {
		    if (!visitedNodes.contains(neighbor)) {
			nextNodesToProcess.add(neighbor);
			visitedNodes.add(neighbor);
			allNodes.remove(neighbor);
			size++;
		    }
		}
	    }
	    maxSize = size > maxSize ? size : maxSize;
	}

	return maxSize;
    }

    @Override
    public void addNode(Node node, Collection<Node> nodes) {
	lastClusteredGraph = new Graph(clusteredGraph);
	lastMdl = mdl;
	lastActionNode = node;
	clusteredGraph = new Graph(nodes.size());
	mdl = sortTreeIfConnected(new Graph(nodes)) ? codingCost() + parameterCost()
		: Double.POSITIVE_INFINITY;
    }

    @Override
    public void removeNode(Node node) throws GraphSizeException {
	if (clusteredGraph.size() < minClusterSize + 1) {
	    throw new GraphSizeException("Cluster too small.");
	}
	int lastNodePosition = clusteredGraph.indexOf(node);
	lastClusteredGraph = new Graph(clusteredGraph);
	clusteredGraph = new Graph(clusteredGraph.size() - 1);
	lastMdl = mdl;
	lastActionNode = node;
	lastClusteredGraph.remove(node);
	mdl = sortTreeIfConnected(lastClusteredGraph) ? codingCost() + parameterCost()
		: Double.POSITIVE_INFINITY;

	lastClusteredGraph.addNode(lastNodePosition, node);
    }

    @Override
    public void undo() {
	if (lastActionNode != null) {
	    mdl = lastMdl;
	    clusteredGraph = new Graph(lastClusteredGraph); // TODO: new
							    // necessary?
	    lastActionNode = null;
	}
    }

    public String toString() {
	String s;
	s = String.format("TREE [MDL=%.2f, ERROR = %d / %d]%n-->[ s ]%n", this.mdl,
		this.errorEdgeCount, this.possibleErrorEdgeCount
//		,Tools.IterableToString(clusteredGraph.getNodes())
			);
	return s;
    }

    @Override
    public Collection<Node> getOrderedClusteredNodes() {
	return new ArrayList<Node>(this.getClusteredNodes());
    }

}
