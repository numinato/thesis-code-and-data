package anonymizedPackage.graphMiner.graphDrawer.accessories;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import anonymizedPackage.graphMiner.graphDrawer.model.Edge;
import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

public class GraphGenerator {
    private Graph graph;
    private Random random = new Random();
    private int nErrorEdges;

    public GraphGenerator(int n, double errorRate) {

	double p;
	double q = (1.0 - errorRate); // correctness = 1 - error rate
	int numberCliqueNodes = (int) ((14.0 / 82.0) * n);
	int numberHubNodes = (int) ((22.0 / 82.0) * n);
	int numberBipartiteNodes = (int) ((15.0 / 82.0) * n);
	int numberTreeNodes = (int) ((21.0 / 82.0) * n);
	int numberSparseNodes = (int) ((10 / 82.0) * n);
	int graphSize = numberCliqueNodes + numberHubNodes + numberBipartiteNodes + numberTreeNodes
		+ numberSparseNodes;
	int nodeOffSet = 0;

	graph = new Graph();
	nErrorEdges = 0;

	// create clique

	for (int i = 0; i < numberCliqueNodes; i++) {
	    graph.add(new Node(0));
	}

	for (int i = 0; i < numberCliqueNodes; i++) {
	    for (int j = i + 1; j < numberCliqueNodes; j++) {
		p = random.nextDouble();
		if (p < 0.714286 * q) {
		    graph.addEdge(graph.getNode(i), graph.getNode(j));
		} else {
		    nErrorEdges++;
		}
	    }
	}

	nodeOffSet += numberCliqueNodes;

	for (int i = 0; i < numberHubNodes; i++) {
	    graph.add(new Node(1));
	}

	Node hubNode = graph.getNode(nodeOffSet);
	// set edges from hub to spikes
	nodeOffSet++;

	for (int i = nodeOffSet; i < nodeOffSet + numberHubNodes - 1; i++) {
	    graph.addEdge(hubNode, graph.getNode(i));
	}
	// set edges from spikes to spikes

	for (int i = nodeOffSet; i < nodeOffSet + numberHubNodes - 1; i++) {
	    for (int j = i + 1; j < nodeOffSet + numberHubNodes - 1; j++) {
		p = random.nextDouble();
		if (p > 0.957143 * q) {
		    graph.addEdge(graph.getNode(i), graph.getNode(j));
		    nErrorEdges++;
		}
	    }
	}

	nodeOffSet += numberHubNodes - 1;

	// bipartite subgraph

	int bipartiteSetA = (2 * numberBipartiteNodes) / 3;
	int bipartiteSetB = numberBipartiteNodes - bipartiteSetA;

	for (int i = nodeOffSet; i < nodeOffSet + numberBipartiteNodes; i++) {
	    graph.add(new Node(2));
	}

	// edges between sets
	for (int i = nodeOffSet; i < nodeOffSet + bipartiteSetA; i++) {
	    for (int j = nodeOffSet + bipartiteSetA; j < nodeOffSet + numberBipartiteNodes; j++) {
		p = random.nextDouble();
		if (p < 0.76 * q) {
		    graph.addEdge(graph.getNode(i), graph.getNode(j));
		} else {
		    nErrorEdges++;
		}
	    }
	}
	// edges in sets

	for (int i = nodeOffSet; i < nodeOffSet + bipartiteSetA; i++) {
	    for (int j = i + 1; j < nodeOffSet + bipartiteSetA; j++) {
		p = random.nextDouble();
		if (p > 0.97777 * q) {
		    graph.addEdge(graph.getNode(i), graph.getNode(j));
		    nErrorEdges++;
		}
	    }
	}

	for (int i = nodeOffSet + bipartiteSetA; i < nodeOffSet + numberBipartiteNodes; i++) {
	    for (int j = i + 1; j < nodeOffSet + numberBipartiteNodes; j++) {
		p = random.nextDouble();
		if (p > 0.9 * q) {
		    graph.addEdge(graph.getNode(i), graph.getNode(j));
		    nErrorEdges++;
		}
	    }
	}

	nodeOffSet += numberBipartiteNodes;
	// tree

	for (int i = nodeOffSet; i < nodeOffSet + numberTreeNodes; i++) {
	    graph.add(new Node(3));
	}

	ArrayList<Node> parents = new ArrayList<Node>();
	ArrayList<Node> children = new ArrayList<Node>();
	parents.add(graph.getNode(nodeOffSet));
	int childNodeId = nodeOffSet + 1;
	int nChildren;

	boolean done = false;
	while (!done) {
	    nChildren = 0;
	    for (int i = 0; i < parents.size(); i++) {
		int numberChildren = random.nextInt((int) (numberTreeNodes * 0.1875));
		while (numberChildren > 0 && !done) {
		    graph.addEdge(parents.get(i), graph.getNode(childNodeId));
		    children.add(graph.getNode(childNodeId));
		    childNodeId++;
		    numberChildren--;
		    nChildren++;
		    if (childNodeId == nodeOffSet + numberTreeNodes) {
			done = true;
		    }
		}
	    }
	    if (nChildren == 0 && !done) {
		graph.addEdge(parents.get(random.nextInt(parents.size())),
			graph.getNode(childNodeId));
		children.add(graph.getNode(childNodeId));
		childNodeId++;
		if (childNodeId == nodeOffSet + numberTreeNodes) {
		    done = true;
		}
	    }
	    parents = children;
	    children = new ArrayList<Node>();
	}

	// error nodes in tree

	// nodeOffSet--;
	for (int i = nodeOffSet; i < nodeOffSet + numberTreeNodes; i++) {
	    for (int j = i + 1; j < nodeOffSet + numberTreeNodes; j++) {
		p = random.nextDouble();
		if (p > 0.9842 * q) {
		    Edge edge = new Edge(graph.getNode(i), graph.getNode(j));
		    if (!graph.containsEdge(edge)) {
			graph.addEdge(edge);
		    }
		    nErrorEdges++;
		}
	    }
	}

	// sparse

	nodeOffSet += numberTreeNodes;

	// connect nodes

	Node parentNode = new Node(4);
	graph.add(parentNode);
	Node nextNode;

	for (int i = nodeOffSet + 1; i < nodeOffSet + numberSparseNodes; i++) {
	    nextNode = new Node(4);
	    graph.add(nextNode);
	    graph.addEdge(parentNode, nextNode);
	    parentNode = nextNode;
	}

	nErrorEdges += numberSparseNodes - 1;

	// add error edges

	for (int i = nodeOffSet; i < nodeOffSet + numberSparseNodes; i++) {
	    for (int j = i + 1; j < nodeOffSet + numberSparseNodes; j++) {
		p = random.nextDouble();
		if (p > 0.7778 * q) {
		    Edge edge = new Edge(graph.getNode(i), graph.getNode(j));
		    if (!graph.containsEdge(edge)) {
			graph.addEdge(edge);
			nErrorEdges++;
		    }
		}
	    }
	}

	// set edges between clusters

	for (int i = 0; i < numberCliqueNodes; i++) {
	    // CLIQUE - HUB
	    for (int j = numberCliqueNodes; j < numberCliqueNodes + numberHubNodes; j++) {
		p = random.nextDouble();
		if (p > (1.0 - 0.0292) * q) {
		    graph.addEdge(graph.getNode(i), graph.getNode(j));
		    nErrorEdges++;
		}
	    }
	    // CLIQUE - BIPARTITE
	    for (int j = numberCliqueNodes + numberHubNodes; j < numberCliqueNodes + numberHubNodes
		    + numberBipartiteNodes; j++) {
		p = random.nextDouble();
		if (p > (1.0 - 0.0190) * q) {
		    graph.addEdge(graph.getNode(i), graph.getNode(j));
		    nErrorEdges++;
		}
	    }
	    // CLIQUE - TREE
	    for (int j = numberCliqueNodes + numberHubNodes + numberBipartiteNodes; j < numberCliqueNodes
		    + numberHubNodes + numberBipartiteNodes + numberTreeNodes; j++) {
		p = random.nextDouble();
		if (p > (1.0 - 0.0102) * q) {
		    graph.addEdge(graph.getNode(i), graph.getNode(j));
		    nErrorEdges++;
		}
	    }
	    // CLIQUE - SPARSE
	    for (int j = numberCliqueNodes + numberHubNodes + numberBipartiteNodes
		    + numberTreeNodes; j < graphSize; j++) {
		p = random.nextDouble();
		if (p > (1.0 - 0.0143) * q) {
		    graph.addEdge(graph.getNode(i), graph.getNode(j));
		    nErrorEdges++;
		}
	    }

	}

	for (int i = numberCliqueNodes; i < numberCliqueNodes + numberHubNodes; i++) {
	    // HUB - BIPARTITE
	    for (int j = numberCliqueNodes + numberHubNodes; j < numberCliqueNodes + numberHubNodes
		    + numberBipartiteNodes; j++) {
		p = random.nextDouble();
		if (p > (1.0 - 0.00909) * q) {
		    graph.addEdge(graph.getNode(i), graph.getNode(j));
		    nErrorEdges++;
		}
	    }
	    // HUB - TREE
	    for (int j = numberCliqueNodes + numberHubNodes; j < numberCliqueNodes + numberHubNodes
		    + numberBipartiteNodes + numberTreeNodes; j++) {
		p = random.nextDouble();
		if (p > (1.0 - 0.00433) * q) {
		    graph.addEdge(graph.getNode(i), graph.getNode(j));
		    nErrorEdges++;
		}
	    }
	    // HUB - SPARSE
	    for (int j = numberCliqueNodes + numberHubNodes + numberBipartiteNodes
		    + numberTreeNodes; j < graphSize; j++) {
		p = random.nextDouble();
		if (p > (1.0 - 0.00455) * q) {
		    graph.addEdge(graph.getNode(i), graph.getNode(j));
		    nErrorEdges++;
		}
	    }
	}

	for (int i = numberCliqueNodes + numberHubNodes; i < numberCliqueNodes + numberHubNodes
		+ numberBipartiteNodes; i++) {
	    // BIPARTITE - TREE
	    for (int j = numberCliqueNodes + numberHubNodes + numberBipartiteNodes; j < numberCliqueNodes
		    + numberHubNodes + numberBipartiteNodes + numberTreeNodes; j++) {
		p = random.nextDouble();
		if (p > (1.0 - 0.00952) * q) {
		    graph.addEdge(graph.getNode(i), graph.getNode(j));
		    nErrorEdges++;
		}
	    }
	    // BIPARTITE - SPARSE
	    for (int j = numberCliqueNodes + numberHubNodes + numberBipartiteNodes
		    + numberTreeNodes; j < graphSize; j++) {
		p = random.nextDouble();
		if (p > (1.0 - 0.00667) * q) {
		    graph.addEdge(graph.getNode(i), graph.getNode(j));
		    nErrorEdges++;
		}
	    }
	}

	for (int i = numberCliqueNodes + numberHubNodes + numberBipartiteNodes; i < numberCliqueNodes
		+ numberHubNodes + numberBipartiteNodes + numberTreeNodes; i++) {
	    // TREE - SPARSE
	    for (int j = numberCliqueNodes + numberHubNodes + numberBipartiteNodes
		    + numberTreeNodes; j < graphSize; j++) {
		p = random.nextDouble();
		if (p > (1.0 - 0.00476) * q) {
		    graph.addEdge(graph.getNode(i), graph.getNode(j));
		    nErrorEdges++;
		}
	    }
	}

	// Check for duplicate edges
	Set<Edge> edgeSet = new HashSet<Edge>(graph.getEdges());
	ArrayList<Edge> edges = new ArrayList<Edge>();
	for (Edge edge : edgeSet) {
	    edges.add(edge);
	}
	if (graph.getEdges().size() != edges.size()) {
	    throw new RuntimeException("Double Edges! Implementation wrong!");
	}

	// set neighboring nodes
	for (Edge edge : graph.getEdges()) {
	    edge.getNode1().addNeighbor(edge.getNode2());
	    edge.getNode2().addNeighbor(edge.getNode1());
	}

    }

    public Graph getGraph() {
	return graph;
    }

    public int getNumberErrorEdges() {
	return nErrorEdges;
    }

}
