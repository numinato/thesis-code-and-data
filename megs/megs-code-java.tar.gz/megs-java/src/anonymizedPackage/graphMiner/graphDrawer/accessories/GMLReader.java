package anonymizedPackage.graphMiner.graphDrawer.accessories;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import anonymizedPackage.graphMiner.graphDrawer.model.Edge;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

public class GMLReader {

    ArrayList<Node> nodes;
    ArrayList<Edge> edges;

    public GMLReader(BufferedReader br) throws IOException {
	Pattern nodePattern;
	Pattern edgePattern;
	Matcher matcher;
	String line;
	StringBuffer dataBuffer;
	int id;
	int offset;

	nodePattern = Pattern
		.compile("\\s*node\\s*\\[\\s*id\\s*(\\d+)\\s*(?:label\\s*\"[^\"]+\"\\s*(?:value\\s*(\\d+)\\s*)?(?:source\\s*\"[^\"]+\"\\s*)?)?\\]");
	edgePattern = Pattern
		.compile("\\s*edge\\s*\\[\\s*source\\s*(\\d+)\\s*target\\s*(\\d+)\\s*\\]");

	nodes = new ArrayList<Node>();
	edges = new ArrayList<Edge>();

	dataBuffer = null;
	id = 0;
	offset = 0;
	while ((line = br.readLine()) != null) {
	    if (line.contains("node") || line.contains("edge")) {
		dataBuffer = new StringBuffer();
		dataBuffer.append(line);
		while (!(line = br.readLine()).contains("]")) {
		    dataBuffer.append(line);
		}
		dataBuffer.append(line);
		matcher = nodePattern.matcher(dataBuffer.toString());
		if (matcher.matches()) {
		    System.err.println(matcher.group(0));
		    System.err.println(">> " + matcher.group(1));
		    int label = 0;
		    int sId = Integer.parseInt(matcher.group(1));

		    // if nodes start with 1 then adjust it
		    if (id == 0 && sId == 1) {
			offset = 1;
			id++;
		    }

		    if (id != sId) {
			throw new IllegalArgumentException("Node IDs are not consecutive. In: '"
				+ line + "'");
		    }

		    if (matcher.group(2) != null) {
			System.err.println(">>" + matcher.group(2));
			label = Integer.parseInt(matcher.group(2));
		    }

		    nodes.add(new Node(100, 100, label));
		    id++;

		} else {
		    matcher = edgePattern.matcher(dataBuffer.toString());
		    boolean successful = matcher.matches();
		    assert successful;

		    System.err.println(matcher.group(0));
		    System.err.println(">> " + matcher.group(1));
		    System.err.println(">> " + matcher.group(2));
		    int sourceId = Integer.parseInt(matcher.group(1)) - offset;
		    int targetId = Integer.parseInt(matcher.group(2)) - offset;

		    if (sourceId != targetId) {
			edges.add(new Edge(nodes.get(sourceId), nodes.get(targetId)));
		    }
		}
	    }
	}
    }

    public ArrayList<Node> getNodes() {
	return nodes;
    }

    public ArrayList<Edge> getEdges() {
	return edges;
    }

}
