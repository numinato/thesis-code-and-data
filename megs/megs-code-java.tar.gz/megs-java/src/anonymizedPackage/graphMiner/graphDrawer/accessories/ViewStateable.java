package anonymizedPackage.graphMiner.graphDrawer.accessories;

/**
* 
* @version $Id: ViewStateable.java 1743 2014-06-27 14:36:51Z goebl $
*/
public interface ViewStateable {

    void setState(ViewState vs);

}
