package anonymizedPackage.graphMiner.graphDrawer.accessories;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Paint;
import java.util.Collection;

import javax.swing.JFrame;

import org.apache.commons.collections15.Transformer;

import anonymizedPackage.graphMiner.graphDrawer.model.Edge;
import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;
import edu.uci.ics.jung.algorithms.layout.FRLayout;
import edu.uci.ics.jung.algorithms.layout.ISOMLayout;
import edu.uci.ics.jung.algorithms.layout.KKLayout;
import edu.uci.ics.jung.algorithms.layout.SpringLayout;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;
import edu.uci.ics.jung.visualization.VisualizationImageServer;

/**
 * 
 * @version $Id: JungGraphViewerAdapter.java 1743 2014-06-27 14:36:51Z goebl $
 */
public class JungGraphViewerAdapter {
    Graph graph;
    UndirectedSparseGraph<Node, Integer> sg;
    Transformer<Node, Paint> vertexPaintTransformer;

    public JungGraphViewerAdapter(Graph graph) {
	this.graph = graph;
	this.sg = new UndirectedSparseGraph<Node, Integer>();

	initGraph();
	initTransformer();
    }

    private void initGraph() {
	int counter;
	for (Node node : graph.getNodes()) {
	    sg.addVertex(node);
	}
	counter = 0;
	for (Edge edge : graph.getEdges()) {
	    sg.addEdge(counter++, edge.getNode1(), edge.getNode2());
	}
    }

    private void initTransformer() {
	vertexPaintTransformer = new Transformer<Node, Paint>() {
	    private final Color[] palette = { Color.GREEN, Color.BLUE, Color.RED, Color.CYAN, Color.MAGENTA,
		    Color.YELLOW, Color.ORANGE };

	    public Paint transform(Node node) {
		return palette[node.getLabel()];
	    }
	};
    }

    public void visualize() {

	KKLayout<Node, Integer> layout = new KKLayout<Node, Integer>(sg);
//	FRLayout<Node, Integer> layout = new FRLayout<Node, Integer>(sg, graph.getDimension());
	layout.setSize(graph.getDimension());
	layout.setMaxIterations(500);
	
	while (!layout.done()){
	    layout.step();
	    System.err.println(layout.getStatus());
	}
	
	
//	VisualizationImageServer<Node, Integer> vs = new VisualizationImageServer<Node, Integer>(layout, graph.getDimension());

	Collection<Node> ns = sg.getVertices();

	for (Node node : ns) {
	    int x = (int) layout.getX(node);
	    int y = (int) layout.getY(node);
	    node.setX(x);
	    node.setY(y);
	}
	graph.update();

//	vs.getRenderContext().setVertexFillPaintTransformer(vertexPaintTransformer);
//	// new CircleLayout(sg), new Dimension(250, 200));
//
//	JFrame frame = new JFrame();
//	frame.getContentPane().add(vs);
//	// frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//	frame.pack();
//	frame.setVisible(true);

    }
}
