package anonymizedPackage.graphMiner.graphDrawer.accessories;

/**
* 
* @version $Id: ViewState.java 1743 2014-06-27 14:36:51Z goebl $
*/
public enum ViewState {
    NODES_PLAIN, NODES_DENOTED_ALL, NODES_DENOTED_CURRENT, SELECTED, MOVING, PRE_MOVING, PERMUTING
}
