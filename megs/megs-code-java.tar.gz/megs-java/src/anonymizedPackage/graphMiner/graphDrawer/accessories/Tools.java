package anonymizedPackage.graphMiner.graphDrawer.accessories;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Random;

import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

/**
 * Utility class. Static, cannot be instantiated.
 * 
 * @version $Id: Tools.java 1844 2014-07-23 16:51:04Z goebl $
 */
public class Tools {

    private Tools() {
	throw new AssertionError();
    }

    /**
     * Shuffles elements of input array.
     * 
     * @param array
     *            an array
     */
    public static void ShuffleArray(int[] array) {
	int index;
	Random random = new Random();
	for (int i = array.length - 1; i > 0; i--) {
	    index = random.nextInt(i + 1);
	    if (index != i) {
		array[index] ^= array[i];
		array[i] ^= array[index];
		array[index] ^= array[i];
	    }
	}
    }

    /**
     * Returns lg*(v), the log star of n to base 2.
     * 
     * @param v
     *            a value
     * @return lg*(v)
     */
    public static double logstar2(double v) {
	double cost = 0;
	double vd = v;

	while (vd > 1) {
	    vd = Math.log(vd) / Math.log(2.0);
	    cost = cost + vd;
	}
	return cost;
    }

    public static double logstar2(int v) {
	return logstar2((double) v);
    }

    public static double log2(int v) {
	return Math.log(v) / Math.log(2.0);
    }

    public static double log2(double v) {
	return Math.log(v) / Math.log(2.0);
    }

    public static double entropy(double p) {
	if (p == 0.0 || p == 1.0) {
	    return 0.0;
	} else {
	    return (-(p * log2(p) + (1 - p) * log2(1 - p)));
	}
    }

    public static double entropyCodingCost(int existingEdgeCount, int possibleEdgeCount) {
	double edgeProbability = possibleEdgeCount == 0 ? 0 : ((double) existingEdgeCount)
		/ (double) possibleEdgeCount;
	return possibleEdgeCount * Tools.entropy(edgeProbability);
    }

    /**
     * 
     * Creates an array of an ascending integer sequence starting with i
     * (inclusive) and ending with j (inclusive).
     * 
     * @param i
     *            first integer of array
     * @param j
     *            last integer of array
     * @return array as defined or null if !(j>i)
     */
    public static int[] createArrayAscendingFromTo(int i, int j) {
	if (j <= i) {
	    return null;
	} else {
	    int[] result = new int[j - i + 1];
	    for (int p = 0; p < j; p++) {
		result[p] = p;
	    }
	    return result;
	}
    }

    public static Object findDifferentElement(ArrayList<?> al1, ArrayList<?> al2) {
	ArrayList<Object> a = new ArrayList<Object>(al1);
	ArrayList<Object> b = new ArrayList<Object>(al2);

	if (a.size() > b.size()) {
	    a.removeAll(b);

	} else if (b.size() > a.size()) {
	    b.removeAll(a);
	} else {
	    return null;
	}

	if (a.size() == 1) {
	    return a.get(0);
	} else if (b.size() == 1) {
	    return b.get(0);
	} else {
	    return null;
	}
    }

    public static int cumsum(int[] array, int from, int to) {
	int sum = 0;

	for (int idx = from; idx < to; idx++) {
	    sum += array[idx];
	}
	return sum;
    }

    public static <T> String IterableToString(Iterable<T> iterable) {
	StringBuffer sb = new StringBuffer();
	for (T t : iterable) {
	    sb.append(t.toString()).append(" ");
	}
	return sb.toString();
    }

    public static int[] parseInt(String[] valuesString) {
	int[] values = new int[valuesString.length];
	for (int i = 0; i < values.length; i++) {
	    values[i] = Integer.parseInt(valuesString[i]);
	}
	return values;
    }

}
