package anonymizedPackage.graphMiner.graphDrawer.accessories;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.TreeMap;

import org.jblas.DoubleMatrix;

/**
 * Normalized Mutual Information
 * 
 * @version $Id: Nmi.java 2235 2015-05-15 12:30:42Z goebl $
 */
public class Nmi {

    public static void main(String[] args) throws IOException {
	int[] classIds;
	int[] clusterIds;

	if (args.length < 2) {
	    System.out.println("Usage: nmi <-lineWise> classIds clusterIds");
	    System.exit(0);
	}
	if (args[0].equalsIgnoreCase("-linewise")) {
	    classIds = readFile(new File(args[1]));
	    clusterIds = readLinewiseFile(new File(args[2]));
	} else {
	    classIds = readFile(new File(args[0]));
	    clusterIds = readFile(new File(args[1]));
	}

	normalize(classIds);
	normalize(clusterIds);

	// int[] a = new int[] { 9, 9, 9, 2, 2, 4, 4, 4 };
	// int[] b = new int[] { 1, 2, 3, 4, 5, 5, 5, 5 };

	// int[] a = new int[] { 1, 1, 1, 1, 1, 1, 1, 1 };
	// int[] b = new int[] { 1, 1, 1, 1, 1, 1, 1, 1 };

	// int[] d = new int[]
	// {8,17,15,12,4,20,6,19,5,8,2,13,4,1,15,7,14,8,13,1,19,17,15,17,8,13,12,11,6,5,10,5,17,20,1,11,2,17,20,2,19,1,14,16,11,18,18,13,3,5,4,1,3,13,19,8,9,20,19,14,20,16,7,14,5,6,14,11,9,13,16,12,12,12,11,2,15,20,8,20,7,18,10,9,5,3,7,15,16,14,1,17,19,16,1,8,15,15,5,6,14,10,13,5,4,17,16,19,3,4,2,10,4,18,2,1,12,16,7,4,7,5,11,19,13,3,8,2,11,9,20,17,10,18,3,8,19,19,15,13,7,19,3,15,13,17,8,15,17,7,12,20,11,7,13,8,16,9,10,14,20,7,17,15,20,1,8,14,6,5,15,13,12,14,1,7,10,5,15,18,6,15,3,17,3,12,8,17,11,10,18,8,9,20,1,20,4,14,12,14,8,13,17,1,2,20,14,5,9,3,6,6,7,4,7,3,18,2,19,8,1,7,15,16,11,14,18,2,7,1,4,15,15,18,12,2,19,17,6,11,20,15,17,9,10,12,6,15,11,13,7,3,10,8,16,16,14,3,1,12,7,19,20,6,17,18,12,18,19,11,15,12,1,9,13,11,8,19,17,17,8,12,18,19,14,5,14,2,9,14,19,17,10,16,9,20,20,18,8,10,5,16,18,19,12,12,3,18,10,5,18,16,18,6,14,14,3,9,6,15,6,18,17,8,10,14,17,13,12,7,10,15,18,15,1,14,9,9,3,17,7,5,7,8,11,12,8,8,11,14,20,15,9,17,3,2,2,4,7,7,1,11,2,3,13,18,20,12,20,12,11,7,9,10,2,18,2,9,17,8,13,17,18,19,4,6,18,12,11,13,17,11,5,10,9,20,13,14,15,7,11,12,4,12,14,9,17,15,8,10,8,16,15,9,14,19,16,15,3,8,12,10,2,5,17,1,18,2,14,11,5,12,3,14,12,2,2,4,1,9,17,13,11,18,2,19,3,11,3,12,1,16,17,19,20,11,6,3,11,12,16,2,14,11,4,19,12,9,19,14,10,17,11,12,14,8,5,12,18,9,3,9,7,9,17,9,8,8,3,6,2,9,6,6,9,3,10,15,5,16,2,8,1,5,1,4,3,6,4,3,12,19,19,5,10,8,11,6,2,9,4,1,20,9,20,16,1,14,15,13,12,5,16,5,8,18,18,9,7,13,19,19,12,7,18,9,19,1,11,15,4,7,4,7,9,11,1,12,6,5,5,4,20,19,17,15,4,8,4,1,7,14,13,11,9,6,11,16,16,12,15,13,3,11,7,2,3,4,14,9,14,6,1,11,6,19,19,8,1,14,17,20,2,10,12,14,15,14,15,8,12,3,2,20,6,12,20,4,4,7,19,8,6,4,8,8,3,9,2,13,1,12,16,5,9,12,2,10,13,5,17,20,17,11,6,15,5,20,13,13,4,2,6,18,19,14,15,5,12,17,9,20,2,7,11,2,15,12,11,17,18,16,7,10,16,3,3,6,11,20,15,7,6,18,19,13,6,2,17,12,19,2,12,6,17,4,9,8,17,14,5,7,3,14,12,4,3,10,19,12,1,2,17,10,8,16,8,11,15,18,7,14,20,2,12,9,7,6,16,20,4,16,4,20,17,9,15,10,17,8,2,12,19,4,9,15,1,19,16,12,4,10,11,20,18,20,14,9,19,10,5,8,15,12,16,20,20,11,20,3,2,7,12,11,19,11,9,11,15,1,17,3,10,6,8,14,4,6,4,4,7,18,10,9,4,20,9,17,13,8,18,16,10,17,18,9,7,12,19,15,8,15,20,11,11,7,2,4,2,10,1,19,13,1,1,5,10,3,1,15,8,16,9,9,1,1,2,12,5,17,18,20,10,5,5,11,16,7,10,13,19,4,15,12,9,18,8,4,13,13,7,17,20,20,3,5,1,13,3,9,18,11,8,5,9,20,3,10,18,1,14,20,6,3,14,19,13,18,4,16,7,9,4,17,13,15,17,2,20,10,16,15,17,4,10,13,19,17,18,12,12,18,1,18,9,1,15,4,3,13,6,7,9,9,8,13,4,4,2,7,16,5,15,14,17,17,6,7,11,7,17,17,12,6,14,5,10,8,11,20,16,20,5,11,2,16,13,18,20,19,9,1,11,5,5,7,2,15,15,11,7,17,12,20,18,8,11,7,13,16,15,3,17,1,9,15,16,8,15,18,5,3,5,8,6,19,2,12,4,17};
	// int[] e = new int[]
	// {4,11,20,8,1,5,8,7,5,19,14,20,9,19,1,13,17,5,19,16,17,12,16,7,5,7,12,17,6,9,18,13,20,5,17,14,5,10,8,12,17,3,17,17,8,9,12,15,15,16,8,9,20,12,17,6,13,12,20,2,11,11,2,19,18,9,16,3,13,6,9,17,4,7,10,7,16,20,4,5,15,8,20,20,13,18,9,13,20,12,19,15,10,13,18,4,8,20,9,14,19,20,14,3,1,13,12,20,15,14,11,6,20,11,1,14,11,2,18,7,5,3,7,5,14,2,6,6,18,9,16,13,16,3,20,17,2,10,7,13,5,12,13,12,9,1,11,9,3,10,10,12,17,15,18,2,5,10,20,16,10,7,2,15,11,4,9,4,16,8,19,1,17,13,11,14,15,2,18,1,6,4,19,2,12,13,14,18,2,17,11,14,5,11,15,20,9,2,2,13,16,14,7,19,11,20,2,5,16,19,16,6,4,17,16,6,5,7,17,17,12,12,6,14,16,9,9,10,6,14,19,19,15,6,14,3,3,4,3,12,2,17,15,19,10,14,18,11,6,20,1,7,20,8,7,3,19,3,7,18,10,13,12,14,1,11,1,17,7,17,5,12,19,1,2,1,14,12,3,16,13,2,2,3,16,2,5,5,3,18,14,15,14,11,7,14,3,3,1,20,20,3,10,14,6,16,12,9,6,16,18,15,9,19,6,11,20,6,6,19,2,6,12,5,13,16,11,14,16,5,13,3,11,17,19,10,6,14,19,11,20,4,3,6,8,9,7,14,2,9,6,7,3,12,6,4,1,6,12,18,1,19,3,17,17,19,3,11,9,4,12,13,5,11,20,10,14,9,1,6,17,7,2,11,8,15,11,17,17,4,3,17,13,1,18,11,11,13,16,18,8,2,15,7,17,8,17,4,3,18,1,14,15,9,8,20,8,9,4,7,7,18,5,7,9,15,3,18,2,10,1,16,15,5,14,12,18,12,19,9,8,10,6,19,10,6,9,15,9,4,18,12,8,5,5,11,9,15,2,17,14,3,18,4,13,11,4,1,16,16,9,2,12,4,15,11,6,19,16,18,2,4,15,14,16,11,9,13,18,14,11,6,15,8,12,18,17,18,19,17,1,1,2,6,1,9,7,11,19,6,7,18,7,3,11,18,8,14,13,10,10,19,2,6,9,12,18,10,9,15,10,18,10,10,10,5,2,2,18,5,18,15,18,19,3,8,20,13,18,10,1,13,5,11,15,13,12,9,5,9,1,13,20,2,1,18,5,1,17,3,18,2,8,12,12,14,13,9,3,16,5,14,18,2,20,1,17,17,1,11,19,7,17,13,16,16,1,6,14,10,20,15,12,6,6,18,9,17,2,18,1,18,18,11,3,4,15,17,1,16,20,7,13,7,5,16,15,6,12,9,2,1,10,6,7,6,4,8,14,5,14,9,9,4,4,13,6,12,19,15,14,20,16,13,19,2,6,20,16,10,14,9,8,5,8,1,10,7,20,12,17,9,10,17,20,11,19,15,12,20,17,20,13,8,10,19,1,4,10,11,2,14,18,3,9,6,20,13,6,3,11,17,17,17,5,11,18,3,18,18,5,2,10,17,10,9,11,3,3,18,13,6,18,2,10,15,7,9,11,18,16,2,6,8,18,9,5,12,10,18,19,17,15,15,18,2,7,1,17,11,8,5,11,6,2,2,2,9,3,9,18,8,3,12,18,7,1,3,2,15,10,14,14,12,13,18,14,18,10,3,2,15,7,14,14,11,15,11,10,10,19,8,3,5,14,17,20,5,16,12,9,11,10,14,15,7,2,17,8,16,4,3,19,18,20,18,1,11,20,11,18,2,20,19,12,9,7,15,1,8,19,11,10,10,7,20,20,11,20,10,9,5,4,17,15,11,17,11,12,5,12,3,2,14,13,5,9,13,12,3,4,1,9,10,4,14,1,3,20,20,1,10,18,5,17,17,13,1,8,19,14,8,13,5,12,20,17,6,14,8,20,2,6,17,2,11,17,15,3,9,8,10,12,3,19,13,4,12,19,16,14,10,6,12,5,7,19,18,16,19,4,11,13,19,14,8,15,17,13,2,19,2,11,3,8,17,5,18,15,8,5,6,16,1,14,13,15,20,8,6,18,17,10,2,12,4,11,8,7,15,11,16,5,14,2,17,14,19,2,19,11,13,7,2,18,3,8,13,20,11,20,5,8,14,2,15,9,17,8,7,20,15,9,2,15,13,2,3,20,10};

	System.out.printf("NMI is: %.4f%n", getNmi(classIds, clusterIds));
    }

    public static double getNmi(int[] classIds, int[] clusterIds) {
	DoubleMatrix classMatrix, clusterMatrix, product, colSumVector, rowSumVector, left, right, secondProduct;
	double sumProduct, nmiValue, denominator;
	int m;

	if (min(classIds) <= 0 || min(clusterIds) <= 0) {
	    throw new IllegalArgumentException("Labels <= 0 forbidden!");
	}
	if (classIds.length != clusterIds.length) {
	    throw new IllegalArgumentException("Label vectors have different length!");
	}

	if (min(classIds) == max(classIds) && min(clusterIds) == max(clusterIds)) {
	    return 1.0;
	}

	m = classIds.length;

	classMatrix = DoubleMatrix.zeros(m, max(classIds));
	clusterMatrix = DoubleMatrix.zeros(m, max(clusterIds));

	for (int row = 0; row < m; row++) {
	    classMatrix.put(row, classIds[row] - 1, 1.0);
	    clusterMatrix.put(row, clusterIds[row] - 1, 1.0);
	}

	clusterMatrix = clusterMatrix.transpose();

	product = clusterMatrix.mmul(classMatrix);
	colSumVector = product.columnSums();
	rowSumVector = product.rowSums();

	left = DoubleMatrix.zeros(product.rows, colSumVector.columns);
	for (int row = 0; row < left.rows; row++) {
	    left.putRow(row, colSumVector);
	}

	right = DoubleMatrix.zeros(product.rows, colSumVector.columns);
	for (int column = 0; column < right.columns; column++) {
	    right.putColumn(column, rowSumVector);
	}

	secondProduct = left.mul(right);
	sumProduct = product.sum();

	for (int i = 0; i < secondProduct.getLength(); i++) {
	    if (secondProduct.get(i) > 0.0) {
		double v = (sumProduct * product.get(i)) / secondProduct.get(i);
		secondProduct.put(i, v);
	    }
	}

	for (int i = 0; i < secondProduct.getLength(); i++) {
	    if (secondProduct.get(i) > 0.0) {
		secondProduct.put(i, Math.log(secondProduct.get(i)));
	    }
	}

	secondProduct = product.mul(secondProduct);

	nmiValue = secondProduct.sum();

	for (int i = 0; i < colSumVector.getLength(); i++) {
	    if (colSumVector.get(i) > 0.0) {
		double v = colSumVector.get(i) * Math.log(colSumVector.get(i) / sumProduct);
		colSumVector.put(i, v);
	    }
	}

	for (int i = 0; i < rowSumVector.getLength(); i++) {
	    if (rowSumVector.get(i) > 0.0) {
		double v = rowSumVector.get(i) * Math.log(rowSumVector.get(i) / sumProduct);
		rowSumVector.put(i, v);
	    }
	}

	denominator = Math.sqrt(colSumVector.sum() * rowSumVector.sum());

	// epsilon estimation might be necessary, but now equal to original
	// implementation
	nmiValue = denominator == 0.0 ? 0.0 : nmiValue / denominator;

	return nmiValue;

	// Left for debugging (prints matrix nicely):
	// System.out.println((secondProduct.toString("%.1f")).replaceAll(";",
	// "\n"));
    }

    private static int max(int[] array) {
	int max = Integer.MIN_VALUE;
	for (int i = 0; i < array.length; i++) {
	    if (array[i] > max) {
		max = array[i];
	    }
	}
	return max;
    }

    private static int min(int[] array) {
	int min = Integer.MAX_VALUE;
	for (int i = 0; i < array.length; i++) {
	    if (array[i] < min) {
		min = array[i];
	    }
	}
	return min;
    }

    private static void normalize(int[] array) {
	if (min(array) == 0) {
	    for (int i = 0; i < array.length; i++) {
		array[i] += 1;
	    }
	}
    }

    private static int[] readFile(File file) throws IOException {
	ArrayList<Integer> ids = new ArrayList<Integer>();
	BufferedReader br = new BufferedReader(new FileReader(file));
	String line = null;

	while ((line = br.readLine()) != null) {
	    ids.add(Integer.parseInt(line.trim()));
	}
	br.close();

	int[] idsArray = new int[ids.size()];
	for (int i = 0; i < idsArray.length; i++) {
	    idsArray[i] = ids.get(i);
	}
	return idsArray;
    }

    private static int[] readLinewiseFile(File file) throws IOException {
	ArrayList<Integer> ids = new ArrayList<Integer>();
	TreeMap<Integer, Integer> tm = new TreeMap<Integer, Integer>();
	BufferedReader br = new BufferedReader(new FileReader(file));
	String line = null;
	int id = 1;

	while ((line = br.readLine()) != null) {
	    String[] ar = line.trim().split("\\s");
	    for (int i = 0; i < ar.length; i++) {
		tm.put(Integer.parseInt(ar[i]), id);
	    }
	    id++;
	}
	br.close();

	for (Integer i : tm.keySet()) {
	    ids.add(tm.get(i));
	}

	int[] idsArray = new int[ids.size()];
	for (int i = 0; i < idsArray.length; i++) {
	    idsArray[i] = ids.get(i);
	}
	return idsArray;
    }

}
