package anonymizedPackage.graphMiner.graphDrawer.presentation;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

import sun.security.provider.certpath.AdjacencyList;

/**
 * 
 * @version $Id: AdjMatrixJPanel.java 1898 2014-08-12 13:59:32Z goebl $
 */
public class AdjMatrixJPanel extends JPanel {

    private static final long serialVersionUID = -2152931823234946969L;

    final static Color lightGreen = new Color(220, 255, 220);
    final static Color lightYellow = new Color(255, 255, 220);
    final static Color lightRed = new Color(255, 150, 150);
    final static Color lightGray = new Color(210, 210, 210);

    private Color[] nodeColors;
    private int[] clusterIds;
    private int[][] adjacencyMatrix;
    private int yellowHighlightedNodeID;
    private int greenHighlightedNodeID;
    private int gridStrength;
    private double scaling;

    public AdjMatrixJPanel() {
	this.nodeColors = null;
	this.adjacencyMatrix = new int[0][0];
	this.scaling = 1.0;
	this.yellowHighlightedNodeID = -1;
	this.greenHighlightedNodeID = -1;
	this.gridStrength = 1;
	this.setPreferredSize(new Dimension(2000, 2000));
    }

    @Override
    protected void paintComponent(Graphics graphics) {
	Graphics2D graphics2D = (Graphics2D) graphics;
	setBackground(Color.white);
	drawAdjacencyMatrix(graphics2D);
    }

    private void drawAdjacencyMatrix(Graphics2D g) {
	double cellSize = 15.0 * scaling;
	double offsetTop = 5.0;
	double offsetLeft = 5.0;
	double offsetLabels = 2.0;
	double width = 0.0;
	double height = 0.0;
	int nodeCount = adjacencyMatrix.length;
	String nodeString = null;
	Font font = new Font("Arial", Font.PLAIN, (int) (10 * scaling));

	g.setFont(font);

	// calculate offset from top and left
	offsetTop += g.getFontMetrics().getStringBounds("0", g).getHeight();
	offsetLeft += g.getFontMetrics().getStringBounds("999", g).getWidth();

	// draw labels
	for (int i = 0; i < nodeCount; i++) {
	    nodeString = Integer.toString(i);
	    g.setColor(nodeColors[i]);
	    width = g.getFontMetrics().getStringBounds(nodeString, g).getWidth();
	    height = g.getFontMetrics().getStringBounds(nodeString, g).getHeight();
	    g.drawString(nodeString, (float) (offsetLeft + i * cellSize + (cellSize - width) / 2.0),
		    (float) (offsetTop - offsetLabels));
	    g.drawString(nodeString, (float) (offsetLeft - offsetLabels - width),
		    (float) (offsetTop + i * cellSize + height));
	}

	// draw nodes
	for (int i = 0; i < nodeCount; i++) {
	    for (int j = 0; j < nodeCount; j++) {
		if (i == yellowHighlightedNodeID || j == yellowHighlightedNodeID) {
		    if (adjacencyMatrix[i][j] == 1) {
			g.setColor(Color.yellow);
		    } else {
			g.setColor(lightYellow);
		    }
		} else if (i == greenHighlightedNodeID || j == greenHighlightedNodeID) {
		    if (adjacencyMatrix[i][j] == 1) {
			g.setColor(Color.green);
		    } else {
			g.setColor(lightGreen);
		    }
		} else if (adjacencyMatrix[i][j] == 1) {
		    if (clusterIds[i] % 2 == 0 && clusterIds[j] % 2 == 0) {
			g.setColor(Color.black);
		    } else {
			g.setColor(Color.black);
		    }

		} else {
		    if (clusterIds[i] % 2 == 0 && clusterIds[j] % 2 == 0) {
			g.setColor(Color.white);
		    } else {
			g.setColor(lightGray);
		    }
		}
		g.fillRect((int) (offsetLeft + i * cellSize + gridStrength),
			(int) (offsetTop + j * cellSize + gridStrength), (int) (cellSize - 2 * gridStrength),
			(int) (cellSize - 2 * gridStrength));
	    }
	}
    }

    public void setNodeColors(Color[] nodeColors) {
	this.nodeColors = nodeColors;
    }

    public void updateData(int[][] adjacencyMatrix, Color[] nodeColors, int yellowHighlightedNodeID,
	    int greenHighlightedNodeID, int[] clusterIds) {
	this.adjacencyMatrix = adjacencyMatrix;
	this.nodeColors = nodeColors;
	this.yellowHighlightedNodeID = yellowHighlightedNodeID;
	this.greenHighlightedNodeID = greenHighlightedNodeID;
	this.clusterIds = clusterIds;
    }

    public void showAdjacencyDummy() {
        adjacencyMatrix = new int[0][0];
        
    }

    public void increaseScaling() {
	if (scaling < 10.0) {
	    scaling += 0.1;
	}
    }

    public void decreaseScaling() {
	if (scaling > 0.1) {
	    scaling -= 0.1;
	}
    }

    public void toggleGrid() {
	if (gridStrength == 0) {
	    gridStrength = 1;
	} else {
	    gridStrength = 0;
	}
    }
}
