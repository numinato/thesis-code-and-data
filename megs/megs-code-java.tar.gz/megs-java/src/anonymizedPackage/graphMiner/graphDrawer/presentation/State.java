package anonymizedPackage.graphMiner.graphDrawer.presentation;

/**
* 
* @version $Id: State.java 1743 2014-06-27 14:36:51Z goebl $
*/
public enum State {
	FIXED, SELECTED, DRAGGED, PERMUTING, MOVING, PRE_MOVING_PERMUTING, DELETING, COLORING, CLUSTERING;
}
