package anonymizedPackage.graphMiner.graphDrawer.presentation;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.ItemSelectable;
import java.awt.Point;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;

import org.jdesktop.swingx.JXStatusBar;

import anonymizedPackage.graphMiner.graphDrawer.accessories.ViewState;
import anonymizedPackage.graphMiner.graphDrawer.accessories.ViewStateable;
import anonymizedPackage.graphMiner.graphDrawer.model.Edge;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

/**
 * 
 * @version $Id: GraphDrawerView.java 1743 2014-06-27 14:36:51Z goebl $
 */
public class GraphDrawerView extends JFrame implements ViewStateable {

    private static final long serialVersionUID = 9106966553662272713L;

    private GraphJPanel leftJPanel;
    private AdjMatrixJPanel rightJPanel;
    private JPanel pRight;
    private JPanel pInfoInput;
    private JScrollPane jspRight;
    private JTextArea jtaInfo;
    private JLabel statusLabel1;
    private JLabel statusLabel2;
    private JLabel statusLabel3;
    private ArrayList<Node> nodes;
    private ArrayList<Edge> edges;

    private JMenuBar menuBar;

    private JMenu menuView;

    private JMenu menuSettings;
    private JMenuItem menuItem1;
    private JMenuItem menuItem2;
    private JMenuItem menuItem3;
    private JMenuItem menuItem4;
    private JMenuItem menuItem5;
    private JMenuItem menuItem6;

    public JTextArea jtaInput;

    public GraphDrawerView(ArrayList<Node> nodes, ArrayList<Edge> edges) {
	super("Graph Drawer");
	this.nodes = nodes;
	this.edges = edges;
	initView();
    }

    private void initView() {

	System.setProperty("apple.laf.useScreenMenuBar", "true");
	try {
	    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	} catch (Exception e) {
	    e.printStackTrace();
	}

	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	// setSize(1500, 950);
	setSize(1500, 800);
	leftJPanel = new GraphJPanel(this);
	rightJPanel = new AdjMatrixJPanel();

	this.setLayout(new BorderLayout());
	JPanel mainJPanel = new JPanel();
	mainJPanel.setLayout(new GridLayout(1, 2, 0, 0));

	pRight = new JPanel();
	pRight.setLayout(new BorderLayout(0, 0));
	jspRight = new JScrollPane(rightJPanel, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
		JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

	pInfoInput = new JPanel();
	pInfoInput.setLayout(new BorderLayout(0, 3));

	jtaInfo = new JTextArea(3, 20);
	jtaInfo.setEditable(false);
	// jtaInfo.setEnabled(true);
	jtaInfo.setEnabled(false);

	jtaInput = new JTextArea(2, 20);
	jtaInput.setText("100,0");
	jtaInput.setEditable(false);
	jtaInput.setEnabled(false);

	pInfoInput.add(jtaInfo, BorderLayout.NORTH);
	pInfoInput.add(jtaInput, BorderLayout.CENTER);

	pRight.add(pInfoInput, BorderLayout.NORTH);

	pRight.add(jspRight, BorderLayout.CENTER);

	JScrollPane jsp = new JScrollPane(leftJPanel, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
		JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

	JXStatusBar statusBar = new JXStatusBar();

	this.getContentPane().add(mainJPanel, BorderLayout.CENTER);
	this.getContentPane().add(statusBar, BorderLayout.SOUTH);

	mainJPanel.add(jsp);
	mainJPanel.add(pRight);

	statusLabel1 = new JLabel("Ready.");
	statusLabel2 = new JLabel("");
	statusLabel3 = new JLabel("");
	JXStatusBar.Constraint c1 = new JXStatusBar.Constraint();
	c1.setFixedWidth(100);
	JXStatusBar.Constraint c2 = new JXStatusBar.Constraint();
	c2.setFixedWidth(500);
	JXStatusBar.Constraint c3 = new JXStatusBar.Constraint(
		JXStatusBar.Constraint.ResizeBehavior.FILL);
	statusBar.add(statusLabel1, c1);
	statusBar.add(statusLabel2, c2);
	statusBar.add(statusLabel3, c3);

	// create menu
	menuBar = new JMenuBar();
	menuSettings = new JMenu("Settings");
	menuView = new JMenu("View");
	menuBar.add(menuSettings);
	menuBar.add(menuView);

	menuItem1 = new JCheckBoxMenuItem("Verbose Visualisation");
	menuItem1.setSelected(false);
	menuItem3 = new JCheckBoxMenuItem("Show Split and Merge");
	menuItem3.setSelected(false);
	menuItem4 = new JCheckBoxMenuItem("Reset Graph Labels Before Clustering");
	menuItem4.setSelected(true);
	menuItem5 = new JCheckBoxMenuItem("Save Best MDL Clustering");
	menuItem5.setSelected(true);
	menuItem6 = new JCheckBoxMenuItem("Load Sparse (Unconnected) Nodes");
	menuItem6.setSelected(true);
	
	menuSettings.add(menuItem1);
	menuSettings.add(menuItem3);
	menuSettings.add(menuItem4);
	menuSettings.add(menuItem5);
	menuSettings.add(menuItem6);

	menuItem2 = new JMenuItem("Maximize");
	menuView.add(menuItem2);

	this.setJMenuBar(menuBar);

	this.setSize(1024, 1000);
	// this.setSize(1680, 1050);
	// this.pack();
    }

    public void setJtaInfo(String s) {
	jtaInfo.setText(s);
    }

    public void setInputMouseListener(MouseListener m) {
	jtaInput.addMouseListener(m);
    }

    public void setKeyListener(KeyListener k) {
	this.addKeyListener(k);
    }

    public void setCurrentNode(Node node) {
	leftJPanel.setCurrentNode(node);
    }

    public void setGraphMouseListener(MouseListener ml) {
	leftJPanel.setMouseListener(ml);
    }

    public void setGraphMotionListener(MouseMotionListener mml) {
	leftJPanel.setMouseMotionListener(mml);
    }

    public void setItemListener(ItemListener il) {
	menuItem1.addItemListener(il);
	menuItem3.addItemListener(il);
	menuItem4.addItemListener(il);
	menuItem5.addItemListener(il);
	menuItem6.addItemListener(il);
    }

    public void setActionListener(ActionListener a) {
	menuItem2.addActionListener(a);
    }

    public Node getCurrentNode() {
	return leftJPanel.getCurrentNode();
    }

    public void setCurrentMousePoint(Point currentMousePoint) {
	leftJPanel.setCurrentMousePoint(currentMousePoint);
    }

    public Point getCurrentMousePoint() {
	return leftJPanel.getCurrentMousePoint();
    }

    public ArrayList<Node> getNodes() {
	return nodes;
    }

    public ArrayList<Edge> getEdges() {
	return edges;
    }

    public void setNodes(ArrayList<Node> nodes) {
	this.nodes = nodes;
    }

    public void setEdges(ArrayList<Edge> edges) {
	this.edges = edges;
    }

    public void updateData(int[][] adjacencyMatrix, Color[] nodeColors) {
	rightJPanel.updateData(adjacencyMatrix, nodeColors, -1, -1, null);
    }

    public void updateData(int[][] adjacencyMatrix, Color[] nodeColors, int node1IdHighlighted,
	    int node2IdHighlighted, int[] clusterIds) {
	rightJPanel.updateData(adjacencyMatrix, nodeColors, node1IdHighlighted, node2IdHighlighted,
		clusterIds);
    }

    public void showAdjacencyDummy() {
	rightJPanel.showAdjacencyDummy();

    }

    public void increaseScaling() {
	rightJPanel.increaseScaling();
    }

    public void decreaseScaling() {
	rightJPanel.decreaseScaling();
    }

    public void toggleGrid() {
	rightJPanel.toggleGrid();
    }

    public void setState(ViewState vs) {
	leftJPanel.setState(vs);
    }

    public void setStatusLabels(String label1, String label2, String label3) {
	if (label1 != null) {
	    statusLabel1.setText(label1);
	}
	if (label2 != null) {
	    statusLabel2.setText(label2);
	}
	if (label3 != null) {
	    statusLabel3.setText(label3);
	}
    }

    public void setGraphJPanelSize(Dimension dimension) {
	leftJPanel.setPreferredSize(dimension);
    }

    public JMenuItem getMenuItem1() {
	return menuItem1;
    }

    public JMenuItem getMenuItem2() {
	return menuItem2;
    }

    public JMenuItem getMenuItem3() {
	return menuItem3;
    }

    public JMenuItem getMenuItem4() {
	return menuItem4;
    }

    public JMenuItem getMenuItem5() {
	return menuItem5;
    }

    public JMenuItem getMenuItem6() {
	return menuItem6;
    }

    public void maximizeView() {
	this.setExtendedState(this.getExtendedState() | JFrame.MAXIMIZED_BOTH);
    }


}
