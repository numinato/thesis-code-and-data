package anonymizedPackage.graphMiner.graphDrawer.presentation;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import anonymizedPackage.graphMiner.graphDrawer.accessories.ViewState;
import anonymizedPackage.graphMiner.graphDrawer.accessories.ViewStateable;
import anonymizedPackage.graphMiner.graphDrawer.model.Edge;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;

/**
 * 
 * @version $Id: GraphJPanel.java 1844 2014-07-23 16:51:04Z goebl $
 */
public class GraphJPanel extends JPanel implements ViewStateable {

    private static final long serialVersionUID = 1676592908399372053L;

    private ViewState state;
    private GraphDrawerView parentView = null;
    private Node currentNode;
    private Point currentMousePoint;

    public GraphJPanel(GraphDrawerView gdv) {
	state = ViewState.NODES_PLAIN;
	parentView = gdv;
	currentNode = null;
	currentMousePoint = null;

	setPreferredSize(new Dimension(1000, 1000));
    }

    @Override
    protected void paintComponent(Graphics graphics) {
	Graphics2D graphics2D = (Graphics2D) graphics;
	setBackground(Color.white);
	drawEdges(graphics2D);
	drawNodes(graphics2D);

    }

    @SuppressWarnings("unchecked")
    private void drawNodes(Graphics2D graphics2D) {
	// draw the nodes
	switch (state) {
	case NODES_DENOTED_ALL:
	    for (Node node : parentView.getNodes()) {
		drawNode(graphics2D, node, Color.red);
	    }
	    break;
	case SELECTED:
	    drawColoredNodes(graphics2D, Color.red, Color.black);
	    break;
	case MOVING:
	    drawColoredNodes(graphics2D, Color.green, Color.black);
	    break;
	case PERMUTING:
	    drawColoredNodes(graphics2D, Color.blue, Color.black);
	    break;
	default:
	    for (Iterator<Node> iter = parentView.getNodes().iterator(); iter.hasNext();) {
		Node node = iter.next();
		drawNode(graphics2D, node, node.getColor());
	    }
	}
    }

    private void drawColoredNodes(Graphics2D graphics2D, Color selectedColor, Color unselectedColor) {
	for (Node node : parentView.getNodes()) {
	    if (node.equals(currentNode)) {
		drawNode(graphics2D, node, selectedColor);
	    } else {
		drawNode(graphics2D, node, unselectedColor);
	    }
	}
    }

    private void drawEdges(Graphics2D graphics2D) {
	// draw the lines
	switch (state) {
	case MOVING:
	    for (Edge edge : parentView.getEdges()) {
		if (edge.containsAsNode1(currentNode)) {
		    edge.x1 = currentMousePoint.x;
		    edge.y1 = currentMousePoint.y;
		    graphics2D.setColor(Color.green);
		    graphics2D.draw(edge);
		} else if (edge.containsAsNode2(currentNode)) {
		    edge.x2 = currentMousePoint.x;
		    edge.y2 = currentMousePoint.y;
		    graphics2D.setColor(Color.green);
		    graphics2D.draw(edge);
		} else {
		    graphics2D.setColor(Color.black);
		    graphics2D.draw(edge);
		}
	    }
	    break;

	case SELECTED:
	    for (Edge edge : parentView.getEdges()) {
		graphics2D.setColor(Color.black);
		graphics2D.draw(edge);
	    }
	    graphics2D.setColor(Color.red);
	    graphics2D.draw(new Edge(currentNode, currentMousePoint.x, currentMousePoint.y));
	    break;

	case NODES_DENOTED_ALL:
	    for (Edge edge : parentView.getEdges()) {
		graphics2D.setColor(Color.red);
		graphics2D.draw(edge);
	    }
	    break;
	default:
	    for (Edge edge : parentView.getEdges()) {
		graphics2D.setColor(new Color(0, 0, 0));
		graphics2D.draw(edge);
	    }
	    break;
	}
    }

    private void drawNode(Graphics2D graphics2D, Node node, Color nodeColor) {
	String nodeIdString;
	double width;
	int nodeSize;
	int nodeID = parentView.getNodes().indexOf(node);

	nodeIdString = Integer.toString(nodeID);

	nodeSize = Node.getShapeSize();
	graphics2D.setFont(new Font("Arial", Font.BOLD, (2 * nodeSize) / 3));
	width = graphics2D.getFontMetrics().getStringBounds(nodeIdString, graphics2D).getWidth();

	graphics2D.setColor(nodeColor);
	graphics2D.setPaint(nodeColor);
	graphics2D.draw(node.getShape());
	graphics2D.fill(node.getShape());

	graphics2D.setColor(Color.white);

	graphics2D.drawString(nodeIdString, (int) (node.getX() - width / 2), node.getY() + 5);
    }

    /**
     * Saves this canvas's graphics to a file as a PNG image in the given
     * filename.
     * 
     * @param filename
     */
    public void savePNG(String filename) {
	BufferedImage image = new BufferedImage(this.getWidth(), this.getHeight(), BufferedImage.TYPE_4BYTE_ABGR);
	// call the paint method using the images graphics instead of the
	// canvas's
	this.paint(image.getGraphics());
	// try to write. If we get an error, we bury our head into the sand
	try {
	    ImageIO.write(image, "png", new File(filename));
	} catch (IOException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
    }

    public void setMouseListener(MouseListener ml) {
	this.addMouseListener(ml);
    }

    public void setMouseMotionListener(MouseMotionListener mml) {
	this.addMouseMotionListener(mml);

    }

    public void setCurrentNode(Node currentNode) {
	this.currentNode = currentNode;
    }

    public void setCurrentMousePoint(Point currentMousePoint) {
	this.currentMousePoint = currentMousePoint;
    }

    public Node getCurrentNode() {
	return currentNode;
    }

    public Point getCurrentMousePoint() {
	return currentMousePoint;
    }

    @Override
    public void setState(ViewState vs) {
	this.state = vs;
    }

}
