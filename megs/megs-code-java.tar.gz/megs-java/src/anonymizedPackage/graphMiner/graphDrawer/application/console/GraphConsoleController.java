package anonymizedPackage.graphMiner.graphDrawer.application.console;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;

import anonymizedPackage.graphMiner.graphClusterer.SplitMergeClusterer;
import anonymizedPackage.graphMiner.graphDrawer.accessories.GraphGenerator;
import anonymizedPackage.graphMiner.graphDrawer.accessories.JungGraphViewerAdapter;
import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.GraphType;
import anonymizedPackage.graphMiner.graphDrawer.presentation.State;

/**
 * 
 * @version $Id: GraphConsoleController.java 2247 2015-05-18 15:55:42Z goebl $
 */
public class GraphConsoleController {

    static final double EPSILON = 1e-10;

    public Graph graphModel;

    GraphType[] graphTypes;
    State state;
    boolean done = false;

    File lastLoadedFile;
    boolean isVerboseVisual;
    boolean isShowingSplitMerge;
    boolean doSaveBestNmiModel;
    boolean doResetBeforeClustering;
    boolean loadSparse;

    public int userValue;

    public GraphConsoleController() {
	graphModel = new Graph();
	state = State.FIXED;

	graphTypes = null;
	lastLoadedFile = null;
	isVerboseVisual = false;
	isShowingSplitMerge = false;
	doSaveBestNmiModel = true;
	doResetBeforeClustering = true;
	loadSparse = true;

    }

    class GraphDrawerKeyListener implements KeyListener {
	char keyChar;

	@Override
	public void keyPressed(KeyEvent keyEvent) {
	}

	@Override
	public void keyReleased(KeyEvent keyEvent) {
	};

	@Override
	public void keyTyped(KeyEvent keyEvent) {
	    keyChar = keyEvent.getKeyChar();
	    switch (keyChar) {
	    case 'r': // create a random permutation
		      // randomize the node IDs
		graphModel.randomize();
		break;
	    case 'R': // reset to last loaded graph if existing
		if (state == State.FIXED) {
		    resetGraph();
		}
		break;
	    case ' ': // print the adjacency matrix to the console window
		graphModel.printAdjacencyMatrix();
		break;
	    case 'v':
		(new JungGraphViewerAdapter(graphModel)).visualize();
		break;
	    case 'Q': // delete all graph information and initialize new graph
		if (state == State.FIXED) {
		    graphModel = new Graph();
		    lastLoadedFile = null;
		}
		break;
	    default:
		int i = (int) keyChar - 48;
		break;
	    }
	}

    }

    void saveBestModel() {
	if (lastLoadedFile != null) {
	    String filename = lastLoadedFile.getName().substring(0,
		    lastLoadedFile.getName().toString().length() - 4)
		    + "_bestMdl.mat";
	    graphModel.save(new File(lastLoadedFile.getParentFile(), filename), "mat");
	    graphModel.save(new File(lastLoadedFile.getParentFile(), filename), "grx");
	    // graphModel.save(new File(lastLoadedFile.getParentFile(), filename
	    // + ".grd"), "grd");
	}
    }

    private void loadModel(File file) {
	this.graphModel = new Graph(file, loadSparse);

	lastLoadedFile = file;
    }

    void resetGraph() {
	if (lastLoadedFile != null) {
	    loadModel(lastLoadedFile);
	}
    }

    private void cluster() {
	if (state == State.FIXED & graphModel.size() > 0) {
	    state = State.CLUSTERING;
	    ConsoleClusterer clusterer = new ConsoleClusterer(GraphConsoleController.this);
	    (new Thread(clusterer)).start();
	}
    }

    private void cluster(int nExperiments, int nInternalRuns) {
	if (state == State.FIXED & graphModel.size() > 0) {
	    state = State.CLUSTERING;
	    ConsoleClusterer clusterer = new ConsoleClusterer(nExperiments, nInternalRuns,
		    GraphConsoleController.this);
	    (new Thread(clusterer)).start();
	}
    }

    public static void main(String[] args) {
	GraphConsoleController gcc = new GraphConsoleController();
	int nExperiments = 1; // default
	int nInternalRuns = 30; // default

	if (args.length >= 4) {
	    if (args[3].equalsIgnoreCase("-noSparse")) {
		gcc.loadSparse = false;
		SplitMergeClusterer.hasSparse = false;
	    }
	}

	if (args.length >= 3) {
	    nInternalRuns = Integer.parseInt(args[2]);
	}

	if (args.length >= 2) {
	    nExperiments = Integer.parseInt(args[1]);

	}

	if (args.length >= 1) {
	    gcc.loadModel(new File(args[0]));
	    gcc.cluster(nExperiments, nInternalRuns);
	}

	if (args.length == 0) {
	    System.out
		    .println("usage: java -jar graphMiner.jar file <numberExperiments> <numberInternalRuns>");
	}
    }

}
