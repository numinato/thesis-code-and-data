package anonymizedPackage.graphMiner.graphDrawer.application.gui;

import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import javax.swing.SwingUtilities;

import org.apache.commons.math3.analysis.function.Exp;
import org.apache.commons.math3.stat.descriptive.moment.StandardDeviation;

import anonymizedPackage.graphMiner.graphClusterer.GraphSizeException;
import anonymizedPackage.graphMiner.graphClusterer.SplitMergeClusterer;
import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;
import anonymizedPackage.graphMiner.graphDrawer.presentation.State;

public class Clusterer implements Runnable {

    private GraphDrawerController gdc;

    Clusterer(GraphDrawerController gdc) {
	this.gdc = gdc;
    }

    SplitMergeClusterer clusterer;

    public void run() {
	int nExperiments = 1;

	FileWriter fw;

	try {
	    fw = new FileWriter("results.txt", true);
	    fw.write("\n===========================================\nFILE: \"" + gdc.lastLoadedFile
		    + "\"");
	    fw.write("\nMDL\t\tNMI\t\tRUNTIME\n");

	    double[] mdls = new double[nExperiments];
	    double[] nmis = new double[nExperiments];
	    double[] runtimes = new double[nExperiments];

	    double bestNmi = 0.0;
	    double minMdl = Double.MAX_VALUE;

	    for (int i = 0; i < nExperiments; i++) {
		if (gdc.doResetBeforeClustering) {
		    gdc.resetGraph();
		}
		double time = System.currentTimeMillis();
		cluster();
		runtimes[i] = (System.currentTimeMillis() - time) / 1000.0;
		mdls[i] = clusterer.getMdl();
		nmis[i] = clusterer.getNmi();

		if (clusterer.getMdl() < minMdl) {
		    minMdl = clusterer.getMdl();
		    bestNmi = clusterer.getNmi();
		    if (gdc.doSaveBestNmiModel) {
			gdc.saveBestModel();
		    }
		}
		fw.write(String.format("%.4f\t%.4f\t\t%.4f%n", clusterer.getMdl(),
			clusterer.getNmi(), runtimes[i]));
		fw.flush();

	    }

	    double meanNmi = 0.0;
	    double meanMdl = 0.0;
	    double meanRuntime = 0.0;

	    for (int i = 0; i < nExperiments; i++) {
		meanNmi += nmis[i];
		meanMdl += mdls[i];
		meanRuntime += runtimes[i];
	    }

	    meanNmi /= nExperiments;
	    meanMdl /= nExperiments;
	    meanRuntime /= nExperiments;

	    StandardDeviation std = new StandardDeviation();
	    std.evaluate(nmis);

	    double stdMdl = std.evaluate(mdls);
	    double stdNmi = std.evaluate(nmis);
	    double stdRuntime = std.evaluate(runtimes);

	    System.err.printf("%n%nMDL = %.4f +- %.4f%n" + "NMI = %.4f +- %.4f%n"
		    + "Time = %.4f +- %.4f%n>>Best NMI = %.4f%n", meanMdl, stdMdl, meanNmi, stdNmi,
		    meanRuntime, stdRuntime, bestNmi);

	    fw.write("---------------------------------------------\n");
	    fw.write(String.format("%.4f\t%.4f\t\t%.4f%n", meanMdl, meanNmi, meanRuntime));
	    fw.write(String.format("+-%.4f\t+-%.4f\t+-%.4f%n", stdMdl, stdNmi, stdRuntime));
	    fw.write(String.format("Best NMI found by MDL is %.4f", bestNmi));
	    fw.flush();
	    fw.close();

	} catch (IOException e) {
	    e.printStackTrace();
	}

	// tidy up
	this.gdc.view.setStatusLabels("Ready.", "", null);
	this.gdc.state = State.FIXED;
    }

    /**
     * Does the clustering
     */
    private void cluster() {
	Node node = null;
	double cost;
	double mdlCost = 0.0;
	double newMdlCost = -1.0;

	long t = System.currentTimeMillis();
	this.gdc.state = State.CLUSTERING;

	System.err.print("Class labels are ");
	// set ids + class labels (ugly workaround)
	for (int i = 0; i < this.gdc.graphModel.size(); i++) {
	    Node n = this.gdc.graphModel.getNode(i);
	    n.setId(i);
	    n.setClassLabel(n.getLabel());
	    System.err.print(n.getLabel() + " ");
	}
	System.err.println();

	// initialize new clustering
	// clustering = new Clustering(graphModel, k);
	Graph debugGraph = new Graph(this.gdc.graphModel);
	try {
	    clusterer = new SplitMergeClusterer(this.gdc.graphModel);
	} catch (GraphSizeException e1) {
	    // Graph was too small (shouldn't really happen)
	    e1.printStackTrace();
	}

	repaintThreaded(-1, -1);
	if (this.gdc.isVerboseVisual) {
	    try {
		Thread.sleep(500);
	    } catch (InterruptedException e) {
		e.printStackTrace();
	    }
	}
	// set matrix to 'all nodes black'
	clusterer.update(this.gdc.graphModel);
	assert this.gdc.graphModel.getNodes().containsAll(debugGraph.getNodes())
		&& debugGraph.getNodes().containsAll(this.gdc.graphModel.getNodes());
	repaintThreaded(-1, -1);
	if (this.gdc.isVerboseVisual) {
	    try {
		Thread.sleep(500);
	    } catch (InterruptedException e) {
		e.printStackTrace();
	    }
	}

	// run clustering
	while (newMdlCost != mdlCost) {
	    assert !(newMdlCost > mdlCost + GraphDrawerController.EPSILON) || mdlCost == -1.0
		    || newMdlCost == -1.0;
	    mdlCost = newMdlCost;

	    double mdlCostBeforeSplit = clusterer.getMdl();
	    System.err.println(">> Current MDL is " + clusterer.getMdl());
	    System.err.println("Splitting..");
	    clusterer.split();
	    double mdlCostAfterSplit = clusterer.getMdl();
	    assert !(mdlCostAfterSplit > mdlCostBeforeSplit + GraphDrawerController.EPSILON)
		    || mdlCost == -1.0 || newMdlCost == -1.0;
	    if (this.gdc.isShowingSplitMerge) {
		repaintThreaded(-1, -1);
	    }
	    System.err.println(">> Current MDL is " + clusterer.getMdl());
	    System.err.println("Merging..");
	    double mdlCostBeforeMerge = clusterer.getMdl();
	    clusterer.merge();
	    double mdlCostAfterMerge = clusterer.getMdl();
	    assert !(mdlCostAfterMerge > mdlCostBeforeMerge + GraphDrawerController.EPSILON)
		    || mdlCost == -1.0 || newMdlCost == -1.0;

	    if (this.gdc.isShowingSplitMerge) {
		repaintThreaded(-1, -1);
	    }
	    System.err.println(">> Current MDL is " + clusterer.getMdl());
	    System.err.println("Assigning..");

	    clusterer.createNodeProcessingOrder();
	    while ((node = clusterer.nextNode()) != null) {
		int nodeId;
		// System.err.println("Assigning Node (ID) " +
		// graphModel.indexOf(node));

		this.gdc.view.setStatusLabels("Clustering.", "[Memory used: "
			+ (Runtime.getRuntime().totalMemory() / 1024 / 1024) + "m/"
			+ (Runtime.getRuntime().maxMemory() / 1024 / 1024) + "m]", null);

		// ****
		// if (Main.debuggingEnabled) {
		// repaintThreaded(graphModel.getNodes().indexOf(node), -1);
		// try {
		// Thread.sleep(500);
		// } catch (InterruptedException e) {
		// e.printStackTrace();
		// }
		// }
		// ****

		// clustering.step(node);
		double mdlCostBeforeAssignment = clusterer.getMdl();
		assert this.gdc.graphModel.contains(node);
		clusterer.updateClustering(node);
		clusterer.update(this.gdc.graphModel);
		double mdlCostAfterAssignment = clusterer.getMdl();
		assert !(mdlCostAfterAssignment > mdlCostBeforeAssignment
			+ GraphDrawerController.EPSILON)
			|| mdlCost == -1.0 || newMdlCost == -1.0;
		nodeId = this.gdc.graphModel.indexOf(node);
		if (this.gdc.isVerboseVisual) {
		    repaintThreaded(-1, nodeId);
		    try {
			Thread.sleep(100);
		    } catch (InterruptedException e) {
			e.printStackTrace();
		    }
		}

		// ****
		// if (Main.debuggingEnabled) {
		// try {
		// Thread.sleep(500);
		// } catch (InterruptedException e) {
		// e.printStackTrace();
		// }
		// }
		// ****

		System.err.println(">> Current MDL is " + clusterer.getMdl());
	    }
	    // clusterer.merge();

	    System.err.println(clusterer.clustering.toString());

	    // double newMdl = -1.0;
	    // double mdl = clusterer.getMdl();
	    // while (newMdlCost != mdl) {
	    // assert !(newMdl > mdl + EPSILON) || mdl == -1.0 || newMdl ==
	    // -1.0;
	    // mdl = newMdl;
	    // System.err.println("Splitting..");
	    // clusterer.split();
	    // repaintThreaded(-1, -1);
	    // System.err.println("Merging..");
	    // clusterer.merge();
	    // repaintThreaded(-1, -1);
	    // newMdl = clusterer.getMdl();
	    // }
	    newMdlCost = clusterer.getMdl();
	}

	// set matrix to 'all nodes black' again
	clusterer.sort(this.gdc.graphModel);
	repaintThreaded(-1, -1);

	// show result info on view
	cost = clusterer.getMdl();
	this.gdc.graphTypes = clusterer.getGraphTypes();
	StringBuilder sb = new StringBuilder();
	sb.append(String.format("MDL = %.4f, ( ", cost));
	for (int i = 0; i < this.gdc.graphTypes.length; i++) {
	    sb.append(this.gdc.graphTypes[i].toString()).append(" : ")
		    .append(String.format("%.2f", clusterer.clustering.get(i).getMinMdl()))
		    .append(" , ");
	}
	sb.append(").\nTime used for clustering: ");
	sb.append(String.format("%.2f", (System.currentTimeMillis() - t) / 1000.0));
	sb.append(" s");
	sb.append(String.format("%nNMI = %.4f", clusterer.getNmi()));
	this.gdc.view.setJtaInfo(sb.toString());
    }

    private void repaintThreaded(final int nodeId1, final int nodeId2) {
	try {
	    SwingUtilities.invokeAndWait(new Runnable() {
		public void run() {
		    Clusterer.this.gdc.view.setNodes(Clusterer.this.gdc.graphModel.getNodes());
		    Clusterer.this.gdc.view.setEdges(Clusterer.this.gdc.graphModel.getEdges());
		    setNodeClusters();
		    Clusterer.this.gdc.updateAdjacencyMatrix(nodeId1, nodeId2);
		    Clusterer.this.gdc.view.repaint();
		}
	    });
	} catch (InvocationTargetException e) {
	    e.printStackTrace();
	} catch (InterruptedException e) {
	    e.printStackTrace();
	}
    }

    protected void setNodeClusters() {
	int[] clusterBegins = clusterer.getClusterBegins();

	int id = 0;
	for (int n = 0; n < this.gdc.graphModel.size(); n++) {
	    if ((id < clusterBegins.length - 1) && (n == clusterBegins[id + 1])) {
		id++;
	    }
	    this.gdc.graphModel.getNode(n).setLabel(id);
	}
    }
}