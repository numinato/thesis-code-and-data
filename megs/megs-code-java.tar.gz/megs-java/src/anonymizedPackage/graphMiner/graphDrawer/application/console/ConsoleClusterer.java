package anonymizedPackage.graphMiner.graphDrawer.application.console;

import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import javax.swing.SwingUtilities;

import org.apache.commons.math3.analysis.function.Exp;
import org.apache.commons.math3.stat.descriptive.moment.StandardDeviation;

import anonymizedPackage.graphMiner.graphClusterer.GraphSizeException;
import anonymizedPackage.graphMiner.graphClusterer.SplitMergeClusterer;
import anonymizedPackage.graphMiner.graphDrawer.application.gui.GraphDrawerController;
import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;
import anonymizedPackage.graphMiner.graphDrawer.presentation.State;

public class ConsoleClusterer implements Runnable {

    private GraphConsoleController gcc;
    private int nExperiments;
    private int nInternalRuns;
    SplitMergeClusterer clusterer;

    ConsoleClusterer(GraphConsoleController gcc) {
	this.gcc = gcc;
	this.nExperiments = 1;
	this.nInternalRuns = 30;
    }

    public ConsoleClusterer(int nExperiments, int nInternalRuns, GraphConsoleController gcc) {
	this(gcc);
	this.nExperiments = nExperiments;
	this.nInternalRuns = nInternalRuns;
    }

    public void run() {

	FileWriter fw;
	String resultInfoBestNmi = null;

	try {
	    fw = new FileWriter("results.txt", true);
	    fw.write(System.lineSeparator());
	    fw.write("===========================================");
	    fw.write(System.lineSeparator());
	    fw.write("FILE: \"" + gcc.lastLoadedFile + "\"");
	    fw.write(System.lineSeparator());
	    fw.write("MDL\t\tNMI\t\tRUNTIME");
	    fw.write(System.lineSeparator());

	    double[] mdls = new double[nExperiments];
	    double[] nmis = new double[nExperiments];
	    double[] runtimes = new double[nExperiments];

	    double bestNmi = 0.0;
	    double minMdl = Double.MAX_VALUE;

	    for (int i = 0; i < nExperiments; i++) {
		double mdl, nmi, runMdl;
		nmi = 0;
		mdl = Double.MAX_VALUE;
		String resultInfo = null;
		double time = System.currentTimeMillis();

		for (int j = 0; j < nInternalRuns; j++) {
		    String result;
		    if (gcc.doResetBeforeClustering) {
			gcc.resetGraph();
		    }
		    result = cluster();
		    runMdl = clusterer.getMdl();
		    if (runMdl < mdl) {
			mdl = runMdl;
			nmi = clusterer.getNmi();
			if (mdl < minMdl) {
			    resultInfo = result;
			    if (gcc.doSaveBestNmiModel) {
				gcc.saveBestModel();
			    }
			}
		    }
		}

		runtimes[i] = (System.currentTimeMillis() - time) / 1000.0;
		mdls[i] = mdl;
		nmis[i] = nmi;

		if (mdl < minMdl) {
		    minMdl = mdl;
		    bestNmi = nmi;
		    resultInfoBestNmi = resultInfo;

		}
		fw.write(String.format("%.4f\t%.4f\t\t%.4f%n", mdl, nmi, runtimes[i]));
		fw.flush();

	    }

	    double meanNmi = 0.0;
	    double meanMdl = 0.0;
	    double meanRuntime = 0.0;

	    for (int i = 0; i < nExperiments; i++) {
		meanNmi += nmis[i];
		meanMdl += mdls[i];
		meanRuntime += runtimes[i];
	    }

	    meanNmi /= nExperiments;
	    meanMdl /= nExperiments;
	    meanRuntime /= nExperiments;

	    StandardDeviation std = new StandardDeviation();
	    std.evaluate(nmis);

	    double stdMdl = std.evaluate(mdls);
	    double stdNmi = std.evaluate(nmis);
	    double stdRuntime = std.evaluate(runtimes);

	    System.err.printf("%n%nMDL = %.4f +- %.4f%n" + "NMI = %.4f +- %.4f%n"
		    + "Time = %.4f +- %.4f%n>>Best NMI = %.4f%n", meanMdl, stdMdl, meanNmi, stdNmi,
		    meanRuntime, stdRuntime, bestNmi);

	    System.err.println(resultInfoBestNmi);

	    fw.write("---------------------------------------------\n");
	    fw.write(String.format("%.4f\t%.4f\t\t%.4f%n", meanMdl, meanNmi, meanRuntime));
	    fw.write(String.format("+-%.4f\t+-%.4f\t+-%.4f%n", stdMdl, stdNmi, stdRuntime));
	    fw.write(String.format("Best NMI found by MDL is %.4f", bestNmi));

	    fw.write(resultInfoBestNmi);
	    fw.flush();
	    fw.close();

	} catch (IOException e) {
	    e.printStackTrace();
	}

	// tidy up
	this.gcc.state = State.FIXED;
    }

    /**
     * Does the clustering
     */
    private String cluster() {
	Node node = null;
	double cost;
	double mdlCost = 0.0;
	double newMdlCost = -1.0;

	long t = System.currentTimeMillis();
	this.gcc.state = State.CLUSTERING;

	System.err.print("Class labels are ");
	// set ids + class labels (ugly workaround)
	for (int i = 0; i < this.gcc.graphModel.size(); i++) {
	    Node n = this.gcc.graphModel.getNode(i);
	    n.setId(i);
	    n.setClassLabel(n.getLabel());
	    System.err.print(n.getLabel() + " ");
	}
	System.err.println();

	// initialize new clustering
	// clustering = new Clustering(graphModel, k);
	Graph debugGraph = new Graph(this.gcc.graphModel);
	try {
	    clusterer = new SplitMergeClusterer(this.gcc.graphModel);
	} catch (GraphSizeException e1) {
	    // Graph was too small (shouldn't really happen)
	    e1.printStackTrace();
	}

	// set matrix to 'all nodes black'
	clusterer.update(this.gcc.graphModel);
	assert this.gcc.graphModel.getNodes().containsAll(debugGraph.getNodes())
		&& debugGraph.getNodes().containsAll(this.gcc.graphModel.getNodes());
	if (this.gcc.isVerboseVisual) {
	    try {
		Thread.sleep(500);
	    } catch (InterruptedException e) {
		e.printStackTrace();
	    }
	}

	// run clustering
	while (Math.abs(mdlCost - newMdlCost) > GraphConsoleController.EPSILON) {
	    assert !(newMdlCost > mdlCost + GraphConsoleController.EPSILON) || mdlCost == -1.0
		    || newMdlCost == -1.0;
	    mdlCost = newMdlCost;

	    double mdlCostBeforeSplit = clusterer.getMdl();
	    System.err.println(">> Current MDL is " + clusterer.getMdl());
	    System.err.println("Splitting..");
	    clusterer.split();
	    double mdlCostAfterSplit = clusterer.getMdl();
	    assert !(mdlCostAfterSplit > mdlCostBeforeSplit + GraphConsoleController.EPSILON)
		    || mdlCost == -1.0 || newMdlCost == -1.0;
	    System.err.println(">> Current MDL is " + clusterer.getMdl());
	    System.err.println("Merging..");
	    double mdlCostBeforeMerge = clusterer.getMdl();
	    clusterer.merge();
	    double mdlCostAfterMerge = clusterer.getMdl();
	    assert !(mdlCostAfterMerge > mdlCostBeforeMerge + GraphConsoleController.EPSILON)
		    || mdlCost == -1.0 || newMdlCost == -1.0;

	    System.err.println(">> Current MDL is " + clusterer.getMdl());
	    System.err.println("Assigning..");

	    clusterer.createNodeProcessingOrder();
	    while ((node = clusterer.nextNode()) != null) {

		// System.err.println("Clustering. [Memory used: "
		// + (Runtime.getRuntime().totalMemory() / 1024 / 1024) + "m/"
		// + (Runtime.getRuntime().maxMemory() / 1024 / 1024) + "m]");

		// clustering.step(node);
		double mdlCostBeforeAssignment = clusterer.getMdl();
		assert this.gcc.graphModel.contains(node);
		clusterer.updateClustering(node);
		clusterer.update(this.gcc.graphModel);
		double mdlCostAfterAssignment = clusterer.getMdl();
		assert !(mdlCostAfterAssignment > mdlCostBeforeAssignment
			+ GraphConsoleController.EPSILON)
			|| mdlCost == -1.0 || newMdlCost == -1.0;

		// System.err.println(">> Current MDL is " +
		// clusterer.getMdl());
	    }

	    newMdlCost = clusterer.getMdl();
	}

	// set matrix to 'all nodes black' again
	clusterer.sort(this.gcc.graphModel);
	setNodeClusters();

	// show result info on view
	cost = clusterer.getMdl();
	this.gcc.graphTypes = clusterer.getGraphTypes();
	StringBuilder sb = new StringBuilder();
	sb.append(String.format("%nMDL = %.4f, ( ", cost));
	for (int i = 0; i < this.gcc.graphTypes.length; i++) {
	    sb.append(this.gcc.graphTypes[i].toString()).append(" : ")
		    .append(String.format("%.2f", clusterer.clustering.get(i).getMinMdl()))
		    .append(" , ");
	}
	sb.append(").\nTime used for clustering: ");
	sb.append(String.format("%.2f", (System.currentTimeMillis() - t) / 1000.0));
	sb.append(" s");
	sb.append(String.format("%nNMI = %.4f", clusterer.getNmi()));

	sb.append("\n--------- Structure Details: -----------------\n");
	sb.append(clusterer.clustering.toString());
	sb.append("\n----------------------------------------------\n");

	return sb.toString();
    }

    protected void setNodeClusters() {
	int[] clusterBegins = clusterer.getClusterBegins();

	int id = 0;
	for (int n = 0; n < this.gcc.graphModel.size(); n++) {
	    if ((id < clusterBegins.length - 1) && (n == clusterBegins[id + 1])) {
		id++;
	    }
	    this.gcc.graphModel.getNode(n).setLabel(id);
	}
    }
}