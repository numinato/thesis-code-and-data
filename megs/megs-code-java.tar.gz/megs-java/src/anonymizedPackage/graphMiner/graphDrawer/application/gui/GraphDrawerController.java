package anonymizedPackage.graphMiner.graphDrawer.application.gui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JFileChooser;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileNameExtensionFilter;

import anonymizedPackage.graphMiner.Main;
import anonymizedPackage.graphMiner.graphClusterer.ClusterMap;
import anonymizedPackage.graphMiner.graphClusterer.FixedKClusterer;
import anonymizedPackage.graphMiner.graphClusterer.Mdl;
import anonymizedPackage.graphMiner.graphClusterer.SplitMergeClusterer;
import anonymizedPackage.graphMiner.graphDrawer.accessories.GraphGenerator;
import anonymizedPackage.graphMiner.graphDrawer.accessories.JungGraphViewerAdapter;
import anonymizedPackage.graphMiner.graphDrawer.accessories.Tools;
import anonymizedPackage.graphMiner.graphDrawer.accessories.ViewState;
import anonymizedPackage.graphMiner.graphDrawer.model.Edge;
import anonymizedPackage.graphMiner.graphDrawer.model.Graph;
import anonymizedPackage.graphMiner.graphDrawer.model.GraphType;
import anonymizedPackage.graphMiner.graphDrawer.model.Node;
import anonymizedPackage.graphMiner.graphDrawer.presentation.GraphDrawerView;
import anonymizedPackage.graphMiner.graphDrawer.presentation.State;

/**
 * 
 * @version $Id: GraphDrawerController.java 1898 2014-08-12 13:59:32Z goebl $
 */
public class GraphDrawerController {

    static final double EPSILON = 1e-10;

    GraphDrawerView view;
    public Graph graphModel;

    GraphType[] graphTypes;
    State state;
    boolean done = false;

    private int currentClusterID;
    private Edge currentEdge;

    File lastLoadedFile;
    boolean isVerboseVisual;
    boolean isShowingSplitMerge;
    boolean doSaveBestNmiModel;
    boolean doResetBeforeClustering;
    boolean loadSparse;

    public int[] userValues;

    public GraphDrawerController() {
	graphModel = new Graph();
	view = new GraphDrawerView(graphModel.getNodes(), graphModel.getEdges());
	state = State.FIXED;
	view.setState(ViewState.NODES_PLAIN);
	view.setStatusLabels(null, null, "(Options: DIAGONALIZE_RUNS=" + Graph.DIAGONALIZE_MAX_RUNS
		+ ", BIPARTITENESS_RUNS=" + Mdl.BIPARTITENESS_RUNS + ")");

	graphTypes = null;
	currentEdge = null;
	lastLoadedFile = null;
	isVerboseVisual = false;
	isShowingSplitMerge = false;
	doSaveBestNmiModel = true;
	doResetBeforeClustering = true;
	loadSparse = true;

	userValues = Tools.parseInt(view.jtaInput.getText().split(","));

	addListener();
    }

    public void initView() {
	this.view.setVisible(true);
    }

    private void addListener() {
	view.setKeyListener(new GraphDrawerKeyListener());
	view.setInputMouseListener(new InputMouseListener());
	view.setGraphMouseListener(new GraphMouseListener());
	view.setGraphMotionListener(new GraphMouseMotionListener());
	view.setItemListener(new MenuItemListener());
	view.setActionListener(new MenuActionListener());
    }

    class GraphDrawerKeyListener implements KeyListener {
	boolean doRepaint;
	char keyChar;

	@Override
	public void keyPressed(KeyEvent keyEvent) {
	}

	@Override
	public void keyReleased(KeyEvent keyEvent) {
	};

	@Override
	public void keyTyped(KeyEvent keyEvent) {
	    keyChar = keyEvent.getKeyChar();
	    doRepaint = true;
	    switch (keyChar) {
	    case 'm':
		view.maximizeView();
		break;
	    case 'r': // create a random permutation
		      // randomize the node IDs
		graphModel.randomize();
		view.setNodes(graphModel.getNodes());
		break;
	    case 'R': // reset to last loaded graph if existing
		if (state == State.FIXED) {
		    resetGraph();
		}
		break;
	    case ' ': // print the adjacency matrix to the console window
		graphModel.printAdjacencyMatrix();
		break;
	    case 'd':
		if (state == State.DELETING) {
		    state = State.FIXED;
		    view.setState(ViewState.NODES_PLAIN);
		    view.setStatusLabels("Ready.", "", null);
		} else if (state == State.FIXED) {
		    state = State.DELETING;
		    view.setStatusLabels("Deleting...", "", null);
		    view.setState(ViewState.NODES_DENOTED_ALL);
		}
		break;
	    case 's':
		if (state == State.FIXED) {
		    saveModel();
		}
		break;
	    case 'l':
		if (state == State.FIXED) {
		    loadModel(null);
		    view.setNodes(graphModel.getNodes());
		    view.setEdges(graphModel.getEdges());
		    view.setGraphJPanelSize(graphModel.getDimension());
		}
		break;
	    case 'i': // increase size of graph presentation
		if (state == State.FIXED) {
		    graphModel.increaseDimension();
		    view.setGraphJPanelSize(graphModel.getDimension());
		    (new JungGraphViewerAdapter(graphModel)).visualize();
		}
		break;
	    case 'I': // decrease size of graph presentation
		if (state == State.FIXED) {
		    graphModel.decreaseDimension();
		    view.setGraphJPanelSize(graphModel.getDimension());
		    (new JungGraphViewerAdapter(graphModel)).visualize();
		}
		break;
	    // case 'p': // save to a png image with a file name equal to
	    // the current time
	    // Date n = new Date();
	    // leftJPanel.savePNG("adj-mat-" + Integer.toString(n.getDate())
	    // + "-"
	    // + Integer.toString(n.getHours()) + "-"
	    // + Integer.toString(n.getMinutes()) + "-"
	    // + Integer.toString(n.getSeconds()) + ".png");
	    // break;
	    case '+': // increase scaling by one step
		view.increaseScaling();
		Node.increaseShapeSize();
		for (Node node : graphModel.getNodes()) {
		    node.recalculateShape();
		}
		view.setNodes(graphModel.getNodes());
		break;
	    case '-': // decrease scaling by one step
		view.decreaseScaling();
		Node.decreaseShapeSize();
		for (Node node : graphModel.getNodes()) {
		    node.recalculateShape();
		}
		view.setNodes(graphModel.getNodes());
		break;
	    case '*': // toggle grid
		view.toggleGrid();
		break;
	    case 'c': // start clustering
		if (state == State.FIXED & graphModel.size() > 0) {
		    state = State.CLUSTERING;
		    view.setStatusLabels("Clustering...", "", null);
		    Clusterer clusterer = new Clusterer(GraphDrawerController.this);
		    (new Thread(clusterer)).start();
		    doRepaint = false;
		}
		break;
	    case 'a': // leave coloring mode
		if (state == State.COLORING) {
		    state = State.FIXED;
		    view.setState(ViewState.NODES_PLAIN);
		    view.setStatusLabels("Ready.", "", null);
		}
		break;
	    case 'g': // generate new running example graph with #userValue
		      // nodes
		if (state == State.FIXED) {
		    double errorRate;
		    int numberNodes;
		    view.setStatusLabels("Generating..", "", null);
		    view.repaint();
		    numberNodes = userValues[0];
		    errorRate = 0.0;
		    if (userValues.length > 1) {
			errorRate = userValues[1] / 1000.0;
		    }
		    GraphGenerator generator = new GraphGenerator(numberNodes, errorRate);
		    graphModel = generator.getGraph();
		    view.setNodes(graphModel.getNodes());
		    view.setEdges(graphModel.getEdges());
		    view.setGraphJPanelSize(graphModel.getDimension());
		    String percent = String.format("%.2f",
			    ((double) generator.getNumberErrorEdges())
				    / graphModel.getEdges().size());
		    view.setStatusLabels("Generated.", userValues[0] + " n (" + errorRate + ",#"
			    + generator.getNumberErrorEdges() + "/" + graphModel.getEdges().size()
			    + ":" + percent + "), " + graphModel.getEdges().size() + " edges).["
			    + (Runtime.getRuntime().totalMemory() / 1024 / 1024) + "m/"
			    + (Runtime.getRuntime().maxMemory() / 1024 / 1024) + "m used]", null);
		}
		break;
	    case 'v':
		(new JungGraphViewerAdapter(graphModel)).visualize();
		break;
	    case 'Q': // delete all graph information and initialize new graph
		if (state == State.FIXED) {
		    graphModel = new Graph();
		    view.setNodes(graphModel.getNodes());
		    view.setEdges(graphModel.getEdges());
		    lastLoadedFile = null;
		    view.setStatusLabels("Ready.", "New graph initialized.", null);
		}
		break;
	    default:
		int i = (int) keyChar - 48;
		if (i >= 0 && i <= 5 && (state == State.FIXED || state == State.COLORING)) {
		    currentClusterID = i;
		    state = State.COLORING;
		    view.setStatusLabels("Coloring Mode.", "(a)bort", null);
		}
		break;
	    }
	    if (doRepaint) {
		updateAdjacencyMatrix();
		view.repaint();
	    }
	}
    }

    class InputMouseListener implements MouseListener {

	@Override
	public void mouseReleased(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	    view.jtaInput.setEnabled(false);
	    view.jtaInput.setEditable(false);
	    userValues = Tools.parseInt(view.jtaInput.getText().split(","));
	    view.requestFocusInWindow();
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	    view.jtaInput.setEnabled(true);
	    view.jtaInput.setEditable(true);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}

    }

    class MenuItemListener implements ItemListener {

	@Override
	public void itemStateChanged(ItemEvent e) {
	    if (e.getItemSelectable() == view.getMenuItem1()) {
		if (e.getStateChange() == ItemEvent.SELECTED) {
		    isVerboseVisual = true;
		} else {
		    isVerboseVisual = false;
		}
	    } else if (e.getItemSelectable() == view.getMenuItem3()) {
		if (e.getStateChange() == ItemEvent.SELECTED) {
		    isShowingSplitMerge = true;
		} else {
		    isShowingSplitMerge = false;
		}
	    } else if (e.getItemSelectable() == view.getMenuItem4()) {
		if (e.getStateChange() == ItemEvent.SELECTED) {
		    doResetBeforeClustering = true;
		} else {
		    doResetBeforeClustering = false;
		}
	    } else if (e.getItemSelectable() == view.getMenuItem5()) {
		if (e.getStateChange() == ItemEvent.SELECTED) {
		    doSaveBestNmiModel = true;
		} else {
		    doSaveBestNmiModel = false;
		}
	    } else if (e.getItemSelectable() == view.getMenuItem6()) {
		if (e.getStateChange() == ItemEvent.SELECTED) {
		    loadSparse = true;
		    SplitMergeClusterer.hasSparse = true;
		} else {
		    loadSparse = false;
		    SplitMergeClusterer.hasSparse = false;
		}
	    }
	}
    }

    class MenuActionListener implements ActionListener {
	@Override
	public void actionPerformed(ActionEvent e) {
	    if (e.getSource() == view.getMenuItem2()) {
		view.maximizeView();
	    }
	}
    }

    private void saveModel() {
	JFileChooser fc = new JFileChooser(System.getProperty("user.dir") + "/..");
	FileNameExtensionFilter filter = new FileNameExtensionFilter("Graph Drawer files", "grd",
		"gml", "out", "tkz", "cxp", "mat", "mts");
	File file = null;
	fc.setFileFilter(filter);

	int returnValue = fc.showSaveDialog(view);

	if (returnValue == JFileChooser.APPROVE_OPTION) {
	    String extension;

	    file = fc.getSelectedFile();
	    extension = file.toString().substring(file.toString().length() - 3,
		    file.toString().length());
	    graphModel.save(file, extension);
	}
    }

    void saveBestModel() {
	if (lastLoadedFile != null) {
	    String filename = lastLoadedFile.getName().substring(0,
		    lastLoadedFile.getName().toString().length() - 4)
		    + "_bestMdl.mat";
	    graphModel.save(new File(lastLoadedFile.getParentFile(), filename), "mat");
	}
    }

    private void loadModel(File file) {
	int returnValue = JFileChooser.APPROVE_OPTION;

	if (file == null) {
	    JFileChooser fc = new JFileChooser(System.getProperty("user.dir") + "/..");
	    FileNameExtensionFilter filter = new FileNameExtensionFilter("Graph Drawer files",
		    "grd", "edges", "gml", "adl");
	    fc.setFileFilter(filter);

	    returnValue = fc.showOpenDialog(view);
	    file = fc.getSelectedFile();
	}

	if (returnValue == JFileChooser.APPROVE_OPTION) {
	    this.graphModel = new Graph(file, loadSparse);

	}
	lastLoadedFile = file;
    }

    public void setCurrentClusterID(int currentClusterID) {
	this.currentClusterID = currentClusterID;
    }

    class GraphMouseListener implements MouseListener {
	public void mouseClicked(MouseEvent e) {
	    if (SwingUtilities.isRightMouseButton(e)) {
		switch (state) {
		case FIXED:
		case PRE_MOVING_PERMUTING:
		    if (setCurrentNode(e)) {
			state = State.PERMUTING;
			view.setState(ViewState.PERMUTING);
		    }
		    break;
		case PERMUTING:
		    Node oldCurrentNode = view.getCurrentNode();
		    if (setCurrentNode(e) && view.getCurrentNode() != oldCurrentNode) {
			graphModel.swapNodes(oldCurrentNode, view.getCurrentNode());
		    }
		    view.setCurrentNode(null);
		    state = State.FIXED;
		    view.setState(ViewState.NODES_PLAIN);
		    break;
		}
	    } else if (SwingUtilities.isLeftMouseButton(e)) {
		switch (state) {
		case DELETING:
		    if (setCurrentNode(e)) {
			@SuppressWarnings("unchecked")
			ArrayList<Edge> edgesCopy = new ArrayList<Edge>(graphModel.getEdges());
			for (Edge edge : edgesCopy) {
			    if (edge.containsAsNode(view.getCurrentNode())) {
				graphModel.getEdges().remove(edge);
			    }
			}
			graphModel.getNodes().remove(view.getCurrentNode());
			for (Node node : view.getCurrentNode().getNeighbors()) {
			    node.removeNeighbor(view.getCurrentNode());
			}
			view.setCurrentNode(null);
		    } else if (setCurrentEdge(e)) {
			currentEdge.getNode1().removeNeighbor(currentEdge.getNode2());
			currentEdge.getNode2().removeNeighbor(currentEdge.getNode1());
			graphModel.getEdges().remove(currentEdge);
			currentEdge = null;
		    }
		    break;
		case COLORING:
		    if (setCurrentNode(e)) {
			view.getCurrentNode().setLabel(currentClusterID);
			view.setCurrentNode(null);
		    }
		    break;
		}
	    }
	    updateAdjacencyMatrix();
	    view.repaint();
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
	    if (SwingUtilities.isLeftMouseButton(e)) {
		switch (state) {
		case FIXED:
		    if (setCurrentNode(e)) {
			state = State.SELECTED;
			view.setCurrentMousePoint(e.getPoint());
			view.setState(ViewState.SELECTED);
		    } else {
			graphModel.getNodes().add(new Node(e.getX(), e.getY()));
		    }
		    break;
		case SELECTED:
		    Node oldCurrentNode = view.getCurrentNode();
		    Node currNode = null;
		    if (setCurrentNode(e)) {
			if (!(currNode = view.getCurrentNode()).equals(oldCurrentNode)) {
			    oldCurrentNode.addNeighbor(currNode);
			    currNode.addNeighbor(oldCurrentNode);
			    graphModel.getEdges().add(new Edge(currNode, oldCurrentNode));
			}
			state = State.FIXED;
			view.setState(ViewState.NODES_PLAIN);
			view.setCurrentNode(null);
			view.setCurrentMousePoint(null);
		    } else {
			view.setCurrentNode(oldCurrentNode);
		    }
		    break;
		}
	    } else if (SwingUtilities.isRightMouseButton(e)) {
		switch (state) {
		case FIXED:
		    if (setCurrentNode(e)) {
			state = State.PRE_MOVING_PERMUTING;
			view.setState(ViewState.PRE_MOVING);
			break;
		    }
		}
	    }
	    updateAdjacencyMatrix();
	    view.repaint();
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	    switch (state) {
	    case SELECTED:
		Node oldCurrentNode = view.getCurrentNode();
		Node currNode = null;
		if (setCurrentNode(e)) {
		    if (!(currNode = view.getCurrentNode()).equals(oldCurrentNode)) {
			currNode.addNeighbor(oldCurrentNode);
			oldCurrentNode.addNeighbor(currNode);
			graphModel.getEdges().add(new Edge(currNode, oldCurrentNode));
			state = State.FIXED;
			view.setState(ViewState.NODES_PLAIN);
			view.setCurrentNode(null);
			break;
		    }
		}
		view.setCurrentNode(oldCurrentNode);
		view.repaint();
		break;
	    case MOVING:
		state = State.FIXED;
		view.setState(ViewState.NODES_PLAIN);
		view.setCurrentNode(null);
		break;
	    }
	    updateAdjacencyMatrix();
	    view.repaint();
	}
    }

    class GraphMouseMotionListener implements MouseMotionListener {
	@Override
	public void mouseMoved(MouseEvent e) {
	    switch (state) {
	    case SELECTED:
		view.setCurrentMousePoint(e.getPoint());
		view.repaint();
		break;
	    }
	}

	@Override
	public void mouseDragged(MouseEvent e) {
	    if (SwingUtilities.isLeftMouseButton(e)) {
		switch (state) {
		case SELECTED:
		    view.setCurrentMousePoint(e.getPoint());
		    break;
		}
	    } else if (SwingUtilities.isRightMouseButton(e)) {
		switch (state) {
		case PRE_MOVING_PERMUTING:
		    state = State.MOVING;
		    view.setState(ViewState.MOVING);
		case MOVING:
		    view.setCurrentMousePoint(e.getPoint());
		    view.getCurrentNode().setX(view.getCurrentMousePoint().x);
		    view.getCurrentNode().setY(view.getCurrentMousePoint().y);
		    view.getCurrentNode().recalculateShape();
		    break;
		}
	    }
	    updateAdjacencyMatrix();
	    view.repaint();
	}
    }

    private boolean setCurrentNode(MouseEvent e) {
	for (Node node : graphModel.getNodes()) {
	    if (node.contains(e.getPoint())) {
		view.setCurrentNode(node);
		return true;
	    }
	}
	view.setCurrentNode(null);
	return false;
    }

    private boolean setCurrentEdge(MouseEvent e) {
	for (Edge edge : graphModel.getEdges()) {
	    if (edge.contains(e.getPoint(), 4.0)) {
		currentEdge = edge;
		return true;
	    }
	}
	return false;
    }

    public void updateAdjacencyMatrix() {
	updateAdjacencyMatrix(-1, -1);
    }

    public void updateAdjacencyMatrix(int node1IdHighlighted, int node2IdHighlighted) {
	if (graphModel.size() < 10000) {
	    Color[] colors = new Color[graphModel.getNodes().size()];
	    for (int i = 0; i < colors.length; i++) {
		colors[i] = graphModel.getNodes().get(i).getColor();
	    }

	    int[] clusterIds = new int[graphModel.getNodes().size()];
	    for (int i = 0; i < clusterIds.length; i++) {
		clusterIds[i] = graphModel.getNodes().get(i).getLabel();
	    }

	    view.updateData(graphModel.getAdjacencyMatrix(), colors, node1IdHighlighted,
		    node2IdHighlighted, clusterIds);
	} else {
	    view.showAdjacencyDummy();
	}

    }

    void resetGraph() {
	if (lastLoadedFile != null) {
	    loadModel(lastLoadedFile);
	    view.setNodes(graphModel.getNodes());
	    view.setEdges(graphModel.getEdges());
	    view.setGraphJPanelSize(graphModel.getDimension());
	}
    }
}
