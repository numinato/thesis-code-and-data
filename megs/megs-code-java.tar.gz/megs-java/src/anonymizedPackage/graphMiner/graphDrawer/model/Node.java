package anonymizedPackage.graphMiner.graphDrawer.model;

import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.io.Serializable;
import java.util.ArrayList;

/**
 * 
 * @version $Id: Node.java 1742 2014-06-27 14:32:35Z goebl $
 */
public class Node implements Serializable {

    private static final long serialVersionUID = -5425498251500557651L;

    private static int shapeSize = 20;
    private int id;
    private int label;
    private int classLabel;
    public int origId;
    private int x;
    private int y;
    private Shape shape;
    private ArrayList<Node> neighbors = new ArrayList<Node>();
    private Color[] clusterColors = new Color[] { Color.BLACK, Color.BLUE, Color.CYAN,
	    Color.MAGENTA, Color.ORANGE, Color.PINK, Color.DARK_GRAY, Color.YELLOW,
	    Color.LIGHT_GRAY, Color.RED, Color.GRAY, Color.BLACK, Color.BLUE, Color.CYAN,
	    Color.MAGENTA, Color.ORANGE, Color.PINK, Color.DARK_GRAY, Color.YELLOW,
	    Color.LIGHT_GRAY, Color.RED, Color.GRAY };

    public Node() {
	this(100,100);
    }
    
    public Node(int label) {
	this(100, 1000, label);
    }

    public Node(int x, int y, int label) {
	this.x = x;
	this.y = y;
	this.label = label;
	this.shape = new Ellipse2D.Float(x - shapeSize / 2, y - shapeSize / 2, shapeSize, shapeSize);
    }

    public Node(int x, int y) {
	this(x, y, 0);
    }

    public static void increaseShapeSize() {
	if (shapeSize <= 40) {
	    shapeSize++;
	}
    }

    public static void decreaseShapeSize() {
	if (shapeSize >= 10) {
	    shapeSize--;
	}
    }

    public static int getShapeSize() {
	return shapeSize;
    }

    public ArrayList<Node> getNeighbors() {
	return neighbors;
    }

    public int getLabel() {
	return label;
    }

    public int getX() {
	return x;
    }

    public int getY() {
	return y;
    }

    public Shape getShape() {
	return shape;
    }

    public Color getColor() {
//	return Color.BLACK;
	return clusterColors[label];
    }

    public void setLabel(int label) {
	this.label = label;
    }

    public void setX(int x) {
	this.x = x;
    }

    public void setY(int y) {
	this.y = y;
    }

    public void recalculateShape() {
	this.shape = new Ellipse2D.Float(x - shapeSize / 2, y - shapeSize / 2, shapeSize, shapeSize);
    }

    public boolean contains(Point point) {
	return shape.contains(point);
    }

    public void removeNeighbor(Node node) {
	neighbors.remove(node);
    }

    public void addNeighbor(Node node) {
	neighbors.add(node);
    }

    public int getDegree() {
	return neighbors.size();
    }

    public String toString() {
	return Integer.toString(id);
    }

    public int getId() {
	return id;
    }

    public void setId(int id) {
	this.id = id;
    }

    public int getClassLabel() {
        return classLabel;
    }

    public void setClassLabel(int classLabel) {
        this.classLabel = classLabel;
    }
}
