package anonymizedPackage.graphMiner.graphDrawer.model;

/**
* 
* @version $Id: GraphType.java 1743 2014-06-27 14:36:51Z goebl $
*/
public enum GraphType {
	CLIQUE, TREE, HUB, BIPARTITE, SPARSE //, PATH
}