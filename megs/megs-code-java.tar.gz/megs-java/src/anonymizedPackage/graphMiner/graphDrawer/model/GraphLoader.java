package anonymizedPackage.graphMiner.graphDrawer.model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import anonymizedPackage.graphMiner.graphDrawer.accessories.GMLReader;

public class GraphLoader {
    private ArrayList<Node> nodes;
    private ArrayList<Edge> edges;

    public GraphLoader(File file, boolean loadSparse) {
	BufferedReader br;

	nodes = new ArrayList<Node>();
	edges = new ArrayList<Edge>();
	br = null;

	try {
	    br = new BufferedReader(new FileReader(file));
	    String fileExtension = file.getName().substring(file.getName().length() - 3,
		    file.getName().length());

	    switch (fileExtension) {
	    case "gml":
		loadGml(br);
		break;
	    case "grd":
		loadGrd(br);
		break;
	    default:
		loadDefault(br);
	    }

	} catch (IOException e) {
	    e.printStackTrace();
	} finally {
	    try {
		br.close();
	    } catch (IOException e) {
		e.printStackTrace();
	    }
	}

	// remove duplicates from nodes and edges ArrayLists
	Set<Node> nodeSet = new LinkedHashSet<Node>(nodes);
	nodes = new ArrayList<Node>();
	for (Node node : nodeSet) {
	    nodes.add(node);
	}

	Set<Edge> edgeSet = new HashSet<Edge>(edges);
	edges = new ArrayList<Edge>();
	for (Edge edge : edgeSet) {
	    edges.add(edge);
	}

	// add neighbors to nodes
	for (Edge edge : getEdges()) {
	    edge.getNode1().addNeighbor(edge.getNode2());
	    edge.getNode2().addNeighbor(edge.getNode1());
	}

	if (!loadSparse) {
	    for (Iterator<Node> iter = nodes.iterator(); iter.hasNext();) {
		Node n = iter.next();
		if (n.getNeighbors().size() == 0) {
		    System.err.println("Sparse node: " + n.getId());
		    iter.remove();
		}
	    }
	}

    }

    private void loadDefault(BufferedReader br) throws IOException {
	String line;
	Pattern p = Pattern.compile("\\s*(\\d+)[\\s\\t:;,]+(\\d+)(?:[\\s\\t:;,]+\\d+)?\\s*");
	Matcher m;
	HashMap<Integer, Node> nodeMap = new HashMap<Integer, Node>();
	while ((line = br.readLine()) != null) {
	    m = p.matcher(line);
	    if (m.matches()) {
		System.err.println(m.group(0));
		System.err.println(">> '" + m.group(1) + "' -- '" + m.group(2) + "'");

		int nodeId1 = Integer.parseInt(m.group(1));
		int nodeId2 = Integer.parseInt(m.group(2));

		Node node1;
		Node node2;

		// if nodes don't exist, create them
		if (nodeMap.containsKey(nodeId1)) {
		    node1 = nodeMap.get(nodeId1);
		} else {
		    node1 = new Node();
		    nodeMap.put(nodeId1, node1);
		}
		if (nodeMap.containsKey(nodeId2)) {
		    node2 = nodeMap.get(nodeId2);
		} else {
		    node2 = new Node();
		    nodeMap.put(nodeId2, node2);
		}
		if (nodeId1 != nodeId2) {
		    edges.add(new Edge(node1, node2));
		}

	    } else if (!line.startsWith("#")) {
		throw new IllegalArgumentException("Line \"" + line + "\" could not be read!");
	    }
	}

	ArrayList<Integer> sortedNodeIds = new ArrayList<Integer>(nodeMap.keySet());
	Collections.sort(sortedNodeIds);

	for (Integer i : sortedNodeIds) {
	    nodes.add(nodeMap.get(i));
	}
    }

    private void loadGrd(BufferedReader br) throws IOException {
	HashMap<Integer, Node> nodeMap;
	String line;
	String[] splitString;
	
	nodeMap = new HashMap<Integer, Node>();
	line = br.readLine();
	
	if (!line.startsWith("#nodes")) {
	    throw new RuntimeException("Illegal File Format: '#nodes' expected");
	}

	// First: Read nodes
	while (!(line = br.readLine()).equals("#edges")) {
	    Node node;
	    int nodeId, xCoord, yCoord, label;

	    splitString = line.split(";");
	    nodeId = Integer.parseInt(splitString[0]);

	    if (splitString.length == 2) {
		label = Integer.parseInt(splitString[1]);
		node = new Node(label);
		node.origId = nodeId;
	    } else {
		xCoord = Integer.parseInt(splitString[1]);
		yCoord = Integer.parseInt(splitString[2]);
		label = Integer.parseInt(splitString[3]);
		node = new Node(xCoord, yCoord, label);
		node.origId = nodeId;
	    }

	    if (nodeMap.containsKey(nodeId)) {
		throw new RuntimeException("Error: Same node ID used at least twice!");
	    }

	    nodeMap.put(nodeId, node);
	}

	// Second: Read edges
	while ((line = br.readLine()) != null) {
	    splitString = line.split(";");
	    int nodeId1 = Integer.parseInt(splitString[0]);
	    int nodeId2 = Integer.parseInt(splitString[1]);
	    if (nodeId1 != nodeId2) {
		getEdges().add(new Edge(nodeMap.get(nodeId1), nodeMap.get(nodeId2)));
	    }
	}

	ArrayList<Integer> sortedNodeIds = new ArrayList<Integer>(nodeMap.keySet());
	Collections.sort(sortedNodeIds);

	for (Integer i : sortedNodeIds) {
	    nodes.add(nodeMap.get(i));
	}

    }

    private void loadGml(BufferedReader br) throws IOException {
	GMLReader gmlr;
	gmlr = new GMLReader(br);
	nodes = new ArrayList<Node>(gmlr.getNodes());
	edges = new ArrayList<Edge>(gmlr.getEdges());
    }

    public ArrayList<Node> getNodes() {
	return nodes;
    }

    public ArrayList<Edge> getEdges() {
	return edges;
    }

}
