package anonymizedPackage.graphMiner.graphDrawer.model;

import java.awt.Dimension;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeMap;

import com.jmatio.io.MatFileWriter;
import com.jmatio.types.MLArray;
import com.jmatio.types.MLDouble;

/**
 * 
 * @version $Id: Graph.java 2042 2014-10-17 15:40:15Z goebl $
 */
public class Graph {

    public static final int DIAGONALIZE_MAX_RUNS = 30;
    private ArrayList<Edge> edges;
    ArrayList<Node> nodes;
    public int[] clusterBegins;
    private Dimension dimension;

    public Graph() {
	nodes = new ArrayList<Node>();
	edges = new ArrayList<Edge>();
	dimension = new Dimension(600, 900);
    }

    public Graph(List<Node> nodes, List<Edge> edges) {
	this.nodes = new ArrayList<Node>(nodes);
	this.edges = new ArrayList<Edge>(edges);
    }

    public Graph(List<Node> nodes) {
	this.nodes = new ArrayList<Node>(nodes);
	this.edges = null;
    }

    public Graph(Collection<Node> nodes) {
	this.nodes = new ArrayList<Node>(nodes);
	this.edges = null;
    }

    public Graph(Graph graph) {
	this.nodes = new ArrayList<Node>(graph.getNodes());
	if (graph.getEdges() == null) {
	    this.edges = null;
	} else {
	    this.edges = new ArrayList<Edge>(graph.getEdges());
	}
    }

    public Graph(File file, boolean loadSparse) {
	this();
	GraphLoader gl = new GraphLoader(file, loadSparse);
	nodes = gl.getNodes();
	edges = gl.getEdges();

	System.err.printf("Graph loaded: %d nodes, %d edges.%n", nodes.size(), edges.size());
    }

    public Graph(int size) {
	this(new ArrayList<Node>(size));
    }

    public int[] getClusterPositions() {
	ArrayList<Integer> ial = new ArrayList<Integer>();
	int v = -1;
	for (Node node : nodes) {
	    if (node.getLabel() != v) {
		v = node.getLabel();
		ial.add(nodes.indexOf(node));
	    }
	}

	int[] result = new int[ial.size()];
	for (int i = 0; i < result.length; i++) {
	    result[i] = ial.get(i);
	    // System.err.println(result[i]);
	}
	return result;
    }

    public int diagonalize(boolean positiveWeight, boolean isSwapping) {
	int firstNodeID = 0;
	int lastNodeID = nodes.size() - 1;
	return diagonalize(firstNodeID, lastNodeID, positiveWeight, isSwapping);
    }

    public int diagonalize(boolean positiveWeight) {
	return diagonalize(positiveWeight, true);
    }

    public int diagonalize(int firstNodeID, int lastNodeID, boolean isPositiveWeight,
	    boolean isSwapping) {
	int costFinal = Integer.MAX_VALUE;
	int costActual = 0;
	ArrayList<Node> nodesFinal = null;

	for (int run = 0; run < DIAGONALIZE_MAX_RUNS; run++) {
	    boolean changed = true;
	    int costOld = 0;
	    int costNew = 0;

	    randomize(firstNodeID, lastNodeID);

	    while (changed) {

		changed = false;
		for (int i = firstNodeID; i < lastNodeID; i++) {
		    for (int j = firstNodeID; j <= lastNodeID; j++) {
			if (i != j) {
			    costOld = diagCalcCosts(firstNodeID, lastNodeID, isPositiveWeight);
			    if (isSwapping) {
				swapNodes(i, j);
			    } else {
				moveNode(i, j);
			    }
			    costNew = diagCalcCosts(firstNodeID, lastNodeID, isPositiveWeight);
			    // System.err.println("cost_old = " + costOld +
			    // " | cost_new = " + costNew);
			    if (costNew < costOld) {
				// costs are lower: keep swap/move
				changed = true;
			    } else {
				// costs show no improvement: redo swap/move
				if (isSwapping) {
				    swapNodes(i, j);
				} else {
				    moveNode(j, i);
				}
			    }

			}
		    }
		}
	    }
	    costActual = diagCalcCosts(firstNodeID, lastNodeID, isPositiveWeight);
	    if (costActual < costFinal) {
		costFinal = costActual;
		nodesFinal = new ArrayList<Node>(nodes);
	    }
	}

	nodes = nodesFinal;
	return diagCalcCosts(firstNodeID, lastNodeID, isPositiveWeight);
    }

    public int diagonalize(int firstNodeID, int lastNodeID, boolean isPositiveWeight) {
	return diagonalize(firstNodeID, lastNodeID, isPositiveWeight, true);
    }

    private int diagCalcCosts(int firstNodeID, int lastNodeID, boolean isPositiveWeight) {
	int weight = 0;
	int cost = 0;
	int[][] adjMat = getAdjacencyMatrix();

	for (int row = firstNodeID; row < lastNodeID; row++) {
	    weight = isPositiveWeight ? 1 : -1;
	    for (int col = (row + 1); col <= lastNodeID; col++) {
		cost = cost + weight * adjMat[row][col];
		weight = isPositiveWeight ? weight + 1 : weight - 1;
	    }
	}
	return cost;
    }

    public void randomize() {
	ArrayList<Node> newNodes = new ArrayList<Node>();
	TreeMap<Integer, ArrayList<Node>> tm = new TreeMap<Integer, ArrayList<Node>>();

	for (Node node : nodes) {
	    int label = node.getLabel();
	    if (tm.containsKey(label)) {
		tm.get(label).add(node);
	    } else {
		ArrayList<Node> al = new ArrayList<Node>();
		al.add(node);
		tm.put(label, al);
	    }
	}

	ArrayList<Integer> labels = new ArrayList<Integer>(tm.keySet());
	while (!nodes.isEmpty()) {
	    Collections.shuffle(labels);
	    int label = labels.get(0);
	    if (tm.get(label).isEmpty()) {
		tm.remove(label);
		labels.remove(new Integer(label));
	    } else {
		Node node = tm.get(label).remove(0);
		newNodes.add(node);
		nodes.remove(node);
	    }
	}
	nodes = newNodes;
    }

    /**
     * Randomizes all nodes, creating a different looking adjacency matrix.
     */
    public void randomizeRandom() {
	int firstNodeID = 0;
	int lastNodeID = nodes.size() - 1;
	randomize(firstNodeID, lastNodeID);
    }

    /**
     * Randomizes nodes of specified subgraph.
     */
    public void randomize(int firstNodeID, int lastNodeID) { // TODO
	Collections.shuffle(nodes.subList(firstNodeID, lastNodeID + 1));
    }

    /**
     * Creates adjacency matrix representation.
     * 
     * @return adjacency matrix
     */
    public int[][] getAdjacencyMatrix() {
	int[][] adjacencyMatrix = new int[nodes.size()][nodes.size()];
	int index;
	for (Node node : nodes) {
	    for (Node neighboringNode : node.getNeighbors()) {
		index = nodes.indexOf(neighboringNode);
		if (index >= 0) {
		    adjacencyMatrix[nodes.indexOf(node)][index] = 1;
		}
	    }
	}
	return adjacencyMatrix;
    }

    public String getAdjacencyMatrixString() {
	StringBuffer sb = new StringBuffer();
	sb.append("--- Adjacency Matrix ---\n");

	// ids
	for (Node node : nodes) {
	    sb.append(node.getId()).append(" ");
	}
	//
	sb.append(System.lineSeparator());
	sb.append(System.lineSeparator());

	for (int[] B : getAdjacencyMatrix()) {
	    for (int i : B) {
		sb.append(i).append(" ");
	    }
	    sb.append(System.lineSeparator());
	}
	return sb.toString();
    }

    /**
     * Prints adjacency matrix to System.out.
     */
    public void printAdjacencyMatrix() {
	System.err.println(getAdjacencyMatrixString());
    }

    /**
     * Writes nodes and edges of graph to given file.
     * 
     * @param file
     *            save file for graph
     * @param extension
     *            file extension
     */
    public void save(File file, String extension) {
	if (extension.equalsIgnoreCase("out")) {
	    saveAsOut(file);
	} else if (extension.equalsIgnoreCase("tkz")) {
	    saveAsTkz(file);
	} else if (extension.equalsIgnoreCase("grd")) {
	    saveAsGrd(file);
	} else if (extension.equalsIgnoreCase("mat")) {
	    saveAsMatlab(file);
	} else if (extension.equalsIgnoreCase("cxp")) {
	    saveAsCxprime(file);
	} else if (extension.equalsIgnoreCase("mts")) {
	    saveAsMetis(file);
	} else if (extension.equalsIgnoreCase("grx")) {
	    saveAsGrx(file);
	} else {
	    file = new File(file.toString() + ".grd");
	    saveAsGrd(file);
	}
    }

    private void saveAsMetis(File file) {
	PrintWriter outMetis;
	PrintWriter outLabel;
	File metisFile;
	File labelFile;

	String filePrefix = file.getName().substring(0, file.getName().length() - 4);

	metisFile = new File(file.getParentFile(), filePrefix + ".metis");
	labelFile = new File(file.getParentFile(), filePrefix + ".label");

	try {
	    outMetis = new PrintWriter(new BufferedWriter(new FileWriter(metisFile)));
	    outLabel = new PrintWriter(new BufferedWriter(new FileWriter(labelFile)));

	    outMetis.println(nodes.size() + " " + edges.size());

	    for (Node node : nodes) {
		StringBuffer line = new StringBuffer();
		for (Node neighbor : node.getNeighbors()) {
		    line.append((nodes.indexOf(neighbor) + 1) + " ");
		}
		outMetis.println(line.toString().trim());
		outLabel.println(node.getLabel());
	    }
	    outMetis.flush();
	    outMetis.close();
	    outLabel.flush();
	    outLabel.close();

	} catch (IOException e) {
	    e.printStackTrace();
	}
    }

    private void saveAsCxprime(File file) {
	PrintWriter out;
	PrintWriter outLabel;
	File nameFile;
	File networkFile;
	File labelFile;

	String filePrefix = file.getName().substring(0, file.getName().length() - 4);

	nameFile = new File(file.getParentFile(), filePrefix + "_name.txt");
	networkFile = new File(file.getParentFile(), filePrefix + "_network.txt");
	labelFile = new File(file.getParentFile(), filePrefix + "_labels.txt");

	try {
	    out = new PrintWriter(new BufferedWriter(new FileWriter(nameFile)));
	    outLabel = new PrintWriter(new BufferedWriter(new FileWriter(labelFile)));
	    for (Node node : nodes) {
		out.printf("%d \"%d\"%n", nodes.indexOf(node) + 1, nodes.indexOf(node) + 1);
		outLabel.println(node.getLabel());
	    }
	    out.flush();
	    out.close();
	    outLabel.flush();
	    outLabel.close();

	    out = new PrintWriter(new BufferedWriter(new FileWriter(networkFile)));
	    for (Edge edge : getEdges()) {
		out.printf("%d %d%n", nodes.indexOf(edge.getNode1()) + 1,
			nodes.indexOf(edge.getNode2()) + 1);
	    }
	    out.flush();
	    out.close();

	} catch (IOException e) {
	    e.printStackTrace();
	}
    }

    private void saveAsTkz(File file) {
	// hacked down version only
	try {
	    PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(file)));
	    StringBuffer connectingNodesSb = new StringBuffer();

	    int maxClusterId = 0;
	    for (Node node : nodes) {
		if (node.getLabel() > maxClusterId) {
		    maxClusterId = node.getLabel();
		}
	    }

	    StringBuffer[] subgraphsSb = new StringBuffer[maxClusterId + 1];
	    for (int i = 0; i < subgraphsSb.length; i++) {
		subgraphsSb[i] = new StringBuffer();
	    }

	    for (Edge edge : getEdges()) {
		int clusterIdNode1 = edge.getNode1().getLabel();
		int clusterIdNode2 = edge.getNode2().getLabel();
		int nodeId1 = nodes.indexOf(edge.getNode1());
		int nodeId2 = nodes.indexOf(edge.getNode2());
		if (clusterIdNode1 == clusterIdNode2) {
		    subgraphsSb[clusterIdNode1].append("\t\t").append(nodeId1).append(" -- ")
			    .append(nodeId2).append(";").append(System.lineSeparator());
		} else {
		    connectingNodesSb.append("\t\t").append(nodeId1).append(" -- ").append(nodeId2)
			    .append(";").append(System.lineSeparator());
		}

	    }
	    out.println("\\tikz \\graph [layout] {");
	    for (int cId = 0; cId < subgraphsSb.length; cId++) {
		out.println("\t// [layout" + cId + "] {");
		out.println(subgraphsSb[cId].toString());
		out.println("\t};");
	    }
	    out.println(connectingNodesSb.toString());
	    out.println("};");
	    out.flush();
	    out.close();
	} catch (IOException e) {
	    e.printStackTrace();
	}

    }

    private void saveAsOut(File file) {
	try {
	    PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(file)));
	    for (Edge edge : getEdges()) {
		out.printf("%d,%d,1%n", nodes.indexOf(edge.getNode1()) + 1,
			nodes.indexOf(edge.getNode2()) + 1);
	    }
	    out.flush();
	    out.close();
	} catch (IOException e) {
	    e.printStackTrace();
	}

    }

    private void saveAsMatlab(File file) {

	double[] labels = new double[nodes.size()];
	for (int i = 0; i < nodes.size(); i++) {
	    labels[i] = nodes.get(i).getLabel() + 1.0;
	}

	double[][] edgesArray = new double[edges.size() * 2][2];
	for (int i = 0; i < edges.size(); i++) {
	    edgesArray[i][0] = nodes.indexOf(edges.get(i).getNode1()) + 1.0;
	    edgesArray[i][1] = nodes.indexOf(edges.get(i).getNode2()) + 1.0;
	    edgesArray[i + edges.size()][0] = nodes.indexOf(edges.get(i).getNode2()) + 1.0;
	    edgesArray[i + edges.size()][1] = nodes.indexOf(edges.get(i).getNode1()) + 1.0;
	}

	MLDouble mlDoubleEdges = new MLDouble("edges", edgesArray);
	MLDouble mlDoubleLables = new MLDouble("labels", labels, 1);

	Collection<MLArray> list = new ArrayList<MLArray>();
	list.add(mlDoubleEdges);
	list.add(mlDoubleLables);

	try {
	    new MatFileWriter(file, list);
	} catch (IOException e) {
	    e.printStackTrace();
	}
    }

    /**
     * @param file
     */
    private void saveAsGrd(File file) {
	try {
	    PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(file)));
	    out.println("#nodes");
	    for (Node node : nodes) {
		out.printf("%d;%d;%d;%d%n", nodes.indexOf(node), node.getX(), node.getY(),
			node.getLabel());
	    }
	    out.println("#edges");
	    for (Edge edge : getEdges()) {
		out.printf("%d;%d%n", nodes.indexOf(edge.getNode1()),
			nodes.indexOf(edge.getNode2()));
	    }
	    out.flush();
	    out.close();
	} catch (IOException e) {
	    e.printStackTrace();
	}
    }
    
    /**
     * @param file
     */
    private void saveAsGrx(File file) {
	try {
	    PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(file)));
	    out.println("#nodes");
	    for (Node node : nodes) {
		out.printf("%d;%d;%d;%d;%d%n", nodes.indexOf(node), node.getX(), node.getY(),
			node.getLabel(),node.origId);
	    }
	    out.println("#edges");
	    for (Edge edge : getEdges()) {
		out.printf("%d;%d%n", nodes.indexOf(edge.getNode1()),
			nodes.indexOf(edge.getNode2()));
	    }
	    out.flush();
	    out.close();
	} catch (IOException e) {
	    e.printStackTrace();
	}
    }

    /**
     * Swaps labels of two nodes in graph (and likewise their position in
     * ArrayList nodes.
     * 
     * @param node1
     * @param node2
     */
    public void swapNodes(Node node1, Node node2) {
	// permute nodes in arrayList
	int indexNode1 = nodes.indexOf(node1);
	Node node = nodes.get(nodes.indexOf(node2));
	nodes.set(nodes.indexOf(node2), node1);
	nodes.set(indexNode1, node);
    }

    public void swapNodes(int nodeID1, int nodeID2) {
	swapNodes(nodes.get(nodeID1), nodes.get(nodeID2));
    }

    public void swapNodes(Node node, int nodeId) {
	swapNodes(node, nodes.get(nodeId));
    }

    public void moveNode(Node node, int i) {
	nodes.remove(node);
	nodes.add(i, node);
    }

    public void moveNode(int n, int i) {
	moveNode(nodes.get(n), i);
    }

    public ArrayList<Node> getNodes() {
	return nodes;
    }

    public Node getNode(int nodeID) {
	return nodes.get(nodeID);
    }

    public void setNodes(ArrayList<Node> nodes) {
	this.nodes = nodes;
    }

    public void setEdges(ArrayList<Edge> edges) {
	this.edges = edges;
    }

    public ArrayList<Edge> getEdges() {
	return edges;
    }

    public void shuffle() {
	Collections.shuffle(nodes);
    }

    /**
     * Returns <b>non-reflected</b> subgraph (without edge coordinates) from
     * firstNode (inclusive) to lastNode (inclusive).
     * 
     * @param firstNode
     *            first node (inclusive)
     * @param lastNode
     *            last node (inclusive)
     * @return non-reflected subgraph (nodes are reflected, though)
     */
    public Graph subgraph(Node firstNode, Node lastNode) {
	return subgraph(nodes.indexOf(firstNode), nodes.indexOf(lastNode));
    }

    /**
     * Returns <b>non-reflected</b> subgraph (without edge coordinates) from
     * first node (inclusive) to last node (inclusive). Note: the subgraph
     * currently contains no edges.
     * 
     * @param first
     *            first node (inclusive)
     * @param last
     *            last node (inclusive)
     * @return non-reflected subgraph (nodes are reflected, though)
     */
    public Graph subgraph(int first, int last) {
	return new Graph(nodes.subList(first, last + 1));
    }

    public int getDegree(int i, int firstNodeID, int lastNodeID) {
	int degree = 0;
	for (Node n : nodes.get(i).getNeighbors()) {
	    if (nodes.indexOf(n) >= firstNodeID && nodes.indexOf(n) < lastNodeID) { // TODO:
										    // check
										    // if
										    // not
										    // '<
										    // lastNodeID'!
										    // (LOOKS
										    // LIKE!!)
		degree++;
	    }
	}
	return degree;
    }

    public int getDegree(int i) {
	return getDegree(i, 0, this.size());
    }

    public int getDegree(Node node) {
	return getDegree(nodes.indexOf(node), 0, this.size());
    }

    public Node updateCluster(Node node) {

	return null;
    }

    public boolean contains(Node node) {
	return nodes.contains(node);
    }

    public int size() {
	return nodes.size();
    }

    public Collection<? extends Node> subList(int fromIndex, int toIndex) {
	return nodes.subList(fromIndex, toIndex);
    }

    public int getNumberOfNeighbors(Node node, int to) {
	int nodeId = nodes.indexOf(node);
	int result = 0;
	int index;
	for (Node n : node.getNeighbors()) {
	    index = nodes.indexOf(n);
	    if (index >= nodeId && index <= to) {
		result++;
	    }
	}
	return result;
    }

    public ArrayList<Node> getNeighbors(Node node, int to) {
	ArrayList<Node> result = new ArrayList<Node>();
	int nodeId = nodes.indexOf(node);
	int index;
	for (Node n : node.getNeighbors()) {
	    index = nodes.indexOf(n);
	    if (index >= nodeId && index <= to) {
		result.add(n);
	    }
	}

	return result;
    }

    public void removeNode(Node node) {
	nodes.remove(node);
	if (edges != null) {
	    for (Iterator<Edge> iter = edges.iterator(); iter.hasNext();) {
		Edge edge = iter.next();
		if (edge.containsAsNode(node)) {
		    iter.remove();
		}
	    }
	}
    }

    public void addNode(int i, Node node) {
	nodes.add(i, node);

    }

    public void addNode(Node node) {
	nodes.add(node);
    }

    public Node getMaxDegreeNode() {
	Node maxDegreeNode = null;
	int maxDegree = -1;
	int degree = 0;
	for (Node node : nodes) {
	    degree = this.getDegree(node);
	    if (degree > maxDegree) {
		maxDegreeNode = node;
		maxDegree = degree;
	    }
	}
	return maxDegreeNode;
    }

    public void add(Node node) {
	nodes.add(node);
    }

    public int indexOf(Node node) {
	return nodes.indexOf(node);
    }

    public void remove(Node node) {
	removeNode(node);
    }

    public int getHighestDegree() {
	int highestDegree = 0;
	int degree = 0;
	for (Node node : nodes) {
	    degree = this.getDegree(node);
	    if (degree > highestDegree) {
		highestDegree = degree;
	    }
	}
	return highestDegree;
    }

    /**
     * For debugging.
     */
    public int sumOfAllEdges() {
	int[][] adjMat = this.getAdjacencyMatrix();
	int result = 0;
	for (int i = 0; i < this.size(); i++) {
	    for (int j = i + 1; j < this.size(); j++) {
		result += adjMat[i][j];
	    }
	}
	return result;
    }

    public void addEdge(Node node1, Node node2) {
	edges.add(new Edge(node1, node2));
    }

    public boolean containsEdge(Node node1, Node node2) {
	Edge edge = new Edge(node1, node2);
	return edges.contains(edge);
    }

    /**
     * Transforms graph to tree with {@code rootNode} as root by removing
     * cycles.
     * 
     * Note: only works if edges of type edge(parentNode,childNode) and not
     * edge(childNode,parentNode).
     * 
     * @param rootNode
     */
    public void transformToTree(Node rootNode) {
	ArrayList<Node> treeNodes = new ArrayList<Node>();
	LinkedList<Node> nextNodesToProcess = new LinkedList<Node>();
	nextNodesToProcess.add(rootNode);
	treeNodes.add(rootNode);
	Node currentNode = null;

	while ((currentNode = nextNodesToProcess.poll()) != null) {
	    ArrayList<Edge> edgesToRemove = new ArrayList<Edge>();

	    for (Edge edge : edges) {
		if (edge.containsAsNode1(currentNode)) {
		    if (treeNodes.contains(edge.getNode2())) {
			edgesToRemove.add(edge);
		    } else {
			treeNodes.add(edge.getNode2());
			nextNodesToProcess.add(edge.getNode2());
		    }
		}
		// else if (edge.containsAsNode2(currentNode)) {
		// if (treeNodes.contains(edge.getNode1())) {
		// edgesToRemove.add(edge);
		// } else {
		// treeNodes.add(edge.getNode1());
		// nextNodesToProcess.add(edge.getNode1());
		// }
		// }
	    }
	    edges.removeAll(edgesToRemove);
	}
    }

    public boolean addAll(Collection<Node> nodes) {
	return this.nodes.addAll(nodes);
    }

    public boolean contains(Graph graph) {
	return this.nodes.containsAll(graph.getNodes());
    }

    public void sortRandomBfs() {
	randomize();
	sortAsTree();
    }

    public void sortBfs() {
	sortAsTree();
    }

    public void sortAsTree() {
	Node currentNode = getNode(0);
	Graph orderedGraph = new Graph(this.size());
	LinkedList<Node> allNodesToProcess = new LinkedList<Node>(getNodes());
	LinkedList<Node> nextNodesToProcess = new LinkedList<Node>();
	HashSet<Node> visitedNodes = new HashSet<Node>();

	while (currentNode != null) {

	    if (allNodesToProcess.remove(currentNode)) {
		visitedNodes.add(currentNode);
		orderedGraph.add(currentNode);
		for (Node neighbor : currentNode.getNeighbors()) {
		    if (contains(neighbor)) {
			nextNodesToProcess.add(neighbor);
		    }
		}
	    }

	    if ((currentNode = nextNodesToProcess.poll()) == null) {
		if (allNodesToProcess.isEmpty()) {
		    currentNode = null;
		} else {
		    currentNode = allNodesToProcess.getFirst();
		}
	    }
	}

	nodes = new ArrayList<Node>(orderedGraph.getNodes());
    }

    /**
     * Updates shape locations and edge coordinates using node coordinates.
     */
    public void update() {
	for (Edge edge : edges) {
	    edge.update();
	}
	for (Node node : nodes) {
	    node.recalculateShape();
	}
    }

    public Dimension getDimension() {
	return dimension;
    }

    public void increaseDimension() {
	dimension.setSize(dimension.getWidth() + 100, dimension.getHeight() + 100);
    }

    public void decreaseDimension() {
	dimension.setSize(dimension.getWidth() - 100, dimension.getHeight() - 100);
    }

    public boolean containsEdge(Edge edge) {
	return edges.contains(edge);
    }

    public void addEdge(Edge edge) {
	edges.add(edge);
    }
}
