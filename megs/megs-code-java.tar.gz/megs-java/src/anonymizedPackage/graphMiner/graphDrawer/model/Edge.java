package anonymizedPackage.graphMiner.graphDrawer.model;

import java.awt.Point;
import java.awt.geom.Point2D;
import java.awt.geom.Line2D.Float;

/**
 * 
 * @version $Id: Edge.java 1743 2014-06-27 14:36:51Z goebl $
 */
public class Edge extends Float {

    private static final long serialVersionUID = 4255058261940327386L;

    private Node node1;
    private Node node2;

    public Edge() {
    }

    public Edge(Point2D arg0, Point2D arg1) {
	super(arg0, arg1);
    }

    public Edge(float arg0, float arg1, float arg2, float arg3) {
	super(arg0, arg1, arg2, arg3);
    }

    public Edge(Node node1, Node node2) {
	super(node1.getX(), node1.getY(), node2.getX(), node2.getY());
	this.node1 = node1;
	this.node2 = node2;
	
	// quick and dirty safety check
	if (node1 == node2){
	    throw new IllegalArgumentException("Self-Edges are not allowed!");
	}
    }

    public Edge(Node node1, float x, float y) {
	super(node1.getX(), node1.getY(), x, y);
	this.node1 = node1;
    }

    public Node getNode1() {
	return node1;
    }

    public Node getNode2() {
	return node2;
    }

    public boolean containsAsNode1(Node node) {
	return (this.node1.equals(node));

    }

    public boolean containsAsNode2(Node node) {
	return (this.node2.equals(node));

    }

    public boolean containsAsNode(Node node) {
	return containsAsNode1(node) || containsAsNode2(node);
    }

    public boolean contains(Point p, double distance) {
	return (this.ptLineDist(p) < distance);
    }

    public void update() {
	this.x1 = node1.getX();
	this.y1 = node1.getY();
	this.x2 = node2.getX();
	this.y2 = node2.getY();
    }

    @Override
    public boolean equals(Object object) {
	if (object instanceof Edge) {
	    return ((Edge) object).containsAsNode(node1) && ((Edge) object).containsAsNode(node2);
	} else {
	    return super.equals(object);
	}
    }

}
