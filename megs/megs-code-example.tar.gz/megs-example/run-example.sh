#!/bin/bash
# clusters running example from paper
#
java -jar graphMiner.jar running-example.grd
