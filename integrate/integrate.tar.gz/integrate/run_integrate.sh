javac integrate/Main.java && java integrate/Main
