# Integrate

- Research code for paper 
`C. Böhm, A. Oswald, C. Plant, M. Plavinski, and B. Wackersreuther. “Integrative Parameter-Free Clustering of Data with Mixed Type Attributes”. In: PAKDD ’10: Advances in Knowledge Discovery and
Data Mining. 2010, pp. 38–47. doi: 10.1007/978-3-642-13657-3_7` (https://www.springerprofessional.de/integrative-parameter-free-clustering-of-data-with-mixed-type-at/3307944)
- The code comes with a JAVA GUI (see `gut-layout.png`)
- Works with  Java SE 15
- Compile and run with `javac integrate/Main.java && java integrate/Main` (May differ depending on OS)

## How to Use the GUI

- The GUI is only able to visualize 2 numerical and 1 categorical dimensions. Datasets with higher dimensions are processed properly by Integrate but naturally cannot be visualized; please save the results and visualize outside the GUI.
- `load Points` loads a dataset with numerical and categorical attributes. See the file `runningeXampleLabelled.data` for reference: data columns are labelled with `N` or `C` for numerical or categorical type. Categorical values are labeled with integers starting with `0`. The file also requires a column `L`  for the class labels. This is used to calculate the clustering quality. If no labels are known, enter `0` in this column in each row.
- `init` initializes the datset (Z-transform if checked). If no dataset is loaded, `init` creates a random dataset according to the settings `k`, `dim. numerical` and `dim. categorical` entered.
- `reduce` shrinks the dataset to the dimensions entered in the same fields.
- `calculate costs for k's` determines the best number of clusters `k` by minimizing MDL.
  - if a fixed `k` is required, please adjust the lower and upper limit accordingly.
- `run algorithm` runs Integrate for the k with minimal MDL (only works after `init` is completed).
- `save results` writes the clustering result to disk.
- `show origin` and `show result` gives the cluster means and point assignments after initialization (origin) and after running Integrate (result)
- `toggle view` switches the coloring between showing the cluster assignment and showing the first categorical dimension (due to limited colors, this is only useful for studying the results of a toy example)
- `save init points` and `save init p & c` save a dataset and the clustering results for a dataset that is randomly created (see `init` wihout loading a dataset).
- Understanding the `Output`tab:
  - the rows `1;      10175.4172907843`,  `2;       9526.2726316992`, .. give the MDL for each number of clusters calculated. The minimum MDL value gives the best `k` that is used for running the algorithm. Plotting the MDL values gives an idea about other local minima (= good alternative numbers of clusters)
  - Best/ word/ mean quality refers the cluster-validity score by Byron Dom (see paper). This is not up-to-date, today one would use NMI/AMI. This can be calculated outside of Integrate when saving the results.

