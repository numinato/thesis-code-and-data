package integrate.util;

import integrate.Main;
import integrate.ds.ClusteringSet;
import integrate.ds.Point;

public class ClusteringEvaluation {

    public static double measureQuality(ClusteringSet classesSet, ClusteringSet clustersSet) {
        int[][] contingencyTable = createContingencyTable(classesSet, clustersSet);
        if (Main.DEBUGGING) {
            for (int i = 0; i < contingencyTable.length; i++) {
                for (int j = 0; j < contingencyTable[i].length; j++) {
                    System.err.print(contingencyTable[i][j] + " ");
                }
                System.err.println();
            }
            System.err.println();
        }
        return measureQuality(contingencyTable);
    }

    public static double measureQuality(int[][] contingencyTable) {
        double conEntr;
        double encodingClustering = 0.0;
        double result;
        int numClasses = contingencyTable.length;
        int numClusters = contingencyTable[0].length;
        int[] clusterSize;
        int n = 0;
        int classSize = numClasses - 1;

        for (int i = 0; i < contingencyTable.length; i++) {
            for (int j = 0; j < contingencyTable[i].length; j++) {
                n += contingencyTable[i][j];
            }
        }

        clusterSize = clusterSize(contingencyTable, numClasses, numClusters);
        conEntr = conditionalEntropy(contingencyTable, clusterSize, numClasses, numClusters, n);

        for (int i = 0; i < numClusters; i++) {
            int upper = clusterSize[i] + classSize;
            encodingClustering += Math.log(Binomial.binomial(upper, classSize));
        }

        encodingClustering /= (double) n;
        result = conEntr + encodingClustering;
        return result;
    }

    private static double conditionalEntropy(int[][] conTab, int[] clusterSize, int numClasses, int numClusters,
            int n) {
        double sum = 0.0;
        for (int i = 0; i < numClasses; i++) {
            for (int j = 0; j < numClusters; j++) {
                double mult1 = conTab[i][j] / (double) n;
                double mult2 = Math.log(conTab[i][j] / (double) clusterSize[j]);
                if (mult1 != 0) {
                    sum += mult1 * mult2;
                }
            }
        }
        return -sum;
    }

    private static int[] clusterSize(int[][] conTab, int numClasses, int numClusters) {
        int[] size = new int[numClusters];
        for (int i = 0; i < numClusters; i++) {
            for (int j = 0; j < numClasses; j++) {
                size[i] += conTab[j][i];
            }
        }
        return size;
    }

    private static int[][] createContingencyTable(ClusteringSet classesSet, ClusteringSet clustersSet) {
        int numClasses = classesSet.clusterings.length;
        int numClusters = clustersSet.clusterings.length;
        int[][] contingencyTable = new int[numClasses][numClusters];

        for (int i = 0; i < numClasses; i++) {
            for (int j = 0; j < numClusters; j++) {
                for (Point p : classesSet.clusterings[i].points) {
                    if (clustersSet.pointMap.get(p) == clustersSet.clusterings[j]) {
                        contingencyTable[i][j]++;
                    }
                }
            }
        }
        return contingencyTable;
    }

}