package integrate.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import integrate.core.ClusteringApp;
import integrate.ds.Clustering;
import integrate.ds.ClusteringSet;
import integrate.ds.Point;

public class FileAccess {

    public static void saveResult(String directory, ArrayList<HashMap<Integer, String>> decodingTable,
            String filename, ClusteringSet cs) throws IOException {

        PrintWriter pw = createPrintWriter(directory, filename);

        writePointsAndClusteringLabels(pw, cs, decodingTable);

        pw.flush();
        pw.close();

    }

    /**
     * @param pw
     * @param cs
     * @param decodingTable
     */
    private static void writePointsAndClusteringLabels(PrintWriter pw, ClusteringSet cs,
            ArrayList<HashMap<Integer, String>> decodingTable) {
        for (int i = 0; i < cs.clusterings[0].points.get(0).numParameters.length; i++) {
            pw.print("N,");
        }
        for (int i = 0; i < cs.clusterings[0].points.get(0).catParameters.length; i++) {
            pw.print("C,");
        }
        pw.println("CLUSTERING");

        writePoints(pw, cs, decodingTable);
    }

    /**
     * @param pw
     * @param cs
     * @param decodingTable
     */
    private static void writePointsAndClassLabels(PrintWriter pw, ClusteringSet cs,
            ArrayList<HashMap<Integer, String>> decodingTable) {
        for (int i = 0; i < cs.clusterings[0].points.get(0).numParameters.length; i++) {
            pw.print("N,");
        }
        for (int i = 0; i < cs.clusterings[0].points.get(0).catParameters.length; i++) {
            pw.print("C,");
        }
        pw.println("L");

        writePoints(pw, cs, decodingTable);
    }    
    
    /**
     * @param pw
     * @param cs
     * @param decodingTable
     */
    private static void writePoints(PrintWriter pw, ClusteringSet cs,
            ArrayList<HashMap<Integer, String>> decodingTable) {
        int label = 0;
        for (Clustering c : cs.clusterings) {
            for (Point p : c.points) {
                for (double numParameter : p.numParameters) {
                    pw.printf(Locale.US, "%f,", numParameter);
                }
                if (decodingTable == null) {
                    for (int catParameter : p.catParameters) {
                        pw.print(catParameter + ",");
                    }
                } else {
                    for (int i = 0; i < decodingTable.size(); i++) {
                        pw.printf("%s,", decodingTable.get(i).get(p.catParameters[i]));
                    }
                }
                pw.println(label);
            }
            label++;
        }
        
    }

    public static void saveInitPoints(String directory, String filename, ClusteringSet cs, ArrayList<HashMap<Integer, String>> decodingTable)
            throws IOException {

        PrintWriter pw = createPrintWriter(directory, filename);

        writePointsAndClassLabels(pw, cs, decodingTable);

        pw.flush();
        pw.close();
    }

    private static void writePoints(PrintWriter pw, ArrayList<Point> points) {

        pw.println("POINTS:");
        for (Point p : points) {
            System.out.println(p.toString());
        }
        for (int i = 0; i < points.get(0).numParameters.length; i++) {
            pw.print("NUM" + (i + 1) + ";");
        }
        for (int i = 0; i < points.get(0).catParameters.length; i++) {
            pw.print("CAT" + (i + 1) + ";");
        }
        pw.println();

        for (Point p : points) {
            for (double numParameter : p.numParameters) {
                pw.printf("%f;", numParameter);
            }
            // for (boolean catParameter : p.catParameters) {
            // pw.printf("%b;", catParameter);
            // }
            pw.println();
        }

    }

    private static PrintWriter createPrintWriter(String directory, String filename) throws IOException {

        File file = new File(directory, filename);
        file.createNewFile();
        return new PrintWriter(new FileWriter(file));
    }

    @SuppressWarnings("unchecked")
    public static ArrayList<Point> loadPoints(ArrayList<Clustering> clusterings,
            ArrayList<HashMap<Integer, String>> decodingTableForSaving, String directory, String filename)
            throws IOException {

        ArrayList<Point> points = new ArrayList<Point>();
        String[] dataDefinition;
        String line;
        int dimNumerical = 0;
        int dimCategorical = 0;

        BufferedReader br = new BufferedReader(new FileReader(new File(directory, filename)));

        dataDefinition = br.readLine().split(",");
        for (String d : dataDefinition) {
            if (d.equalsIgnoreCase("n")) {
                dimNumerical++;
            } else if (d.equalsIgnoreCase("c")) {
                dimCategorical++;
            }
        }
        HashMap<String, Integer>[] hmsCatParameter = (HashMap<String, Integer>[]) new HashMap[dimCategorical];
        for (int i = 0; i < dimCategorical; i++) {
            hmsCatParameter[i] = new HashMap<String, Integer>();
        }
        HashMap<String, Clustering> hmClustering = new HashMap<String, Clustering>();

        while ((line = br.readLine()) != null) {
            Clustering clustering = null;
            double[] numParameters = new double[dimNumerical];
            int[] catParameters = new int[dimCategorical];
            int pointerNumPar = 0;
            int pointerCatPar = 0;
            String[] parameters = line.split(",");

            for (int i = 0; i < dataDefinition.length; i++) {

                if (dataDefinition[i].equalsIgnoreCase("n")) {
                    numParameters[pointerNumPar] = Double.parseDouble(parameters[i]); // XXX
                    pointerNumPar++;
                } else if (dataDefinition[i].equalsIgnoreCase("c")) {
                    if (hmsCatParameter[pointerCatPar].get(parameters[i]) != null) {
                        int catParameter = hmsCatParameter[pointerCatPar].get(parameters[i]);
                        catParameters[pointerCatPar] = catParameter;
                    } else {
                        int newPosition = hmsCatParameter[pointerCatPar].size();
                        hmsCatParameter[pointerCatPar].put(parameters[i], newPosition);
                        catParameters[pointerCatPar] = newPosition;
                        
                    }
                    pointerCatPar++;
                } else if (dataDefinition[i].equalsIgnoreCase("l")) {
                    clustering = hmClustering.get(parameters[i]);
                    if (clustering == null) {
                        double[] numMeans = new double[numParameters.length];
                        double[] numSigmas = new double[numParameters.length];
                        double[][] catProbabilities = new double[catParameters.length][0];
                        clustering = new Clustering(numMeans, numSigmas, catProbabilities, 0);
                        clusterings.add(clustering);
                        hmClustering.put(parameters[i], clustering);
                    }
                } else {
                    System.err.println("Parsing error: invalid parameter label: only n,c,l allowed.");
                }
            }
            Point p = new Point(numParameters, catParameters);
            points.add(p);
            clustering.points.add(p);
            clustering.size++;
        }
        createDecodingTable(hmsCatParameter, decodingTableForSaving);
        
        ClusteringApp.catParameterDimensions = new int[decodingTableForSaving.size()];
        for (int i = 0; i < ClusteringApp.catParameterDimensions.length; i++) {
            ClusteringApp.catParameterDimensions[i] = decodingTableForSaving.get(i).size();
        }
        
        return points;
    }

    /**
     * @param hmsCatParameter
     * @return
     */
    private static void createDecodingTable(
            HashMap<String, Integer>[] hmsCatParameter, ArrayList<HashMap<Integer, String>> alDecoding) {
        for (HashMap<String, Integer> hm : hmsCatParameter) {
            HashMap<Integer, String> hmDecoding = new HashMap<Integer, String>();
            for (String s : hm.keySet()) {
                hmDecoding.put(hm.get(s), s);
            }
            alDecoding.add(hmDecoding);
        }
    }

    public static void saveInitClusterings(String directory, String filename, ClusteringSet cs) throws IOException {
        PrintWriter pw = createPrintWriter(directory, filename);

        // writePointsAndClusterings(pw, cs);

        pw.flush();
        pw.close();

    }

    public static ArrayList<Point> loadInitialClusterings(String directory, String filename,
            Clustering[] clusterings) throws IOException {

        ArrayList<Point> points = new ArrayList<Point>();
        ArrayList<Double> xs;
        ArrayList<Boolean> as;
        double[] xsArray;
        boolean[] asArray;
        String regexpLine = "[^A-Z]*;";
        String line;
        String[] values;
        boolean reading = true;

        BufferedReader br = new BufferedReader(new FileReader(new File(directory, filename)));

        Pattern patternLine = Pattern.compile(regexpLine);
        Matcher matcherLine;

        while (reading) {
            line = br.readLine();
            if (line == null || line.equals("CLUSTERINGS")) {
                reading = false;
            } else {
                matcherLine = patternLine.matcher(line);
                if (matcherLine.matches()) {
                    xs = new ArrayList<Double>();
                    as = new ArrayList<Boolean>();
                    line = line.replaceAll(",", ".");
                    values = line.split(";");
                    for (int i = 0; i <= values.length - 1; i++) {
                        if (values[i].equalsIgnoreCase("true") || values[i].equalsIgnoreCase("false")) {
                            as.add(Boolean.parseBoolean(values[i]));
                        } else {
                            xs.add(Double.parseDouble(values[i]));
                        }
                    }
                    xsArray = new double[xs.size()];
                    asArray = new boolean[as.size()];
                    for (int i = 0; i < xsArray.length; i++) {
                        xsArray[i] = xs.get(i);
                    }
                    for (int i = 0; i < asArray.length; i++) {
                        asArray[i] = as.get(i);
                    }

                    // points.add(new Point(xsArray, asArray));
                }
            }
        }

        while ((line = br.readLine()) != null) {

        }

        return points;
    }

}
