package integrate.util;

import java.util.ArrayList;
import java.util.Random;

import integrate.core.ClusteringApp;
import integrate.ds.Clustering;
import integrate.ds.Point;

public class Randomizer {

    static double getMean() {
        Random r = new Random();
        return r.nextDouble() * 10.0 - 5.0;
    }

    public static int getInt(int k) {
        Random r = new Random();
        return r.nextInt(k);
    }

    public static Clustering[] createRandomClusterings(int k, int dimNumerical, int dimCategorical) {

        Random r = new Random();
        Clustering[] clusterings = new Clustering[k];

        if (true) {
            double[] numMeans_c1 = { 2.0, -4.0 };
            double[] numSigmas_c1 = { 1.8, 0.75 };
            double[][] catProbabilities_c1 = { { 0.88, 0.12 } };

            double[] numMeans_c2 = { -3.0, -1.5 };
            double[] numSigmas_c2 = { 1.3, 1.7 };
            double[][] catProbabilities_c2 = { { 0.12, 0.88 } };

            double[] numMeans_c3 = { -1.0, 2.0 };
            double[] numSigmas_c3 = { 0.8, 1.0 };
            double[][] catProbabilities_c3 = { { 0.88, 0.12 } };

            
            clusterings[0] = new Clustering(numMeans_c1, numSigmas_c1, catProbabilities_c1, 200);
            clusterings[1] = new Clustering(numMeans_c2, numSigmas_c2, catProbabilities_c2, 500);
            clusterings[2] = new Clustering(numMeans_c3, numSigmas_c3, catProbabilities_c3, 300);

            ClusteringApp.catParameterDimensions = new int[1];
            ClusteringApp.catParameterDimensions[0] = 2;

        } else {
            // create k gaussian clusterings

            for (int i = 0; i < k; i++) {

                int maxCatVariety = 2;
                double[] numMeans = new double[dimNumerical];
                double[] numSigmas = new double[dimNumerical];
                double[][] catProbabilities = new double[dimCategorical][maxCatVariety];
                double numSigma;
                int size;

                numSigma = r.nextDouble() * 0.5 + 0.75; // 0.75 <= sigma < 1.25
                // sigma_x = r.nextDouble() * 2.0 + 0.5; // 0.5 <= sigma < 2.5
                for (int j = 0; j < dimNumerical; j++) {
                    numMeans[j] = r.nextDouble() * 20.0 - 10.0;
                    numSigmas[j] = numSigma;
                }

                for (int j = 0; j < dimCategorical; j++) {
                    catProbabilities[j][0] = r.nextDouble();
                    catProbabilities[j][1] = 1 - catProbabilities[j][0];
                }

                size = r.nextInt(400) + 100; // 100 <= size < 500;
                clusterings[i] = new Clustering(numMeans, numSigmas, catProbabilities, size);

                ClusteringApp.catParameterDimensions = new int[1];
                ClusteringApp.catParameterDimensions[0] = 2;

            }

        }
        return clusterings;
    }

    public static ArrayList<Point> createRandomPointsFromClusterings(Clustering[] clusterings, int dimNumerical,
            int dimCategorical) {
        Random r = new Random();

        ArrayList<Point> points = new ArrayList<Point>();
        // create points for each gaussian clustering

        for (Clustering c : clusterings) {
            c.points = new ArrayList<Point>();
            for (int i = 0; i < c.size; i++) {
                double[] numParameters = new double[dimNumerical];
                int[] catParameters = new int[dimCategorical];
                for (int j = 0; j < dimNumerical; j++) {
                    numParameters[j] = r.nextGaussian() * c.numSigmas[j] + c.numMeans[j];

                }
                for (int j = 0; j < dimCategorical; j++) {
                    double v1 = r.nextDouble();
                    if (v1 < c.catProbabilities[j][0]) {
                        catParameters[j] = 0;
                    } else {
                        catParameters[j] = 1;
                    }
                }
                Point p = new Point(numParameters, catParameters);
                c.points.add(p);
                points.add(p);
            }
        }

        return points;
    }

}