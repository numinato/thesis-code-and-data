package integrate.core;

import java.util.ArrayList;

import integrate.Main;
import integrate.ds.Clustering;
import integrate.ds.ClusteringSet;
import integrate.ds.Point;
import integrate.util.Randomizer;

public abstract class ClusteringFramework {

    final static double SQRT_OF_TWO_TIMES_PI = Math.sqrt(2.0 * Math.PI);

    public static Clustering[] createInitialClusteringSet(int k, int numberOfAlgInits, ArrayList<Point> points) {

        Clustering[] minCostClusterings = null;
        int dimNumerical = points.get(0).numParameters.length;
        int dimCategorical = points.get(0).catParameters.length;
        double clusteringsMinCost = Double.MAX_VALUE;

        for (int i = 0; i < numberOfAlgInits; i++) {

            double clusteringsCost = 0.0;
            Clustering[] clusterings = new Clustering[k];
            ArrayList<Point> listToRemove = new ArrayList<Point>(points);
            ArrayList<Point> sample = new ArrayList<Point>();
            ArrayList<Point> usedPoints = new ArrayList<Point>();

            for (int j = 0; j < (points.size() / 10); j++) {
                sample.add(listToRemove.remove(Randomizer.getInt(listToRemove.size())));
            }

            for (int j = 0; j < k; j++) {
                double[] numMeans = new double[dimNumerical];
                double[] numSigmas = new double[dimNumerical];
                double[][] catProbabilities = new double[dimCategorical][0];
                for (int v = 0; v < catProbabilities.length; v++) {
                    catProbabilities[v] = new double[ClusteringApp.catParameterDimensions[v]];
                }
                // double[][] catProbabilities = new
                // double[dimCategorical][maxCatVariety];
                clusterings[j] = new Clustering(numMeans, numSigmas, catProbabilities, 0);
            }

            for (Clustering c : clusterings) {
                Point p = sample.get(Randomizer.getInt(sample.size()));
                while (usedPoints.contains(p)) {
                    p = sample.get(Randomizer.getInt(sample.size()));
                }
                for (int j = 0; j < dimNumerical; j++) {
                    c.numMeans[j] = p.numParameters[j];
                    c.numSigmas[j] = 0.4;
                }
                for (int j = 0; j < dimCategorical; j++) {
                    for (int s = 0; s < c.catProbabilities[j].length; s++) {
                        c.catProbabilities[j][s] = 0.5;
                    }
                }
                usedPoints.add(p);
            }

            for (Point p : sample) {
                double minCost = cost(p, clusterings[0]);
                double newCost;
                for (Clustering c : clusterings) {
                    newCost = cost(p, c);
                    if (newCost < minCost) {
                        minCost = newCost;
                    }
                }
                clusteringsCost += minCost;
            }

            if (clusteringsCost < clusteringsMinCost) {
                minCostClusterings = clusterings;
                clusteringsMinCost = clusteringsCost;
            }
        }
        return minCostClusterings;
    }

    public static double clusteringByCost(ClusteringSet cs, ArrayList<Point> points) {

        int loop = 0;
        int numberPointsChanged;
        int k = cs.clusterings.length;
        int dimNumerical = cs.clusterings[0].numMeans.length;
        int dimCategorical = cs.clusterings[0].catProbabilities.length;
        // int maxCatVariety = dimCategorical > 0 ?
        // cs.clusterings[0].catProbabilities[0].length : 0;
        double costSum = 0.0;
        boolean change = true;

        // run clustering algorithm

        while (change) {
            loop++;
            costSum = 0.0;
            change = false;
            numberPointsChanged = 0;

            // calculating minimum cost
            for (Point p : points) {
                Clustering oldClustering = cs.pointMap.get(p);
                Clustering newClustering = cs.clusterings[0];
                double minCost = cost(p, cs.clusterings[0]);
                double newCost;

                for (int i = 1; i < k; i++) {
                    newCost = cost(p, cs.clusterings[i]);
                    if (minCost > newCost) {
                        minCost = newCost;
                        newClustering = cs.clusterings[i];
                    }
                }
                if (oldClustering != newClustering) {
                    cs.pointMap.put(p, newClustering);
                    newClustering.points.add(p);
                    change = true;
                    numberPointsChanged++;
                }
                costSum += minCost;
            }

            // recalculating clustering model
            for (Clustering c : cs.clusterings) {
                c.size = 0;
                c.numMeans = new double[dimNumerical];
                c.numSigmas = new double[dimNumerical];
                for (int i = 0; i < dimCategorical; i++) {
                    c.catProbabilities[i] = new double[ClusteringApp.catParameterDimensions[i]];
                }
                for (Point p : c.points) {
                    c.size++;
                    for (int i = 0; i < dimNumerical; i++) {
                        c.numMeans[i] += p.numParameters[i];
                        c.numSigmas[i] += p.numParameters[i] * p.numParameters[i];
                    }
                    for (int i = 0; i < dimCategorical; i++) {
                        c.catProbabilities[i][p.catParameters[i]]++;
                    }
                }
                for (int i = 0; i < dimNumerical; i++) {
                    if (c.size == 0) {
                        System.err.println("division by zero: c.NumMeans[i]/(c.size==0): " + c.numMeans[i] + " / "
                                + c.size + " = " + c.numMeans[i] / c.size);

                    }
                    c.numMeans[i] /= c.size;
                    c.numSigmas[i] = Math.sqrt((c.numSigmas[i] / c.size) - c.numMeans[i] * c.numMeans[i]);
                }

                for (int i = 0; i < dimCategorical; i++) {
                    for (int j = 0; j < ClusteringApp.catParameterDimensions[i]; j++) {
                        c.catProbabilities[i][j] /= c.size;
                    }
                }
            }
        System.out.println(loop + ";" + numberPointsChanged + ";" + ( costSum + cost(cs.clusterings)));
        }
        costSum += cost(cs.clusterings);
        return costSum;

    }

    /**
     * @param clusterings
     * @return
     */
    private static double cost(Clustering[] clusterings) {
        double costSum = 0.0;
        int n = 0; // n number of points of all clusterings
        for (Clustering c : clusterings) {
            n += c.size;
        }
        for (Clustering c : clusterings) {
            if (c.size == 0) {
                costSum += Double.POSITIVE_INFINITY;
            } else {
                costSum += c.size * Math.log(n / c.size) / Math.log(2);
            }
        }

        for (Clustering c : clusterings) {
            if ((c.size) != 0) {
                costSum += 0.5 * (2 * c.numMeans.length) * c.size;
                double costCategorical = 0.0;
                for (int i = 0; i < c.catProbabilities.length; i++) {
                    costCategorical += c.catProbabilities[i].length -1;
                }
                costSum += 0.5 * costCategorical * c.size;
            }
        }
        return costSum;
    }

    private static double cost(Point p, Clustering c) {
        double sumCost = 0.0;

        for (int i = 0; i < p.numParameters.length; i++) {
            double multiplier = (p.numParameters[i] - c.numMeans[i]) * (p.numParameters[i] - c.numMeans[i]);
            double dens_num = Math.exp(-0.5 * multiplier / c.numSigmas[i] / c.numSigmas[i]) / SQRT_OF_TWO_TIMES_PI
                    / c.numSigmas[i];

            sumCost += -Math.log(dens_num) / Math.log(2.0);
            if (Main.DEBUGGING && false) {
                if (Double.isInfinite(sumCost)) {
                    System.err.println("exp(-0.5 * (" + p.numParameters[i] + " - " + c.numMeans[i] + ") * ("
                            + p.numParameters[i] + " - " + c.numMeans[i] + ") / (" + c.numSigmas[i] + " * "
                            + c.numSigmas[i] + ") )");
                    System.err.println("exp(" + (-0.5 * multiplier / c.numSigmas[i] / c.numSigmas[i]) + ")");
                    System.err.println("exp() = " + Math.exp(-0.5 * multiplier / c.numSigmas[i] / c.numSigmas[i]));
                    System.err.println();
                }
            }
        }

        for (int i = 0; i < p.catParameters.length; i++) {
            sumCost += -Math.log(c.catProbabilities[i][p.catParameters[i]]) / Math.log(2.0);
            if (Main.DEBUGGING && false) {

                if (Double.isInfinite(sumCost)) {
                    System.err.println("sumCost is infinite.");
                    System.err.print("c.catProbabilities[" + i + "][p.catParameters[" + i + "]] == ");
                    System.err.println(c.catProbabilities[i][p.catParameters[i]]);
                    System.err.println();
                }
            }
        }
        return sumCost;
    }

    /**
     * @param points
     */
    public static void zTransform(ArrayList<Point> points) {
        for (int i = 0; i < points.get(0).numParameters.length; i++) {
            double sigma = 0.0;
            double mean = 0.0;
            for (Point p : points) {
                sigma += p.numParameters[i] * p.numParameters[i];
                mean += p.numParameters[i];
            }
            mean /= points.size();
            sigma = Math.sqrt((sigma / points.size()) - mean * mean);
            for (Point p : points) {
                p.numParameters[i] = (p.numParameters[i] - mean) / sigma;
            }
        }
    }
}
