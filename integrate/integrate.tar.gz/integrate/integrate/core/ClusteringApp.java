package integrate.core;

import java.awt.FileDialog;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import integrate.ds.Clustering;
import integrate.ds.ClusteringSet;
import integrate.ds.Point;
import integrate.ds.State;
import integrate.gui.DrawPanel;
import integrate.util.ClusteringEvaluation;
import integrate.util.FileAccess;
import integrate.util.Randomizer;

public class ClusteringApp {

    // XXX: shortcut for creating clusterings of correct depth
    public static int[] catParameterDimensions;

    public DrawPanel drawPanel;
    private State state;
    private int bestK;
    private ArrayList<Point> points;
    private ClusteringSet creatingClusteringSet;
    private ClusteringSet resultClusteringSet;
    public JTextArea textArea;
    public JTextArea largeTextArea;
    public JTextArea textAreaDuplicate;
    public JTextField kField;
    public JTextArea thirdTextArea;
    public ArrayList<HashMap<Integer, String>> decodingTableForSaving;
    public final static int SAVE_RESULT = 0;
    public final static int SAVE_INITIALIZATION = 1;

    public ClusteringApp() {
        state = State.STARTED;
    }

    public void init(int k, int dimNumerical, int dimCategorical) {
        Clustering[] clusterings = Randomizer.createRandomClusterings(k, dimNumerical, dimCategorical);
        points = Randomizer.createRandomPointsFromClusterings(clusterings, dimNumerical, dimCategorical);
        creatingClusteringSet = new ClusteringSet(clusterings);
        creatingClusteringSet.initPointMap();
        decodingTableForSaving = null;
        state = State.INITIALIZED;
    }

    public boolean saveInitPoints(JFrame frame) throws IOException {
        if (state == State.INITIALIZED || state == State.BEST_K_FOUND || state == State.CALC_FINISHED) {
            FileDialog fd = new FileDialog(frame, "Save initialization", FileDialog.SAVE);
            fd.setVisible(true);
            FileAccess.saveInitPoints(fd.getDirectory(), fd.getFile(), creatingClusteringSet,
                    decodingTableForSaving);
            return true;
        } else {
            return false;
        }
    }

    public boolean loadPoints(JFrame frame, boolean zTransform) throws IOException {
        if (state == State.STARTED || state == State.INITIALIZED || state == State.CALC_FINISHED
                || state == State.BEST_K_FOUND) {
            FileDialog fd = new FileDialog(frame, "Load points", FileDialog.LOAD);
            fd.setVisible(true);
            String file = fd.getFile();
            if (file != null) {
                ArrayList<Clustering> alClusterings = new ArrayList<Clustering>();
                decodingTableForSaving = new ArrayList<HashMap<Integer, String>>();
                points = FileAccess.loadPoints(alClusterings, decodingTableForSaving, fd.getDirectory(), fd
                        .getFile());
                if (zTransform)
                    ClusteringFramework.zTransform(points);
                Clustering[] c = new Clustering[alClusterings.size()];
                for (int i = 0; i < c.length; i++) {
                    c[i] = alClusterings.get(i);
                }
                creatingClusteringSet = new ClusteringSet(c);
                creatingClusteringSet.initPointMap();
                state = State.INITIALIZED;
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public boolean loadInitialClusterings(JFrame frame) throws IOException {
        if (state == State.STARTED || state == State.INITIALIZED || state == State.CALC_FINISHED
                || state == State.BEST_K_FOUND) {
            FileDialog fd = new FileDialog(frame, "Load init p & c", FileDialog.LOAD);
            fd.setVisible(true);
            String file = fd.getFile();
            if (file != null) {

                // points = FileAccess.loadInitialClusterings(fd.getDirectory(),
                // fd.getFile(), clusterings);
                state = State.INITIALIZED;
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }

    }

    public String calcCostsForKs(int minK, int maxK, int numberOfAlgInits) {
        if (state == State.INITIALIZED || state == State.BEST_K_FOUND || state == State.CALC_FINISHED) {
            String result = new String("");
            HashMap<Integer, Double> costMap = new HashMap<Integer, Double>();
            double cost;
            double minCost = Double.MAX_VALUE;
            for (int k = minK; k <= maxK; k++) {
                Clustering[] clusterings = ClusteringFramework.createInitialClusteringSet(k, numberOfAlgInits,
                        points);
                ClusteringSet cs = new ClusteringSet(clusterings);
                cost = ClusteringFramework.clusteringByCost(cs, points);
                costMap.put(k, cost);
                if (cost < minCost) {
                    minCost = cost;
                    bestK = k;
                }

                System.err.println("k: " + k + "; cost: " + cost);
            }

            for (int i = minK; i <= maxK; i++) {
                result += String.format(Locale.US, "%3d;  %20.10f%n", i, costMap.get(i));
            }

            result += String.format(Locale.US, "   BEST K = %d%n%n", bestK);
            System.err.println();
            state = State.BEST_K_FOUND;
            return result;
        } else {
            return null;
        }
    }

    public String runAlgorithm(int numberOfAlgInits, int numberOfAlgTries) {
        if (state == State.BEST_K_FOUND || state == State.CALC_FINISHED) {
            double qualityBest = Double.MAX_VALUE;
            double qualityWorst = 0.0;
            double qualityMean = 0.0;
            for (int i = 0; i < numberOfAlgTries; i++) {
                System.err.println("try " + i);
                Clustering[] minCostInitialClusterings = null;
                minCostInitialClusterings = ClusteringFramework.createInitialClusteringSet(bestK,
                        numberOfAlgInits, points);
                ClusteringSet cs = new ClusteringSet(minCostInitialClusterings);
                ClusteringFramework.clusteringByCost(cs, points);
                double qm = ClusteringEvaluation.measureQuality(creatingClusteringSet, cs);
                qualityMean += qm;
                if (qm < qualityBest) {
                    qualityBest = qm;
                    resultClusteringSet = cs;
                }
                if (qm > qualityWorst) {
                    qualityWorst = qm;
                }
            }
            qualityMean /= numberOfAlgTries;
            state = State.CALC_FINISHED;
            return String.format(Locale.US, "Best quality = %f%nWorst quality = %f%nMean quality = %f%n%n", qualityBest,
                    qualityWorst, qualityMean);
        }
        return null;
    }

    public ClusteringSet getCreatingClusteringSet() {
        if (state == State.INITIALIZED || state == State.BEST_K_FOUND || state == State.CALC_FINISHED) {
            if (creatingClusteringSet.clusterings[0].numMeans.length == 2
                    && creatingClusteringSet.clusterings[0].catProbabilities.length <= 1) {
                return creatingClusteringSet;
            }
        }
        return null;
    }

    public ClusteringSet getResultClusteringSet() {
        if (state == State.CALC_FINISHED) {
            if (resultClusteringSet.clusterings[0].numMeans.length == 2
                    && resultClusteringSet.clusterings[0].catProbabilities.length <= 1) {
                return resultClusteringSet;
            }
        }

        return null;
    }

    public void saveResult(JFrame frame) throws IOException {
        if (state == State.CALC_FINISHED) {
            FileDialog fd = new FileDialog(frame, "Save result", FileDialog.SAVE);
            fd.setVisible(true);
            FileAccess.saveResult(fd.getDirectory(), decodingTableForSaving, fd.getFile(), resultClusteringSet);
        }
    }

    public boolean saveInitClusterings(JFrame frame) throws IOException {
        if (state == State.STARTED) {
            return false;
        } else {
            FileDialog fd = new FileDialog(frame, "Save init p & c", FileDialog.SAVE);
            fd.setVisible(true);
            FileAccess.saveInitClusterings(fd.getDirectory(), fd.getFile(), creatingClusteringSet);
            return true;
        }
    }

    public boolean reduceInit(int newDimNumerical, int newDimCategorical) {
        if (state == State.STARTED) {
            return false;
        } else {
            if (newDimNumerical <= points.get(0).numParameters.length
                    && newDimCategorical <= points.get(0).catParameters.length) {
                reduceClustering(newDimNumerical, newDimCategorical, creatingClusteringSet);
                creatingClusteringSet.initPointMap();
                state = State.INITIALIZED;

                return true;
            } else {
                return false;
            }

        }

    }

    private void reduceClustering(int dimNumerical, int dimCategorical, ClusteringSet cs) {

        int maxCatVariety = 10;
        for (Clustering c : cs.clusterings) {
            double[] newNumMeans = new double[dimNumerical];
            for (int i = 0; i < dimNumerical; i++) {
                newNumMeans[i] = c.numMeans[i];
            }
            c.numMeans = newNumMeans;

            double[] newNumSigmas = new double[dimNumerical];
            for (int i = 0; i < dimNumerical; i++) {
                newNumSigmas[i] = c.numSigmas[i];
            }
            c.numSigmas = newNumSigmas;

            double[][] newCatProbabilities = new double[dimCategorical][maxCatVariety];
            for (int i = 0; i < dimCategorical; i++) {
                newCatProbabilities[i] = c.catProbabilities[i];
            }
            c.catProbabilities = newCatProbabilities;

            for (Point p : c.points) {
                double[] newNumParameters = new double[dimNumerical];
                for (int i = 0; i < dimNumerical; i++) {
                    newNumParameters[i] = p.numParameters[i];
                }
                p.numParameters = newNumParameters;

                int[] newCatParameters = new int[dimCategorical];
                for (int i = 0; i < dimCategorical; i++) {
                    newCatParameters[i] = p.catParameters[i];
                }
                p.catParameters = newCatParameters;
            }
        }
    }
}
