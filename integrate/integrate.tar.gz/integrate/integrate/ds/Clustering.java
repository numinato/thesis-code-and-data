package integrate.ds;

import java.util.ArrayList;

public class Clustering {
    
    public Clustering(double[] numMeans, double[] numSigmas, double[][] catProbabilities, int size){
        
        this.numMeans = numMeans;
        this.numSigmas = numSigmas;
        this.catProbabilities = catProbabilities;
        this.size = size;
        points = new ArrayList<Point>();

    }

    public double[] numMeans;
    public double[] numSigmas;
    public double[][] catProbabilities;
    public int size;
    public ArrayList<Point> points;
    
    
    @Override
    public String toString() {
        
        StringBuffer sbnumMeans = new StringBuffer();
        StringBuffer sbnumSigmas = new StringBuffer();
        StringBuffer sbcatProbabilities = new StringBuffer();
        
        for (Double numMean : this.numMeans) {
            sbnumMeans.append("   ").append(numMean).append(System.getProperty("line.separator"));
        }
        for (Double numSigma : this.numSigmas) {
            sbnumSigmas.append("   ").append(numSigma).append(System.getProperty("line.separator"));
        }
        for (int i = 0; i<catProbabilities.length; i++){
            sbcatProbabilities.append(System.getProperty("line.separator"));
            for (int j = 0; j<catProbabilities[i].length; j++) {
                sbcatProbabilities.append("   ").append(catProbabilities[i][j]).append(System.getProperty("line.separator"));
            }
        }
        
        return  "Clustering:" + System.getProperty("line.separator") +
                " numMeans: " + System.getProperty("line.separator") +
                sbnumMeans.toString() +
                " numSigmas: " + System.getProperty("line.separator") +
                sbnumSigmas.toString() +
                " catProbabilities: " + System.getProperty("line.separator") +
                sbcatProbabilities.toString() +
                " size:" + this.size + System.getProperty("line.separator");
    }
    
}
