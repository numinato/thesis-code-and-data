package integrate.ds;

/**
 * @author sg
 *
 */
public class Point {

    public Point(double[] numParameters, int[] catParameters) {

        this.numParameters = numParameters;
        this.catParameters = catParameters;

    }

    public double[] numParameters;
    public int[] catParameters;


    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        for (double numParameter : numParameters) {
            sb.append(numParameter).append(";");
        }
        for (int catParameter : catParameters) {
            sb.append(catParameter).append(";");
        }
        return sb.toString();
    }
}
