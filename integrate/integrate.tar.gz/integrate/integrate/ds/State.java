package integrate.ds;

public enum State {
    STARTED, INITIALIZED, CALC_FINISHED, BEST_K_FOUND
}
