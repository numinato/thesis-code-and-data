package integrate.ds;

import java.util.HashMap;

public class ClusteringSet {

    final int k;
    public Clustering[] clusterings;
    public HashMap<Point, Clustering> pointMap;

    public ClusteringSet(Clustering[] clusterings) {
        this.clusterings = clusterings;
        k = clusterings.length;
        pointMap = new HashMap<Point, Clustering>();
    }

    public void initPointMap() {
        for (Clustering c : clusterings) {
            for (Point p : c.points) {
                pointMap.put(p, c);

            }
        }
    }
}
