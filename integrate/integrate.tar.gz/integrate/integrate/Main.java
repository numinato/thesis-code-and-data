package integrate;

import javax.swing.JFrame;

import integrate.core.ClusteringApp;
import integrate.gui.PresentationFrame;

public class Main {
    
    public final static boolean DEBUGGING = true;

    public static void main(String[] args) {

        JFrame f = new PresentationFrame(new ClusteringApp());
        f.setVisible(true);

    }
}