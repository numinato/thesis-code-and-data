package integrate.gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import integrate.core.ClusteringApp;
import integrate.ds.ClusteringSet;

public class PresentationFrame extends JFrame implements ActionListener, ItemListener {

    private static final long serialVersionUID = 1L;

    DrawPanel dp = new DrawPanel();
    ClusteringApp tc;
    private boolean zTransform = true;

    JButton initButton;
    JButton stepButton;
    JButton toggleViewButton;
    JButton saveResultButton;
    JButton saveInitPointsButton;
    JButton saveInitClusteringsButton;
    JButton loadPointsButton;
    JButton loadInitialClusteringsButton;
    JButton reduceInitButton;
    JButton calcCostsForKsButton;
    JButton displayOriginButton;
    JButton displayResultButton;
    JButton runAlgorithmButton;
    JButton kIndieButton;
    JButton statsButton;

    JCheckBox checkBoxZTransform;

    JTextField textFieldStatus;
    JTextField kIndieTextField;
    JTextField textFieldK;
    JTextField textFieldDimNumerical;
    JTextField textFieldDimCategorical;
    JTextField textFieldMinK;
    JTextField textFieldMaxK;
    JTextField textFieldNumberOfAlgInits;
    JTextField textFieldNumberOfAlgTries;

    JTextArea textArea;
    JTextArea textAreaDuplicate;
    JTextArea largeTextArea;
    JTextArea thirdTextArea;

    JLabel labelK;
    JLabel labelDimNumerical;
    JLabel labelDimCategorical;
    JLabel labelRangeK;
    JLabel labelNumberOfAlgInits;
    JLabel labelNumberOfAlgTries;

    JTabbedPane tabbedPane;

    JScrollPane scrollPane;
    JScrollPane scrollPaneDuplicate;
    JScrollPane largeScrollPane;
    JScrollPane thirdScrollPane;

    public PresentationFrame(ClusteringApp tc) {

        this.tc = tc;
        setSize(950, 750);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Visualization");

        initButton = new JButton("init");
        stepButton = new JButton("step");
        toggleViewButton = new JButton("toggle view");
        statsButton = new JButton("write statistics to file");
        kIndieButton = new JButton("calculate k-independent clustering");
        saveResultButton = new JButton("save result");
        saveInitPointsButton = new JButton("save init points");
        saveInitClusteringsButton = new JButton("save init p & c");
        loadPointsButton = new JButton("load Points");
        loadInitialClusteringsButton = new JButton("load init clusterings");
        calcCostsForKsButton = new JButton("calculate costs for k's");
        displayOriginButton = new JButton("show origin");
        displayResultButton = new JButton("show result");
        reduceInitButton = new JButton("reduce");
        runAlgorithmButton = new JButton("run algorithm");

        textFieldStatus = new JTextField();
        textFieldStatus.setHorizontalAlignment(JTextField.CENTER);
        kIndieTextField = new JTextField("3");
        textFieldK = new JTextField("3");
        textFieldDimNumerical = new JTextField("2");
        textFieldDimCategorical = new JTextField("1");
        textFieldMinK = new JTextField("1");
        textFieldMaxK = new JTextField("20");
        textFieldNumberOfAlgInits = new JTextField("100");
        textFieldNumberOfAlgTries = new JTextField("100");

        
        textArea = new JTextArea();
        textAreaDuplicate = new JTextArea();
        largeTextArea = new JTextArea();
        thirdTextArea = new JTextArea();

        checkBoxZTransform = new JCheckBox("Z-Transformation", true);

        labelNumberOfAlgInits = new JLabel("# inits of algorithm:");
        labelRangeK = new JLabel("<= k <=", JLabel.CENTER);
        labelK = new JLabel("k", JLabel.LEFT);
        labelDimNumerical = new JLabel("dim. numerical:", JLabel.LEFT);
        labelDimCategorical = new JLabel("dim. categorical:", JLabel.LEFT);
        labelNumberOfAlgTries = new JLabel("# tries for algorithm:");
        
        tabbedPane = new JTabbedPane();

        scrollPane = new JScrollPane();
        scrollPaneDuplicate = new JScrollPane();
        largeScrollPane = new JScrollPane();
        thirdScrollPane = new JScrollPane();

        Container cont = getContentPane();
        cont.add(tabbedPane);

        Container contVisual = new Container();
        contVisual.setLayout(new BorderLayout());
        contVisual.add(dp, BorderLayout.CENTER);

        Container contSide = new Container();
        contVisual.add(contSide, BorderLayout.EAST);
        contSide.setLayout(new BorderLayout());

        Container contSideTop = new Container();
        contSideTop.setLayout(new GridLayout(18, 1));
        contSide.add(contSideTop, BorderLayout.NORTH);

        JPanel panelK = new JPanel(new GridLayout(1, 2));
        JPanel panelDimNumerical = new JPanel(new GridLayout(1, 2));
        JPanel panelDimCategorical = new JPanel(new GridLayout(1, 2));

        panelK.add(labelK);
        panelK.add(textFieldK);
        panelDimNumerical.add(labelDimNumerical);
        panelDimNumerical.add(textFieldDimNumerical);
        panelDimCategorical.add(labelDimCategorical);
        panelDimCategorical.add(textFieldDimCategorical);

        JPanel panelRangeK = new JPanel(new GridLayout(1, 3));
        panelRangeK.add(textFieldMinK);
        panelRangeK.add(labelRangeK);
        panelRangeK.add(textFieldMaxK);

        JPanel panelNumberOfAlgInits = new JPanel(new GridLayout(1, 2));
        panelNumberOfAlgInits.add(labelNumberOfAlgInits);
        panelNumberOfAlgInits.add(textFieldNumberOfAlgInits);

        JPanel panelNumberOfAlgTries = new JPanel(new GridLayout(1, 2));
        panelNumberOfAlgTries.add(labelNumberOfAlgTries);
        panelNumberOfAlgTries.add(textFieldNumberOfAlgTries);

        
        JPanel panelDisplay = new JPanel(new GridLayout(1, 2));
        panelDisplay.add(displayOriginButton);
        panelDisplay.add(displayResultButton);

        JPanel panelInitReduce = new JPanel(new GridLayout(1, 2));
        panelInitReduce.add(initButton);
        panelInitReduce.add(reduceInitButton);

        contSideTop.add(textFieldStatus);
        contSideTop.add(panelInitReduce);
        contSideTop.add(panelK);
        contSideTop.add(panelDimNumerical);
        contSideTop.add(panelDimCategorical);
        contSideTop.add(calcCostsForKsButton);
        contSideTop.add(panelRangeK);
        contSideTop.add(panelNumberOfAlgInits);
        contSideTop.add(panelDisplay);
        contSideTop.add(panelNumberOfAlgTries);
        contSideTop.add(runAlgorithmButton);
        contSideTop.add(toggleViewButton);
        contSideTop.add(saveResultButton);
        contSideTop.add(saveInitPointsButton);
        contSideTop.add(saveInitClusteringsButton);
        contSideTop.add(checkBoxZTransform);
        contSideTop.add(loadPointsButton);
        contSideTop.add(loadInitialClusteringsButton);

        scrollPane.setViewportView(textArea);
        scrollPaneDuplicate.setViewportView(textAreaDuplicate);

        largeScrollPane.setViewportView(largeTextArea);

        contSide.add(scrollPane, BorderLayout.CENTER);

        Container thirdCont = new Container();
        thirdScrollPane.setViewportView(thirdTextArea);
        thirdCont.setLayout(new BorderLayout());
        Container thirdContTop = new Container();
        thirdContTop.setLayout(new GridLayout(2, 1));
        thirdContTop.add(kIndieTextField);

        thirdCont.add(thirdScrollPane, BorderLayout.CENTER);

        tabbedPane.addTab("Visualization", contVisual);
        tabbedPane.addTab("Output", thirdCont);

        initButton.addActionListener(this);
        stepButton.addActionListener(this);
        toggleViewButton.addActionListener(this);
        kIndieButton.addActionListener(this);
        statsButton.addActionListener(this);
        displayOriginButton.addActionListener(this);
        displayResultButton.addActionListener(this);
        runAlgorithmButton.addActionListener(this);
        reduceInitButton.addActionListener(this);
        saveResultButton.addActionListener(this);
        saveInitPointsButton.addActionListener(this);
        saveInitClusteringsButton.addActionListener(this);
        loadPointsButton.addActionListener(this);
        loadInitialClusteringsButton.addActionListener(this);
        calcCostsForKsButton.addActionListener(this);

        checkBoxZTransform.addItemListener(this);
    }

    public void itemStateChanged(ItemEvent e) {
        if (e.getItemSelectable() == checkBoxZTransform) {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                zTransform = true;
            } else {
                zTransform = false;
            }
        }
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == initButton) {
            try {
                tc.init(tfToInt(textFieldK), tfToInt(textFieldDimNumerical), tfToInt(textFieldDimCategorical));
                textFieldStatus.setText("INITIALIZED");
                // try to display created clusterings and points
                ClusteringSet clusteringSet = tc.getCreatingClusteringSet();
                if (clusteringSet != null) {
                    dp.display(clusteringSet);
                }
            } catch (NumberFormatException nfe) {
                textFieldStatus.setText("NO INTEGERS");
            }
        }
        if (e.getSource() == reduceInitButton) {
            try {
                if (tc.reduceInit(tfToInt(textFieldDimNumerical), tfToInt(textFieldDimCategorical))) {
                    textFieldStatus.setText("INITIALIZED");
                    ClusteringSet clusteringSet = tc.getCreatingClusteringSet();
                    if (clusteringSet != null) {
                        dp.display(clusteringSet);
                    }
                }
            } catch (NumberFormatException nfe) {
                textFieldStatus.setText("NO INTEGERS");
            }
        }
        if (e.getSource() == calcCostsForKsButton) {
            try {
                int minK = tfToInt(textFieldMinK);
                int maxK = tfToInt(textFieldMaxK);
                int numberOfAlgInits = tfToInt(textFieldNumberOfAlgInits);

                String result = tc.calcCostsForKs(minK, maxK, numberOfAlgInits);
                if (result != null) {
                    thirdTextArea.setText(thirdTextArea.getText() + result);
                    tabbedPane.setSelectedIndex(1);
                }
            } catch (NumberFormatException nfe) {
                textFieldStatus.setText("NO INTEGERS");
            }
        }
        if (e.getSource() == displayOriginButton) {
            ClusteringSet clusteringSet = tc.getCreatingClusteringSet();
            if (clusteringSet != null) {
                dp.display(clusteringSet);
            }
        }
        if (e.getSource() == displayResultButton) {
            ClusteringSet clusteringSet = tc.getResultClusteringSet();
            if (clusteringSet != null) {
                dp.display(clusteringSet);
            }
        }
        if (e.getSource() == runAlgorithmButton) {
            try {
                int numberOfAlgInits = tfToInt(textFieldNumberOfAlgInits);
                int numberOfAlgTries = tfToInt(textFieldNumberOfAlgTries);
                String result = tc.runAlgorithm(numberOfAlgInits, numberOfAlgTries);
                if (result != null) {
                    thirdTextArea.setText(thirdTextArea.getText() + result);
                    tabbedPane.setSelectedIndex(1);
                }
            } catch (NumberFormatException nfe) {
                textFieldStatus.setText("NO INTEGERS");
            }
        }
        if (e.getSource() == toggleViewButton) {
            dp.markClusterings = (dp.markClusterings ? false : true);
            dp.repaint();
        }

        if (e.getSource() == saveResultButton) {
            try {
                tc.saveResult(this);
            } catch (IOException e1) {
                textFieldStatus.setText("IO EXCEPTION");
                e1.printStackTrace();
            }
        }
        if (e.getSource() == saveInitPointsButton) {
            try {
                if (tc.saveInitPoints(this)) {
                    textFieldStatus.setText("SAVED");
                }
            } catch (IOException e1) {
                textFieldStatus.setText("IO EXCEPTION");
                e1.printStackTrace();
            }
        }
        if (e.getSource() == saveInitClusteringsButton) {
            try {
                if (tc.saveInitClusterings(this)) {
                    textFieldStatus.setText("SAVED");
                }
            } catch (IOException e1) {
                textFieldStatus.setText("IO EXCEPTION");
                e1.printStackTrace();
            }
        }
        if (e.getSource() == loadPointsButton) {
            try {
                if (tc.loadPoints(this, zTransform)) {
                    textFieldStatus.setText("LOADED");
                }
            } catch (IOException e1) {
                textFieldStatus.setText("IO EXCEPTION");
                e1.printStackTrace();
            }
        }
        if (e.getSource() == loadInitialClusteringsButton) {
            try {
                if (tc.loadInitialClusterings(this)) {
                    textFieldStatus.setText("LOADED");
                }
            } catch (IOException e1) {
                textFieldStatus.setText("IO EXCEPTION");
                e1.printStackTrace();
            }
        }
    }

    private int tfToInt(JTextField tf) throws NumberFormatException {
        return Integer.parseInt(tf.getText());
    }
}