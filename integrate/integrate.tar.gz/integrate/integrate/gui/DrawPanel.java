package integrate.gui;

import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;

import javax.swing.*;

import integrate.ds.*;
import integrate.ds.Point;

public class DrawPanel extends JPanel {

    private static final long serialVersionUID = 3171825416376561537L;

    final double stretching = 35.0;
    private ClusteringSet clusteringSetToBeDrawn;
    private DrawingState drawingState;
    public String drawingCommand = "";
    public boolean markClusterings = false;
    public int stepCount;

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        super.paintComponent(g2);

        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.translate(350.0, 350.0);

        // draw axes

        g2.draw(new Rectangle(-350, -350, 700, 700));
        g2.drawLine(-350, 0, +350, 0);
        g2.drawLine(0, -350, 0, +350);

        if (drawingState == DrawingState.DRAW_CLUSTERING_SET) {
            for (Clustering c : clusteringSetToBeDrawn.clusterings) {
                drawX(g2, c.numMeans[0] * stretching, c.numMeans[1] * stretching, Color.RED);
            }
            Color col = Color.GREEN;

            for (Clustering c : clusteringSetToBeDrawn.clusterings) {
                for (Point p : c.points) {
                    if (markClusterings) {
//                        if (p.catParameters.length == 0 ) {
                            drawPoint(g2, p.numParameters[0] * stretching, p.numParameters[1] * stretching,
                                    3, col);
//                        } 
//                        else {
//                            // drawPoint( g2, p.xs[0] * streching, p.xs[1] *
//                            // streching, 2, Color.RED);
//                            drawTriangle(g2, p.numParameters[0] * stretching,
//                                    p.numParameters[1] * stretching, 4, col);
//                        }
                    } else {
                        if (p.catParameters.length == 0 || p.catParameters[0] == 0) {
                            drawPoint(g2, p.numParameters[0] * stretching, p.numParameters[1] * stretching,
                                    3, Color.BLUE);
                        } else if (p.catParameters[0] == 1 ) {
                            drawPoint(g2, p.numParameters[0] * stretching, p.numParameters[1] * stretching,
                                    3, Color.RED);
                        } else {
                            drawPoint(g2, p.numParameters[0] * stretching, p.numParameters[1] * stretching,
                                    3, Color.GREEN);
//                            // drawPoint( g2, p.xs[0] * stretching, p.xs[1] *
//                            // stretching, 2, Color.RED);
//                            drawTriangle(g2, p.numParameters[0] * stretching,
//                                    p.numParameters[1] * stretching, 4, Color.RED);
                        }
                    }
                }
                col = getNextColor(col);
            }
        }
    }

    private void drawPoint(Graphics2D g2, double x, double y, double diameter, Color color) {
        double radius = diameter / 2.0;
        g2.setColor(color);
        g2.fill(new Ellipse2D.Double(x - radius, y - radius, diameter, diameter));
    }

    private void drawTriangle(Graphics2D g2, double x_double, double y_double, int height, Color color) {
        int x = (int) x_double;
        int y = (int) y_double;
        g2.setColor(color);
        g2.fill(new Polygon(new int[] { x, x + height / 2, x - height / 2, x }, new int[] { y - height / 2,
                y + height / 2, y + height / 2, y - height / 2 }, 4));
    }

    private void drawX(Graphics2D g2, double x, double y, Color color) {
        g2.setColor(color);
        g2.drawLine((int) x - 10, (int) y - 10, (int) x + 10, (int) y + 10);
        g2.drawLine((int) x - 10, (int) y + 10, (int) x + 10, (int) y - 10);
    }

    private Color getNextColor(Color c) {
        ArrayList<Color> colors = new ArrayList<Color>();
        colors.add(Color.GREEN);
        colors.add(Color.BLACK);
        colors.add(Color.RED);
        colors.add(Color.CYAN);
        colors.add(Color.MAGENTA);
        colors.add(Color.PINK);
        colors.add(Color.BLUE);
        colors.add(Color.YELLOW);
        colors.add(Color.ORANGE);
        colors.add(Color.GRAY);
        return colors.get((colors.indexOf(c) + 1) % 10);
    }

    public void display(ClusteringSet clusteringSet) {
        clusteringSetToBeDrawn = clusteringSet;
        drawingState = DrawingState.DRAW_CLUSTERING_SET;
        this.repaint();

    }
}
